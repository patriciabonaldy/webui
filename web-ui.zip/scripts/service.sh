#!/bin/bash

APP_NAME=fiscar-data-explorer-web-ui
VERSION=$(git describe --tags)
export USER='27954448776'
export PASSWORD='bolita2020.'

if [ -z $VERSION ]; then
    VERSION=0.0.1 #Por si no hay version en git aun
fi

build-all(){
    rm -rf target/
    declare -a arr=("development" "qa" "production")
    for i in "${arr[@]}"
    do
        echo "Building in $i"
        export NODE_ENV=$i 
        export MODE_ENV=$i
        npm run build
    done
}

deploy-to-nexus(){
    cd target 
    declare -a arr=("development" "qa" "production")    
    for i in "${arr[@]}"
    do
        export NODE_ENV=$i
        tar -czvf fiscar-data-explorer-web-ui-${NODE_ENV}-${VERSION}.tar.gz dist-${NODE_ENV}
        md5sum fiscar-data-explorer-web-ui-${NODE_ENV}-${VERSION}.tar.gz | cut -d ' ' -f 1 > fiscar-data-explorer-web-ui-${NODE_ENV}-${VERSION}.tar.gz.md5
        sha1sum fiscar-data-explorer-web-ui-${NODE_ENV}-${VERSION}.tar.gz | cut -d ' ' -f 1 > fiscar-data-explorer-web-ui-${NODE_ENV}-${VERSION}.tar.gz.sha1
        #
        curl --noproxy '*' -vk --user $USER:$PASSWORD -X PUT --verbose --upload-file fiscar-data-explorer-web-ui-${NODE_ENV}-${VERSION}.tar.gz     https://nexus.cloudint.afip.gob.ar/nexus/repository/fisca-seleccion-casos-raw/fiscar-data-explorer-web-ui/${VERSION}/fiscar-data-explorer-web-ui-${NODE_ENV}-${VERSION}.tar.gz
        echo  https://nexus.cloudint.afip.gob.ar/nexus/repository/fisca-seleccion-casos-raw/fiscar-data-explorer-web-ui/${VERSION}/fiscar-data-explorer-web-ui-${NODE_ENV}-${VERSION}.tar.gz >> ./log.txt
        curl --noproxy '*' -vk --user $USER:$PASSWORD -X PUT --verbose --upload-file fiscar-data-explorer-web-ui-${NODE_ENV}-${VERSION}.tar.gz.sha1 https://nexus.cloudint.afip.gob.ar/nexus/repository/fisca-seleccion-casos-raw/fiscar-data-explorer-web-ui/${VERSION}/fiscar-data-explorer-web-ui-${NODE_ENV}-${VERSION}.tar.gz.sha1
        curl --noproxy '*' -vk --user $USER:$PASSWORD -X PUT --verbose --upload-file fiscar-data-explorer-web-ui-${NODE_ENV}-${VERSION}.tar.gz.md5  https://nexus.cloudint.afip.gob.ar/nexus/repository/fisca-seleccion-casos-raw/fiscar-data-explorer-web-ui/${VERSION}/fiscar-data-explorer-web-ui-${NODE_ENV}-${VERSION}.tar.gz.md5

    done
    rm fiscar-data-explorer-web-ui-*.tar.*
    cd ..    
}

case "$1" in
    build-all)
        build-all
        ;;
    deploy-to-nexus)
        deploy-to-nexus
        ;;
    *)
        echo "Usage: $0 {env|docker|rundev|release}"
esac