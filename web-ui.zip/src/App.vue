<template>
 <v-app id="app" >
   <Notificacion v-if="mensaje" :color="color" :titulo="titulo" :mensaje="mensaje" @close="closeErrorNotification()" :goToHome="goToHome" :goToCampana="goToCampana" :path="fullPath"/>
   <v-content style="padding: 48px 0 0 0;">
      <v-layout row>  
        <v-flex>
          <MenuSuperior style="padding-left: 0px; "/>
        </v-flex>
      </v-layout>       
    
      <v-layout >
        <transition name="moveInUp">
          <router-view/>
        </transition>
      </v-layout>
    </v-content>
  </v-app>

</template>

<script lang="ts">
import { Component, Vue, Watch} from 'vue-property-decorator';
import MenuSuperior from '@/components/MenuSuperior.vue';
import WebFontLoader from 'webfontloader';
import Notificacion from '@/components/Notificacion.vue';
import {namespace} from 'vuex-class';

const store = namespace('SeleccionarStore');


@Component({
  components:{
    MenuSuperior,
    Notificacion
  }
})
export default class App extends Vue {
   @store.State('titulo') titulo: string;  
   @store.State('color') color: string;  
   @store.State('mensaje') mensaje: string;  
   @store.State('goToHome') goToHome: Boolean;
   @store.State('goToCampana') goToCampana: Boolean;
   @store.State('fullPath') fullPath: string;
   @store.State('impuestos') impuestos: Array<any>;
   @store.Action('getImpuestosSefi') getImpuestosSefi: Function;

   @store.Action('closeErrorNotification') closeErrorNotification: Function;

    

    @Watch('mensaje')
    updateHipotesis(val, oldVal) {
    }

    beforeMount() {
        this.getImpuestosSefi();
    }
}
</script>

<style>
.moveInUp-enter-active{
  animation: fadeIn 1s ease-in;
}
@keyframes fadeIn{
  0%{
    opacity: 0;
  }
  50%{
    opacity: 0.5;
  }
  100%{
    opacity: 1;
  }
}

.containerFiltro {
    -webkit-box-flex: 1;
    -ms-flex: 1 1 100%;
    flex: 1 1 80%;
    margin-left: 22%;
    padding: 24px;
    width: 40%;
    color: #65c6e8;
    color: #1075a8;
}
</style>