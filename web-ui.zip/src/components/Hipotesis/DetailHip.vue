<template>
    <v-dialog v-if="showDetailHipComputed" persistent v-model="showDetailHipComputed" width="1000px" height="630px" hide-overlay transition="dialog-bottom-transition">
        <v-toolbar color="primary" dark tabs>
            <v-toolbar-title>{{ h.nombreHipotesis}}</v-toolbar-title>
            <v-spacer></v-spacer>
            <v-btn icon dark @click="closeit(false)">
                <v-icon>close</v-icon>
            </v-btn>
        </v-toolbar>

        <v-tabs left color="primary" dark icons-and-text slider-color="yellow" v-model="active_tab">
            <v-tab href="#tab-1" :key="1">Detalle
                <v-icon>subject</v-icon>
            </v-tab>
            <v-tab href="#tab-2" :key="2">Corridas
                <v-icon>history</v-icon>
            </v-tab>
            <v-tab href="#tab-3" :key="3">Nueva Corrida
                <v-icon>fa-plus</v-icon>
            </v-tab>
            <v-tab href="#tab-4" :key="4">Dashboard
                <v-icon>show_chart</v-icon>
            </v-tab>
            <v-tab-item :key="1" :value="'tab-1'">
                <div style="height: 630px">
                    <Hipotesis></Hipotesis>
                </div>
            </v-tab-item>
            <v-tab-item :key="2" :value="'tab-2'">
                <div style="height: 630px">
                    <HistoricoHipotesis v-if="h && active_tab == 'tab-2'"></HistoricoHipotesis>
                </div>
            </v-tab-item>
            <v-tab-item :key="3" :value="'tab-3'">
                <div style="height: 630px">
                    <FiltrosHipotesis></FiltrosHipotesis>
                </div>
            </v-tab-item>
            <v-tab-item :key="4" :value="'tab-4'">
                <div style="height: 630px">
                    <ChartHip v-if="h && active_tab == 'tab-4'" ></ChartHip>
                </div>
            </v-tab-item>
        </v-tabs>
    </v-dialog>
</template>

<script lang="ts">
    import {Component, Prop, Watch, Vue} from 'vue-property-decorator';
    import {namespace} from 'vuex-class';
    import CardHipotesis from '@/components/Hipotesis/CardHipotesis.vue';
    import FiltrosHipotesis from '@/components/Hipotesis/FiltrosHipotesis.vue';
    import ChartHip from '@/components/Hipotesis/ChartHip.vue';
    import Hipotesis from '@/components/Hipotesis/Hipotesis.vue';

    import HistoricoHipotesis from '@/components/Hipotesis/HistoricoHipotesis.vue';

    const store = namespace('SeleccionarStore');

    @Component({
        components: {CardHipotesis, FiltrosHipotesis, ChartHip, Hipotesis, HistoricoHipotesis}
    })

    export default class DetailHip extends Vue {
        @store.State('showDetailHip') showDetailHip: Boolean;
        @store.State('hipotesisSeleccionada') h;
        @store.Mutation('SET_SHOW_DETAIL_HIPOTESIS') SET_SHOW_DETAIL_HIPOTESIS: Function;

        step: Number = 1;
        active_tab: string = "tab-1";

        get showDetailHipComputed() {
            return this.showDetailHip;
        }

        set showDetailHipComputed(value) {
            this.SET_SHOW_DETAIL_HIPOTESIS(value);
        }

        closeit() {
            this.SET_SHOW_DETAIL_HIPOTESIS(false);
            this.active_tab = "tab-1";
            this.$emit('close');
        }

    }

</script>
<style>
    .tileContent {
        font-weight: bold;
    }

    .sizeCard {
        height: 280px;
    }

    .size_Card {
        height: 260px;
    }

</style>