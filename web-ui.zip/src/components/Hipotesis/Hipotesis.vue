<template>
    <v-card style="height: 100%">
        <h3 style="text-align: left; padding-top: 16px; padding-left: 16px">Detalle</h3>
        
        <!--v-container grid-list-md style="padding-top: 0; padding-bottom: 0">
            <v-layout wrap>
                <v-flex sm6>
                    <v-text-field class="my-input" disabled v-model="h.nombreHipotesis" label="Nombre de Hipotesis" type="text" ></v-text-field>
                </v-flex>
                <v-flex sm6>
                    <v-text-field class="my-input" disabled v-model="h.objetivoHipotesis" label="Objetivo de la Hipotesis" type="text"  ></v-text-field>
                </v-flex>
                <v-flex sm12>
                    <v-text-field class="my-input" disabled v-model="h.descripcionHipotesis" label="Descripcion de la Hipotesis" type="text"></v-text-field>
                </v-flex>  
                <v-flex sm3>
                    <v-text-field class="my-input" disabled v-model="h.areaDefinidoraSeleccionada" label="Area Definidora" type="text"></v-text-field>
                </v-flex>
                <v-flex sm2>
                    <v-text-field class="my-input" disabled v-model="h.dirGral" label="Direccion General " type="text"></v-text-field>
                </v-flex>
                <v-flex sm4>
                    <v-text-field class="my-input" disabled v-model="h.impuesto" label="Impuesto" type="text"></v-text-field>
                </v-flex>
                <v-flex sm3>
                    <v-text-field class="my-input" disabled v-model="h.hipotesisFormularios" label="Formularios" type="text"></v-text-field>
                </v-flex>  
                <v-flex sm6>
                    <v-text-field class="my-input" disabled v-model="h.concepto" label="Concepto" type="text"></v-text-field>
                </v-flex>  
                <v-flex sm6>
                    <v-text-field class="my-input" disabled v-model="h.origen" label="Origen" type="text"></v-text-field>
                </v-flex>  
                <v-flex sm6>
                    <v-text-field class="my-input" disabled v-model="h.tipoRelevancia" label="Tipo Relevancia " type="text"></v-text-field>
                </v-flex>   
                <v-flex sm6>
                    <v-text-field class="my-input" disabled v-model="h.tipoPonderacion" label="Tipo Ponderacion " type="text"></v-text-field>
                </v-flex> 
                <v-flex sm6>
                    <v-text-field class="my-input" disabled v-model="h.codigoDeInstructivoSeleccionado" label="Codigo de instructivo " type="text"></v-text-field>
                </v-flex> 
                <v-flex sm6>
                    <v-text-field class="my-input" disabled v-model="h.exclusividadSeleccionada" label="Exclusividad" type="text"></v-text-field>
                </v-flex>                         
                
            </v-layout>
            </v-container-->
        <v-container grid-list-md style="padding-top: 10; padding-bottom: 0">    
            <v-layout wrap>
                <v-flex sm2>
                    <span class="font-weight-bold text-xs-left"  >Objetivo de la Hipotesis</span>
                </v-flex>
                <v-divider vertical></v-divider>
                <v-flex sm9>
                    <div class="font-weight-light black--text pa-1 text-xs-left caption">
                        {{h.objetivoHipotesis}}
                    </div>
                </v-flex>
                <v-flex sm2>
                    <span class="font-weight-bold text-xs-left">Descripcion de la Hipotesis</span>
                </v-flex>
                <v-divider vertical></v-divider>
                <v-flex sm9 >
                    <div class="black--text pa-1 text-xs-left caption">
                        {{h.descripcionHipotesis}}
                    </div>
                </v-flex>
                <v-flex sm2>                    
                    <span class="font-weight-bold text-xs-left"  >Area Definidora</span>                    
                </v-flex>
                <v-divider vertical></v-divider>
                <v-flex sm9 >                    
                    <div class="black--text pa-1 text-xs-left caption">
                        {{h.areaDefinidoraSeleccionada}}
                    </div>                    
                </v-flex>
                <v-flex sm2>                    
                    <span class="font-weight-bold text-xs-left" >Direccion General</span>
                </v-flex>
                <v-divider vertical></v-divider>
                <v-flex sm9 >
                    <span class="black--text pa-1 text-xs-left caption">
                        {{h.dirGral}}
                    </span>                  
                </v-flex>
                <v-flex sm2>                    
                    <span class="font-weight-bold text-xs-left" >Impuesto</span>
                </v-flex>
                <v-divider vertical></v-divider>
                <v-flex sm9 >
                    <span class="black--text pa-1 text-xs-left caption">
                        {{h.impuesto}}
                    </span>                  
                </v-flex>  
                <v-flex sm2>                    
                    <span class="font-weight-bold text-xs-left">Formularios</span>
                </v-flex>
                <v-divider vertical></v-divider>
                <v-flex sm9 >
                    <v-textarea auto-grow  disabled                              
                                v-model="h.hipotesisFormularios.join().trim()" style="margin-top: -10px;font-size: 14px;"
                                rows="1">
                    </v-textarea> 
                    
                </v-flex>        
                <v-flex sm2>                    
                    <span class="font-weight-bold text-xs-left" >Concepto</span>
                </v-flex>
                <v-divider vertical></v-divider>
                <v-flex sm9 >
                    <span class="black--text pa-1 text-xs-left caption">
                        {{h.concepto}}
                    </span>                  
                </v-flex>       
                <v-flex sm2>                    
                    <span class="font-weight-bold text-xs-left" >Origen</span>
                </v-flex>
                <v-divider vertical></v-divider>
                <v-flex sm9 >
                    <span class="black--text pa-1 text-xs-left caption">
                        {{h.origen}}
                    </span>                  
                </v-flex>    
                <v-flex sm2>                    
                    <span class="font-weight-bold text-xs-left">Tipo Relevancia</span>
                </v-flex>
                <v-divider vertical></v-divider>
                <v-flex sm9 >
                    <span class="black--text pa-1 text-xs-left caption">
                        {{h.tipoRelevancia}}
                    </span>                  
                </v-flex>  
                <v-flex sm2>                    
                    <span class="font-weight-bold text-xs-left" >Tipo Ponderacion</span>
                </v-flex>
                <v-divider vertical></v-divider> 
                <v-flex sm9 >
                    <span class="black--text pa-1 text-xs-left caption">
                        {{h.tipoPonderacion}}
                    </span>                  
                </v-flex>  
                <v-flex sm2>                    
                    <span class="font-weight-bold text-xs-left">Tipo de Desvio</span>
                </v-flex>
                <v-divider vertical></v-divider> 
                <v-flex sm9 >
                    <span class="black--text pa-1 text-xs-left caption">
                        {{h.codigoDeTipoDesvioSeleccionado}}
                    </span>                  
                </v-flex> 
                <v-flex sm2>                    
                    <span class="font-weight-bold text-xs-left">Codigo de instructivo</span>
                </v-flex>
                <v-divider vertical></v-divider> 
                <v-flex sm9 >
                    <span class="black--text pa-1 text-xs-left caption">
                        {{h.codigoDeInstructivoSeleccionado}}
                    </span>                  
                </v-flex> 
                <v-flex sm2>                    
                    <span class="font-weight-bold text-xs-left">Exclusividad </span>
                </v-flex>
                <v-divider vertical></v-divider> 
                <v-flex sm9 >
                    <span class="black--text pa-1 text-xs-left caption">
                        {{h.exclusividadSeleccionada}}
                    </span>                  
                </v-flex>               
            </v-layout>
        </v-container>        
    </v-card>
    
</template>

<script lang="ts">

    import {Component, Prop, Watch, Vue} from 'vue-property-decorator';
    import {namespace} from 'vuex-class';
    import {hyphenate} from '@/helpers';

    const store = namespace('SeleccionarStore');

    @Component({
        components: {}
    })
    export default class Hipotesis extends Vue {
        @store.State('hipotesisSeleccionada') h: Object;
        step: Number = 1;
        expand: false;
        instructivo: String = "";
        formularios: String = "";

        labelSelect(value){
            return hyphenate(value);
        }
        
        
    }
</script>
<style>
  .title{
      color: #1976d2; 
  }

  .v-text-field__slot {
    border: none;
    overflow: auto;
    -webkit-box-shadow: none;
    -moz-box-shadow: none;
    box-shadow: none;
    border-style: none;
    border-bottom-style: none;
    outline: none; 
}

.v-textarea  {
    -webkit-rtl-ordering: logical;
    outline: none;
    -webkit-box-shadow: none;
    -moz-box-shadow: none;
    box-shadow: none;
    border-style: none;    
    border-width: 0px;
    border-top-width: 0px;
    border-right-width: 0px;
    border-bottom-width: 0px;
    border-left-width: 0px;
    border-bottom-style: none;
    border: none;
}


.v-text-field.v-text-field--solo:not(.v-text-field--solo-flat) .v-input__slot {
     -webkit-box-shadow: none; 
      box-shadow: none;
      border: none;
}
</style>
