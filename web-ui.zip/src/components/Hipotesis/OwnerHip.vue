<template>
    <div>
       <DetailHip v-if="h"></DetailHip>
        <!--<span v-for="h in hipotesis" :key="h.idHipotesis" > {{h.idHipotesis}}</span>-->
        <!--div v-infinite-scroll="loadMore" infinite-scroll-disabled="busy" infinite-scroll-distance="limit"-->
        <Slider ref="slider" id="slider_loop" direction="horizontal" :performance-mode="true" :pagination-visible="true" :pagination-clickable="true" @slide-change-end="updateCurrentPage" :async-data="localHipotesisComputed" style="height: 370px">
            <v-flex v-for="(h, i) in localHipotesisComputed" :key="i" sm4>
                <v-card height="300px" width="350px">
                    <div v-if="i >= (sliderCurrentPage - 1)  && i <= sliderCurrentPage + 1">
                        <v-toolbar card :style="'height: 50px;'">
                            <v-toolbar-title class="title text-capitalize"><h5>{{ h.nombreHipotesis }}</h5></v-toolbar-title>
                            <v-spacer></v-spacer> 
                            <v-tooltip bottom>
                                <v-btn small fab dark class="btnInfo" style="height: 26px;" :color="setColorEstado(h.hipotesisCorridas)"   @click="setShow(sheet = true,h)" slot="activator">
                                    <v-icon>{{ setIcon() }}</v-icon>
                                </v-btn>
                                <span>{{ getUltimaCorridaHipotesis(h.hipotesisCorridas) }}</span>
                            </v-tooltip>
                        </v-toolbar>
                        <v-list :threeLine="true">
                            <v-list-tile>
                                <v-list-tile-content class="caption"><span class="font-weight-bold">Concepto:</span>{{ h.concepto}}</v-list-tile-content>
                            </v-list-tile>
                        </v-list>
                        <v-list dense>
                            <v-list-tile>
                                <v-list-tile-content dense class="caption">Direcci&oacute;n General: {{ h.dirGral}}</v-list-tile-content>
                            </v-list-tile>
                        </v-list>
                        <v-list :twoLine="true">
                            <v-list-tile>
                                <v-list-tile-content dense class="caption">Origen: {{ h.origen}}</v-list-tile-content>
                            </v-list-tile>
                        </v-list>
                    </div>

                    <div v-if="i < (sliderCurrentPage - 1)  || i > sliderCurrentPage + 1">
                        <v-toolbar card :style="'height: 50px;'">
                            <v-toolbar-title class="title text-capitalize"><h5>Cargando...</h5></v-toolbar-title>
                        </v-toolbar>
                        <v-list :threeLine="true">
                            <v-list-tile>
                                <v-list-tile-content class="caption"><span class="font-weight-bold">Cargando...</span></v-list-tile-content>
                            </v-list-tile>
                        </v-list>
                        <v-list dense>
                            <v-list-tile>
                                <v-list-tile-content dense class="caption">Cargando...</v-list-tile-content>
                            </v-list-tile>
                        </v-list>
                        <v-list :twoLine="true">
                            <v-list-tile>
                                <v-list-tile-content dense class="caption">Cargando...</v-list-tile-content>
                            </v-list-tile>
                        </v-list>
                    </div>
                </v-card>
            </v-flex>
        </Slider>
        </div>
    <!--/div-->
</template>
<script lang="ts">
    import {Component, Prop, Vue, Watch} from 'vue-property-decorator';
    import {namespace} from 'vuex-class';
    import Slider from 'vue-plain-slider';
    import DetailHip from '@/components/Hipotesis/DetailHip.vue';
    import {getIcon, getColorEstado, getIdUltimaCorrida, getDescEstado} from '@/helpers';

    const store = namespace('SeleccionarStore');

    @Component({
        components: {
            Slider, DetailHip
        }
    })
    export default class OwnerHip extends Vue {
        @store.State('showDetailHip') showDetailHip: Boolean;
        @store.Mutation('SET_SHOW_DETAIL_HIPOTESIS') SET_SHOW_DETAIL_HIPOTESIS: Function;
        @store.Action('setHipotesisSeleccionada') setHipotesisSeleccionada: Function;
        @store.State('hipotesisSeleccionada') h;

        @Prop(Array) hipotesis: Array<any>;

        localHipotesis: Array<any> = [];
        allHipotesis: Array<any> = [];
        icon: String = 'search-plus';
        sheet: Boolean = false;
        sliderCurrentPage: Number = 1;
        x: Number = 0;
        busy: Boolean = false;

        beforeMount() {
            this.localHipotesisComputed = this.hipotesis;
        }

        @Watch('hipotesis')
        updateHipotesis(val: Array<any>, oldVal: Array<any>) {
            this.sliderCurrentPage = 1;
            let slider: Slider = this.$refs.slider;
            slider.setPage(this.sliderCurrentPage);
            this.localHipotesisComputed = val;
        }

        get localHipotesisComputed() {
            return this.localHipotesis;
        }

        set localHipotesisComputed(value) {
            this.localHipotesis = value;
           
            /*let i = Number(this.x);
            let valMax = i+10;
            let mapFinal = [];

            for (; i < valMax; i++) {
                this.localHipotesis.push(value[i]);
            }
            this.x=i;*/
        }

        loadMore() {
            console.log("Adding 10 more data results");
            this.busy = true;
            this.localHipotesisComputed = this.hipotesis;
        }

        setShow(value, h) {
            this.setHipotesisSeleccionada(h);
            this.SET_SHOW_DETAIL_HIPOTESIS(value);
        }

        setIcon() {
            return getIcon('detail');
        }

        updateCurrentPage(currentPage, el) {
            this.sliderCurrentPage = currentPage;
        }

        setColorEstado(value) {
            if (value.length > 0) {
                return getColorEstado(value[getIdUltimaCorrida(value)].estado);
            }
        }

        getUltimaCorridaHipotesis(value){
            if (value.length > 0) {
                return getDescEstado(value[getIdUltimaCorrida(value)].estado);
            }
        }

    }

</script>
<style>
    .headCard {
        box-shadow: 0px 2px 4px -1px rgba(0, 0, 0, 0.2), 0px 4px 5px 0px rgba(0, 0, 0, 0.14), 0px 1px 10px 0px rgba(0, 0, 0, 0.12);
        position: relative;
    }

    .slider {
        /*height: 400px;*/
        height: 280px;
        width: 1100px;
    }

    .infoHip {
        position: absolute;
        top: 15px;
        left: 300px;
    }

    .titleHip {
        top: 15px;
        position: absolute;
    }

    .textHip {
        top: 22px;
        left: 30px;
        position: absolute;
    }

    .vCard {
        background-color: #fafafa;
        border-color: #fafafa;
        color: rgb(18, 18, 18);
    }

    .containerCard {
        box-shadow: 0 2px 1px -1px rgba(0, 0, 0, .2), 0 1px 1px 0 rgba(0, 0, 0, .14), 0 1px 3px 0 rgba(0, 0, 0, .12);
    }

    .btnInfo {
        top: -8px;
        left: 24px;
        height: 26px;
    }
</style>