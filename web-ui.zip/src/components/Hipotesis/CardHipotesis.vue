<template>
    <v-list class="sizeCard" v-if="selectionComputed">
        <v-layout row wrap>
            <v-flex xs5 sm4>
                <v-list-tile>
                    <v-list-tile-content class="caption tileContent info--text text--darken-3">Codigo Instructivo:  </v-list-tile-content>
                    <v-list-tile-content class="align-end caption text-capitalize">{{ selection.codigoDeInstructivoSeleccionado}}</v-list-tile-content>
                </v-list-tile>
            </v-flex>
            <v-flex xs5 sm4>
                <v-list-tile>
                    <v-list-tile-content class="caption tileContent info--text text--darken-3">Direccion General:  </v-list-tile-content>
                    <v-list-tile-content class="align-end caption text-capitalize">{{ selection.dirGral}}</v-list-tile-content>
                </v-list-tile>
            </v-flex>
            <v-flex xs5 sm4>
                <v-list-tile>
                    <v-list-tile-content class="caption tileContent info--text text--darken-3">Area Generadora:  </v-list-tile-content>
                    <v-list-tile-content class="align-end caption text-capitalize">{{ selection.areaDefinidoraSeleccionada}}</v-list-tile-content>
                </v-list-tile>
            </v-flex>

            <v-flex xs5 sm6>
                <v-list-tile>
                    <v-list-tile-content class="caption tileContent info--text text--darken-3">Concepto:  </v-list-tile-content>
                    <v-list-tile-content class="align-end caption text-capitalize">{{ selection.concepto}}</v-list-tile-content>
                </v-list-tile>
            </v-flex>
            <v-flex xs5 sm6>
                <v-list-tile>
                    <v-list-tile-content class="caption tileContent info--text text--darken-3">Origen:  </v-list-tile-content>
                    <v-list-tile-content class="align-end caption text-capitalize">{{ selection.origen}}</v-list-tile-content>
                </v-list-tile>
            </v-flex>

            <v-flex xs5 sm12>
                <v-list-tile>
                    <v-list-tile-content class="caption tileContent info--text text--darken-3">Exclusividad:  </v-list-tile-content>
                    <v-list-tile-content class="align-end caption text-capitalize">{{ selection.exclusividadSeleccionada}}</v-list-tile-content>
                </v-list-tile>
            </v-flex>

            <Slider sm12 ref="slider" id="slider_loop" direction="horizontal" :performance-mode="true" :pagination-visible="true" :pagination-clickable="true" @slide-change-end="updateCurrentPage" style="height: 130px" :async-data="selectionComputed.hipotesisCorridas">
                <v-card v-for="hipotesisCorrida in sortedCorridasComputed" sm12 style="height: 100px">
                    <v-layout row wrap>
                        <v-flex xs5 sm6>
                            <v-list-tile>
                                <v-list-tile-content class="caption tileContent info--text text--darken-3">Fecha de ejecuci&oacute;n:  </v-list-tile-content>
                                <v-list-tile-content class="align-end caption text-capitalize">{{ hipotesisCorrida.fechaEjecucion }}</v-list-tile-content>
                            </v-list-tile>
                        </v-flex>
                        <v-flex xs5 sm6>
                            <v-list-tile>
                                <v-list-tile-content class="caption tileContent info--text text--darken-3">Periodo:  </v-list-tile-content>
                                <v-list-tile-content class="align-end caption text-capitalize">{{ periodoUltCorrida(hipotesisCorrida) }}</v-list-tile-content>
                            </v-list-tile>
                        </v-flex>
                        <v-flex xs5 sm6 class="">
                            <v-list-tile>
                                <v-list-tile-content class="caption tileContent info--text text--darken-3">Cant. de Usuarios:  </v-list-tile-content>
                                <v-list-tile-content class="align-end caption text-capitalize">{{ hipotesisCorrida.nCantReg}}</v-list-tile-content>
                            </v-list-tile>
                        </v-flex>
                        <v-flex xs5 sm6>
                            <v-list-tile>
                                <v-list-tile-content class="caption tileContent info--text text--darken-3">Ajuste Estimado:  </v-list-tile-content>
                                <v-list-tile-content class="align-end caption text-capitalize">{{ hipotesisCorrida.iAjustePotencial}}</v-list-tile-content>
                            </v-list-tile>
                        </v-flex>
                    </v-layout>
                </v-card>
            </Slider>
        </v-layout>
    </v-list>
</template>

<script lang="ts">
    import {Component, Prop, Watch, Vue} from 'vue-property-decorator';
    import {namespace} from 'vuex-class';
    import Slider from 'vue-plain-slider';

    const store = namespace('SeleccionarStore');

    @Component({
        components: {
            Slider
        }
    })

    export default class CardHipotesis extends Vue {

        @Prop(Object) propHip!:any;

        selection: any = null;
        sortedCorridas: Array<any> = null;
        sliderCurrentPage: Number = 1;

        @Watch('propHip')
        propHipChange() {
            this.selectionComputed = this.propHip;
//            this.$refs.slider.setPage(1);
        }

        get selectionComputed() {
            return this.selection;
        }

        set selectionComputed(value) {
            this.sortedCorridasComputed = value.hipotesisCorridas.sort((x, y) => (x.idCorrida >= y.idCorrida));
            this.selection = value;
        }

        get sortedCorridasComputed(){
            return this.sortedCorridas;
        }


        set sortedCorridasComputed(value){
            this.sortedCorridas = value;

        }

        sortSelectionComputedHipotesisCorridas(value){
            return value.hipotesisCorridas.sort((x, y) => (x.idCorrida >= y.idCorrida))
        }

        periodoUltCorrida(hipotesisCorrida) {
            return hipotesisCorrida.nPeriodoDesde + " - " + hipotesisCorrida.nPeriodoHasta;
        }

        async beforeMount() {
            this.selection = this.propHip;
        }

        updateCurrentPage(currentPage, el) {
            this.sliderCurrentPage = currentPage;
        }
    }

</script>
<style>
    .tileContent {
        font-weight: bold;
    }

    .slider {
        /*height: 400px;*/
        height: 280px;
        width: 100%;
    }

    .sizeCard {
        height: 280px;
    }

    .display-inline-flex {
        display: inline-flex;
    }

</style>