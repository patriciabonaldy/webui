<template>
    <v-card style="height: 100%">
        <h3 style="padding-top: 16px; padding-left: 16px">Historico de Corridas</h3>
        <v-container text-xs-center style="padding: 0">
            <v-spacer></v-spacer>
            <v-container grid-list-xl v-if="rowsComputed != null" style="padding: 0">
                <v-data-table :headers="headers" :items="rowsComputed" :loading="rowsComputed == null" align="center" class="text-xs-center tabla-padding0" >
                    <v-progress-linear slot="progress" color="blue" indeterminate></v-progress-linear>
                    <template slot="no-data">
                        <div v-if="rowsComputed != null && rowsComputed.length == 0">No hay resultados :(</div>
                    </template>
                    <template slot="items" slot-scope="props">
                        <td v-for="(msg,i) in props.item" :key="i" style="text-align: left;">{{msg}}</td>
                    </template>
                </v-data-table>
            </v-container>
        </v-container>
    </v-card>
</template>

<script lang="ts">
    import {Component, Prop, Watch, Vue} from 'vue-property-decorator';
    import {namespace} from 'vuex-class';
    import {formatPrice} from '@/helpers';

    const store = namespace('SeleccionarStore');

    @Component({
        components: {}
    })

    export default class HistoricoHipotesis extends Vue {
        @store.State('hipotesisSeleccionada') h: any;

        rows: Array<any> = [];
        headers: Array<any> = [
            {text: 'Número Corrida', value: 'idCorrida', sortable: true},
            {text: 'Impuesto', value: 'idImpuesto', sortable: true},
            {text: 'Cantidad de Registros', value: 'nCantReg', sortable: true},
            {text: 'Ajuste Potencial', value: 'iAjustePotencial', sortable: false},
            {text: 'Periodo Desde', value: 'nPeriodoDesde', sortable: true},
            {text: 'Periodo Hasta', value: 'nPeriodoHasta', sortable: true},
            {text: 'Fecha Ejecucion', value: 'fechaEjecucion', sortable: true}

        ];

        hipotesisCorridas(){
            return this.h.hipotesisCorridas;
        }

        get rowsComputed(){
            //DEEP CLONE del array de corridas para que el formateo no me pise los datos originales.
            let corridas = JSON.parse(JSON.stringify(this.h.hipotesisCorridas));
            let array = [];
            corridas.forEach(row => {  
                let fecha = row.nPeriodoHasta;      
                fecha = fecha.toString().substring(4,6)=='00'?fecha.toString().substring(0,4)+'12':fecha;  
                row.nPeriodoHasta= fecha;      
                const hip = {
                        idCorrida: 0,
                        idImpuesto: 0,
                        nCantReg: 0,
                        iAjustePotencial: '',
                        nPeriodoDesde: '',
                        nPeriodoHasta: '',
                        fechaEjecucion: 0,
                    };
                this.headers.forEach(hd => {
                    switch (hd.value) {
                        case 'idCorrida':
                            hip.idCorrida = Number(row[hd.value]);    
                        case 'idImpuesto':
                            hip.idImpuesto = Number(row[hd.value]);    
                        case 'nCantReg':
                            hip.nCantReg = Number(row[hd.value]);    
                        case 'iAjustePotencial':
                            hip.iAjustePotencial = formatPrice(row[hd.value]);
                        case 'nPeriodoDesde':
                            hip.nPeriodoDesde = row[hd.value];
                        case 'nPeriodoHasta':
                            hip.nPeriodoHasta = row[hd.value];
                        case 'fechaEjecucion':                            
                            hip.fechaEjecucion =row[hd.value];                        
                        default:
                            break;
                    }        
                });
                array.push(hip);
            });

            return array;            
        }

        set rowsComputed(value){
            this.rows = value;
        }

    }

</script>
<style>
    table.v-table thead th:not(:first-child) {
        padding: 0;
    }
</style>