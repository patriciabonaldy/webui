<template>
    <v-card  style="height: 100%">
        <v-container class="filtros text-xs-center">
            <h3 style="text-align: left; padding-top: 16px; padding-left: 16px">Nueva Corrida</h3>
             <!--<v-spacer></v-spacer>-->
            <!--span class="title text-capitalize ">Periodo de la Hipotesis</span-->
            <v-card-text>
                <v-container grid-list-md>
                    <v-layout wrap style="align-items: center">
                        <v-flex xs12 sm3>
                            <v-switch :label="`Tipo periodo: ${tipoPeriodo ? 'Fiscal' : 'Calendario'}`" v-model="tipoPeriodo"></v-switch>
                        </v-flex>
                        <v-flex xs12 sm3>
                            <v-menu v-if="!tipoPeriodo" key="periodoDesde" :close-on-click="false" :close-on-content-click="false" v-model="menuPeriodoDesde" :nudge-right="40" transition="scale-transition" offset-y full-width min-width="290px">
                                <v-text-field slot="activator" v-model="periodoDesde" label="Seleccione periodo desde" prepend-icon="event" readonly></v-text-field>
                                <v-date-picker locale="es-ES" v-model="periodoDesde" type="month" no-title @input="menuPeriodoDesde = false" data-vv-name="Periodo desde" name="periodoDesde" v-validate="'required'"></v-date-picker>
                            </v-menu>
                            <v-select v-else :items="anios" v-validate="'required'" name="anualDesde" key="anualDesde" data-vv-name="Periodo desde" v-model="periodoDesde" label="Periodo desde"></v-select>
                        </v-flex>
                        <v-flex xs12 sm3>
                            <v-menu v-if="!tipoPeriodo" key="periodoHasta" :close-on-click="false" :close-on-content-click="false" v-model="menuPeriodoHasta" :nudge-right="40" transition="scale-transition" offset-y full-width min-width="290px">
                                <v-text-field slot="activator" v-model="periodoHasta" label="Seleccione periodo hasta" prepend-icon="event" readonly></v-text-field>
                                <v-date-picker locale="es-ES" v-model="periodoHasta" type="month" no-title @input="menuPeriodoHasta = false" data-vv-name="Periodo hasta" name="periodoHasta" v-validate="'required'"></v-date-picker>
                            </v-menu>
                            <v-select v-else :items="anios" v-validate="'required'" name="anualHasta" key="anualHasta" data-vv-name="Periodo hasta" v-model="periodoHasta" label="Periodo hasta"></v-select>
                        </v-flex>
                        <v-btn xs12 sm3 color="success text-capitalize" dark @click="savePeriodo">Ejecutar</v-btn>
                    </v-layout>
                </v-container>
            </v-card-text>       
        </v-container>
     </v-card>   
</template>

<script lang="ts">

    import {Component, Prop, Watch, Vue} from 'vue-property-decorator';
    import {namespace} from 'vuex-class';
    import {buscarKeyEnMap} from '@/helpers';

    const store = namespace('SeleccionarStore');

    @Component({
        components: {}
    })
    export default class FiltrosHipotesis extends Vue {

        @store.State('tipoPeriodoSeleccionado') tipoPeriodoSeleccionado: string;
        @store.State('periodoDesdeSeleccionado') periodoDesdeSeleccionado: string;
        @store.State('periodoHastaSeleccionado') periodoHastaSeleccionado: string;
        @store.State('hipotesisSeleccionada') hipotesisSeleccionada: any;
        @store.State('impuestos') impuestos: Array<any>;

        @store.Mutation('SET_TIPO_PERIODO') SET_TIPO_PERIODO: Function;
        @store.Mutation('SET_PERIODO_DESDE') SET_PERIODO_DESDE: Function;
        @store.Mutation('SET_PERIODO_HASTA') SET_PERIODO_HASTA: Function;
        @store.Mutation('SET_SHOW_HIPOTESIS_SPINNER') SET_SHOW_HIPOTESIS_SPINNER: Function;
        @store.Mutation('SET_NOTIFICACION') SET_NOTIFICACION: Function;
        @store.Mutation('CLEAN_PERIODO') CLEAN_PERIODO: Function;

        @store.Action('getAllHipotesis') getAllHipotesis: Function;
        @store.Action('getMisHipotesis') getMisHipotesis: Function;
        @store.Action('saveHipotesisCorrida') saveHipotesisCorrida: Function;



        menuPeriodoDesde: boolean = false;
        menuPeriodoHasta: boolean = false;
        anios: Array<string> = [];

        beforeMount() {
            let esteanio = new Date().getUTCFullYear();
            this.anios = [];
            for (let x = esteanio; x >= 1980; x--)
                this.anios.push(x.toString());
        }

        get tipoPeriodo() {
            return this.tipoPeriodoSeleccionado == 'F';
        }

        set tipoPeriodo(value) {
            this.SET_PERIODO_DESDE(null);
            this.SET_PERIODO_HASTA(null);
            value ? this.SET_TIPO_PERIODO('F') : this.SET_TIPO_PERIODO('C');
            this.menuPeriodoDesde = false;
            this.menuPeriodoHasta = false;
        }

        get periodoDesde() {
            return this.periodoDesdeSeleccionado;
        }

        set periodoDesde(value) {
            if (this.tipoPeriodo) {
                this.SET_PERIODO_DESDE(value.toString());
            }
            else {
                let [year, month] = value.split('-');
                this.SET_PERIODO_DESDE(year.toString() + month.toString());
            }
        }

        get periodoHasta() {
            return this.periodoHastaSeleccionado;
        }

        set periodoHasta(value) {
            if (this.tipoPeriodo) {
                this.SET_PERIODO_HASTA(value.toString());
            }
            else {
                let [year, month] = value.split('-');
                this.SET_PERIODO_HASTA(year.toString() + month.toString());
            }
        }


        isValidoImpuestoSeleccionado(v){
            let x = this.impuestos.filter(impuesto => impuesto.codigo==v)[0];
            
            if(x!= undefined){
                if(!(x.perVto=='A' && this.tipoPeriodoSeleccionado=='C')){
                    return x;
                }               
            } 
            return undefined;
        }

        savePeriodo() {
            let idImpuesto = this.hipotesisSeleccionada.idImpuesto;
            if (!this.periodoDesde || !this.periodoHasta) {
                this.SET_NOTIFICACION({
                    titulo: "Error",
                    color: "red",
                    mensaje: "Los campos Periodo son obligatorio",
                    goToHome: false,
                    goToCampana: false
                });
            } else if (this.periodoDesdeSeleccionado > this.periodoHastaSeleccionado) {
                this.SET_NOTIFICACION({
                    titulo: "Error",
                    color: "red",
                    mensaje: "El periodo desde no puede ser mayor al periodo hasta",
                    goToHome: false,
                    goToCampana: false
                });
            } else if(this.isValidoImpuestoSeleccionado(idImpuesto)== undefined){
                this.SET_NOTIFICACION({
                    titulo: "Error",
                    color: "red",
                    mensaje: "El tipo de periodo seleccionado no es compatible con el Impuesto",
                    goToHome: false,
                    goToCampana: false
                });
            }    else {
                this.SET_SHOW_HIPOTESIS_SPINNER(true);

                this.saveHipotesisCorrida(this.hipotesisSeleccionada.idHipotesis)
                    .then(() => {
                        this.SET_SHOW_HIPOTESIS_SPINNER(false);
                        this.CLEAN_PERIODO();
                        this.SET_NOTIFICACION({
                            titulo: "Corrida",
                            color: "green",
                            mensaje: "Corrida programada con exito",
                            goToHome: false,
                            goToCampana: false
                        });


                        let loadingMisHipotesis = true;
                        let loadingAllHipotesis = true;
                        this.SET_SHOW_HIPOTESIS_SPINNER(loadingAllHipotesis && loadingMisHipotesis);

                        this.getMisHipotesis().then((x) => {
                            loadingMisHipotesis = false;
                            this.SET_SHOW_HIPOTESIS_SPINNER(loadingAllHipotesis && loadingMisHipotesis);
                        });

                        this.getAllHipotesis().then((x) => {
                            loadingAllHipotesis = false;
                            this.SET_SHOW_HIPOTESIS_SPINNER(loadingAllHipotesis && loadingMisHipotesis);
                        });
                    });

            }


        }
    }
</script>

<style>
    .btnRunHip {
        margin-left: 514px;
        margin-top: -100px;
    }

    .filtros {
        padding: 0px;
    }

</style>