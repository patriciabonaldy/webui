<template>
    <v-layout row wrap>
        <v-container grid-list-xl>
            <v-layout row wrap>
                <h3>Mis hipótesis</h3>
                <OwnerHip :hipotesis="myHipotesisComputed"></OwnerHip>
            </v-layout>
        </v-container>
        <v-container grid-list-xl>
            <v-layout row wrap>
                <h3>Hipótesis Compartidas</h3>
                <OwnerHip :hipotesis="hipotesisComputed"></OwnerHip>
            </v-layout>
        </v-container>
    </v-layout>
</template>
<script lang="ts">
    import {Component, Prop, Vue, Watch} from 'vue-property-decorator';
    import {namespace} from 'vuex-class';
    import OwnerHip from '@/components/Hipotesis/OwnerHip.vue';
    import {buscarHipotesisEnMap} from '../../helpers';

    @Component({
        components: {
            OwnerHip
        }
    })
    export default class CarouselHip extends Vue {
        @Prop(String) keyHip: String;
        @Prop(Array) hipotesis: Array<any>;
        @Prop(Array) misHipotesis: Array<any>;

        myHipotesis: Array<any> = [];
        allHipotesis: Array<any> = [];

        @Watch('hipotesis')
        reloadHipotesis() {
            this.hipotesisComputed = this.getOthersCards();
        }

        @Watch('misHipotesis')
        reloadMisHipotesis() {
            this.myHipotesis = this.getCards();
        }

    
        beforeMount() {
            this.myHipotesis = this.getCards();
            this.hipotesis = this.getOthersCards();
        }

        get myHipotesisComputed() {
            return this.myHipotesis;
        }

        set myHipotesisComputed(value) {
            this.myHipotesis = value;
        }

        get hipotesisComputed() {
            return this.allHipotesis;
        }

        set hipotesisComputed(value) {
            this.allHipotesis = value;
        }

        @Watch('keyHip')
        async keyHipChange(val: string, oldVal: string) {
            this.myHipotesisComputed = await this.getCards();
            this.hipotesisComputed = this.getOthersCards();
        }

        getCards() {
            if (this.keyHip != '' && this.keyHip) {
                let buscarHipotesiEnMap = buscarHipotesisEnMap(this.keyHip, this.misHipotesis);
                return buscarHipotesiEnMap;
            }

            return this.misHipotesis;
        }

        getOthersCards() {
            if (this.keyHip != '' && this.keyHip) {
                return buscarHipotesisEnMap(this.keyHip, this.hipotesis);
            }

            return this.hipotesis;
        }
    }

</script>
<style>
    .mdc-card {
        background: #fff;
        -webkit-box-shadow: 0 1px 6px -1px rgba(0, 0, 0, 0.15);
        -moz-box-shadow: 0 1px 6px -1px rgba(0, 0, 0, 0.15);
        box-shadow: 0 1px 6px -1px rgba(0, 0, 0, 0.15);
    }

    .mdc--tile.mdc--tile-danger {
        background: #e53a36;
        -webkit-box-shadow: 0px 9px 19px -9px rgba(229, 58, 54, 0.65);
        -moz-box-shadow: 0px 9px 19px -9px rgba(229, 58, 54, 0.65);
        box-shadow: 0px 9px 19px -9px rgba(229, 58, 54, 0.65);
    }

    .mdc--tile.mdc--tile-success {
        background: #4ca74f;
        -webkit-box-shadow: 0px 9px 19px -9px rgba(76, 167, 79, 0.65);
        -moz-box-shadow: 0px 9px 19px -9px rgba(76, 167, 79, 0.65);
        box-shadow: 0px 9px 19px -9px rgba(76, 167, 79, 0.65);
    }

    .mdc--tile.mdc--tile-warning {
        background: #fea11d;
        -webkit-box-shadow: 0px 9px 19px -9px rgba(254, 161, 29, 0.65);
        -moz-box-shadow: 0px 9px 19px -9px rgba(254, 161, 29, 0.65);
        box-shadow: 0px 9px 19px -9px rgba(254, 161, 29, 0.65);
    }

    .mdc--tile.mdc--tile-primary {
        background: #11b2c6;
        -webkit-box-shadow: 0px 9px 19px -9px rgba(17, 178, 198, 0.65);
        -moz-box-shadow: 0px 9px 19px -9px rgba(17, 178, 198, 0.65);
        box-shadow: 0px 9px 19px -9px rgba(17, 178, 198, 0.65);
    }

    .mdc--tile {
        width: 86px;
        height: 86px;
        display: -webkit-flex;
        display: flex;
        -webkit-align-items: center;
        align-items: center;
        -webkit-justify-content: center;
        justify-content: center;
    }

    .rounded {
        -webkit-border-radius: 3px;
        -moz-border-radius: 3px;
        -ms-border-radius: 3px;
        -o-border-radius: 3px;
        border-radius: 3px;
    }

</style>