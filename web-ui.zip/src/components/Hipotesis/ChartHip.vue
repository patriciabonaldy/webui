<template>
    <v-card style="height: 100%;">
        <GChart class="overlay" v-if="hipotesisSeleccionada" :resizeDebounce="0" 
                type="LineChart" :data="corridasData" 
                :options="chartOptionsComputed "/>
        <span v-if="corridasData.length <= 1">No hay corridas</span>
    </v-card>
</template>
<script lang="ts">
    import {Component, Prop, Vue, Watch} from 'vue-property-decorator';
    import {namespace} from 'vuex-class';
    import {GChart} from 'vue-google-charts'

    const store = namespace('SeleccionarStore');

    @Component({
        components: {
            GChart
        }
    })


    export default class ChartHip extends Vue {
        @store.State('hipotesisSeleccionada') hipotesisSeleccionadaState: any;

        get chartOptionsComputed() {
            return {
                width: 800,
                height: 400,
                series: {
                    0: {targetAxisIndex: 0},
                    1: {targetAxisIndex: 1}
                },
                vAxes: {
                    // Adds titles to each axis.
                    0: {title: 'Cantidad de casos (Universo)'},
                    1: {title: 'Monto en pesos (Ajuste)'}
                },
            };
        }

        set chartOptionsComputed(value) {

        }

        get hipotesisSeleccionada() {
            return this.hipotesisSeleccionadaState;
        }

        set hipotesisSeleccionada(value) {
            this.hipotesisSeleccionadaState = value;
        }

        get corridasData() {
            return [['Periodo', 'Universo', 'Ajuste']].concat(
                this.hipotesisSeleccionada.hipotesisCorridas.map(corrida => {
                    return [corrida.nPeriodoDesde + "-" + corrida.nPeriodoHasta, Number(corrida.nCantReg), Number(corrida.iAjustePotencial)]
                })
            )
        }

        set corridasData(value) {

        }


    }

</script>

<style>
    .chart {
        width: 100%;
        min-height: 500px;
        left: 80px;
    }

    .row {
        margin: 0 !important;
    }

    .overlay {
        position: absolute;
        top: 60px;   /* chartArea top  */
        left: 90px; /* chartArea left */
    }
</style>