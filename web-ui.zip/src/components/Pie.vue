<template>
    <v-footer fixed color="blue darken-4" dark app>
        <div> Usuario: {{ usuario }}</div>
        <v-spacer/>
        <div> Fecha: {{ fecha }}</div>
    </v-footer>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';

@Component
export default class Pie extends Vue {
    fecha : string = '';
    usuario: string = this.$store.state.CommonStore.usuario;

    async created(){
        this.setFecha();
        setInterval(this.setFecha,60000); //cada 10 minutos, cambia la fecha si es otro dia
    }
    async setFecha(){
        let hoy = new Date();
        this.fecha =  hoy.getDate().toString() + '/' + (hoy.getMonth()+1).toString() + '/' + hoy.getFullYear().toString() + ' ' + hoy.getHours().toString() + ':' + hoy.getMinutes().toString();
    }
}
</script>