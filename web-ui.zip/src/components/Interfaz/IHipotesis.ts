interface IHipotesis {
    idCorrida: number;
    idImpuesto: number;
    nCantReg: number;
    iAjustePotencial: string;
    nPeriodoDesde: string;
    nPeriodoHasta: string;
    fechaEjecucion: number;
}
