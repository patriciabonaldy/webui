import store from '@/store'


export class CloneState {
    states: Array<any> =[];
    idx: number = 0;

    constructor(){
        this.states.push({});
    }    
    
    getState(idx){
        return this.states[idx];
    }

    getIdx(){
        return this.idx;
    }

    getLenghtState(){
        return this.states.length-1;
    }

    addState(state: Object){
        this.states.push(JSON.parse(JSON.stringify(state)));
        this.idx = this.states.length-1;
    } 

    recoveryState(idx,tipo){
        let object = JSON.parse(JSON.stringify(this.states[idx]));        
        this.idx = idx;
        object.changeState = tipo;
        store.dispatch('SeleccionarStore/setState', object);
    }

    undo(tipo){
        this.recoveryState(this.idx-1,tipo);
    }

    redo(tipo){
        this.recoveryState(this.idx+1,tipo);
    }
} 