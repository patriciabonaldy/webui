<template>
  <v-toolbar color="primary" dense fixed clippedLeft dark app class="header-content" style="padding-left: 0px important!">
    <div class="row">
      <v-toolbar-title style="margin-top: 10px;">
        <span data-toggle="tooltip" :title="versiones">FISCAR</span>      
      </v-toolbar-title>
      <p class="font-italic overline" style="font-size: 9px;">{{descVersiones}}</p>
    </div>
   
    
    <v-divider class="mx-3" inset  vertical ></v-divider>
    <span class="subheading">Data Explorer</span>
    <v-spacer></v-spacer>
    <v-toolbar-items dark>
      <v-divider vertical></v-divider>
      <v-btn ripple small to="/Seleccionar" flat><v-icon>fas fa-table</v-icon>&nbsp;&nbsp;Seleccionar</v-btn>
      <v-divider vertical></v-divider>
      <v-btn ripple small to="/Hipotesis" flat><v-icon>fas fa-h-square</v-icon>&nbsp;&nbsp;Hipotesis</v-btn>
      <v-divider vertical></v-divider>
      <v-btn ripple small to="/Ventanilla" flat><v-icon>fas fa-envelope-open-text</v-icon>&nbsp;&nbsp;Campañas</v-btn>
      <v-divider vertical></v-divider>
      <v-btn ripple small to="/Boards" flat><v-icon>fas fa-chart-line</v-icon>&nbsp;&nbsp;Boards</v-btn>
      <v-divider vertical></v-divider>
      <v-btn @click="logoutLocal()" ripple small flat><v-icon>fas fa-power-off</v-icon>&nbsp;&nbsp;Salir</v-btn>
    </v-toolbar-items>
  </v-toolbar>
</template>

<script lang="ts">
import { Component, Watch,Vue } from 'vue-property-decorator';
import {namespace} from 'vuex-class';

const store = namespace('SeleccionarStore');

@Component
export default class MenuSuperior extends Vue {
    @store.Action('logout') logout: Function;
    @store.State('versionUI') versionUI: String;
    @store.State('versionMddw') versionMddw: String;
    @store.State('versionApi') versionApi: String;
    @store.Action('getVersionMddw') getVersionMddw: Function;
    @store.Action('getVersionApi') getVersionApi: Function;

    randy: number = Math.floor(Math.random() * (85 - 3)) + 1;
    vers_webUI: String ="WEB_UI: ";
    vers_MDW: String ="MDW: ";
    vers_Api: String ="API: ";
    versiones: String ="";
    descVersiones: String ="";

    on: Boolean=true;
    
    beforeMount() {
      this.vers_webUI=  `${this.vers_webUI}${this.versionUI} `;
      this.getVersionMddw();
      this.getVersionApi();
    }

    @Watch('versionApi')
    updateVersiones(val, oldVal) {
      this.vers_MDW = `${this.vers_MDW}${this.versionMddw} `;
      this.vers_Api = `${this.vers_Api}${this.versionApi} `;
      this.versiones =  `${this.vers_webUI}\n${this.vers_MDW}\n${this.vers_Api}`;
      this.descVersiones =  `${this.versionUI}@${this.versionMddw}@${this.versionApi}`;
    }

    logoutLocal(){
        this.logout();
    }
}
</script>

<style>
.avatar-img {
    border-radius: 50%;
    display: -webkit-inline-box;
    display: -ms-inline-flexbox;
    display: inline-flex;
    height: 50px;
    width: 50px;
}
.header-content {  
  left: 0px;
  padding-left: 0px;
}

</style>