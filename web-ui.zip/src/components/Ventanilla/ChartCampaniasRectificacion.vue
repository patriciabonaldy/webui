<template>
  <GChart
    v-if="estadisticas"
    :settings="{packages: ['line']}"
    :data="chartData"
    :options="chartOptions"
    :createChart="(el, google) => new google.charts.Line(el)"
    @ready="onChartReady"
  />
</template>
<script lang="ts">
import { Component, Prop, Vue, Watch } from "vue-property-decorator";
import { namespace } from "vuex-class";
import { GChart } from "vue-google-charts";
import moment from "moment";

const store = namespace("SeleccionarStore");

@Component({
  components: {
    GChart
  }
})
export default class ChartCampaniasRectificacion extends Vue {
  @Prop(Object) estadisticas: any;
  @store.State("listadoCampanias") listadoCampanias: any;
  chartsLib;
  vchartData: any;
  //chartData;
  get chartOptionsComputed() {
    return {
      width: 800,
      height: 400,
      series: {
        0: { targetAxisIndex: 0 },
        1: { targetAxisIndex: 1 }
      },
      hAxes: {
        title: "Fecha"
      },
      vAxes: {
        title: "Cantidad"
      },
      legend: {
        position: "bottom",
        width: 100
      },
      colors: ["#6d14a5", "#097138", "#a52714"]
    };
  }
  set chartOptionsComputed(value) {}
  set chartOptions(value) {}
  set chartData(value) {}
  get chartOptions() {
    if (!this.chartsLib) return null;
    return this.chartsLib.charts.line.convertOptions({
      chart: {
        //title: "Company Performance",
        crosshair: {
          color: "#000",
          trigger: "selection"
        }
      }, // Required for Material Bar Charts.
      hAxis: { format: "date", title: "Fecha" },
      vAxis: {
        format: "number",
        title: "Cantidad"
      },
      height: 400,
      colors: ["#1b9e77", "#d95f02", "#7570b3"]
    });
  }
  onChartReady(chart, google) {
    this.chartsLib = google;
  }
  get chartData() {
    var rows: any = [["Fecha", "CantidadTotal", "Leidos", "Rectificados"]];
    for (const [key, value] of Object.entries(this.estadisticas)) {
      var valores = this.estadisticas[key];
      rows.push([
        moment(Number(key)).format("DD/MM/YYYY"),
        //new Date(Number(key)),
        Number(valores.cantidadTotal),
        Number(valores.countLeidos),
        Number(valores.cantidadPresentados)
      ]);
    }
    this.vchartData = rows;
    return this.vchartData;
  }
}
</script>

<style>
.chart {
  width: 100%;
  min-height: 500px;
  left: 80px;
}

.row {
  margin: 0 !important;
}

.overlay {
  position: absolute;
  top: 60px; /* chartArea top  */
  left: 90px; /* chartArea left */
}
</style>