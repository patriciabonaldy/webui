<template>
  <div
    class="col-sm-4 col-lg-4 col-md-4 item"
    :class="{'list-group-item': displayList}"
    style="width: 100%"
  >
    <v-container grid-list-md text-xs-left>
      <v-hover>
        <v-card
          slot-scope="{ hover }"
          :class="`elevation-${hover ? 12 : 2}`"
          style="height: 300px; width: 1150px; padding: 20px;"
        >
          <v-icon
            fab
            dark
            class="float-right"
            align-left
            text-xs-left
            size="20"
            :color="setColor(detailDFE.estadisticas)"
          >{{ setIcono() }}</v-icon>
          <v-layout row wrap align-center class="text-lg-left" style="height: 90%">
            <v-flex
              xs6
              row
              wrap
              align-center
              class="text-lg-left"
              style="border-right: 1px #1075a8 solid; height: 100%"
            >
              <v-layout row wrap class="text-lg-left pa-2">
                <v-flex xs6>
                  <v-layout row wrap class="text-lg-left">
                    <h1>{{ detailDFE.codCampania }}</h1>
                  </v-layout>
                  <div class="mt-2">
                    <strong>Asunto</strong>
                  </div>
                  <div class="grey--text text--darken-2">{{ detailDFE.asunto }}</div>
                  <div class="mt-2">
                    <strong>Fecha de Envio</strong>
                  </div>
                  <div class="grey--text text--darken-2">{{ detailDFE.fechaEnvio | formatDate2}}</div>
                </v-flex>

                <v-flex xs5>
                  <div>
                    <strong>Firmante</strong>
                  </div>
                  <div class="grey--text text--darken-2">{{ detailDFE.usuarioPub }}</div>
                  <div class="mt-2">
                    <strong>Area</strong>
                  </div>
                  <div class="grey--text text--darken-2">{{ detailDFE.areaUsuarioPub }}</div>
                  <div class="mt-2">
                    <strong>Cargo</strong>
                  </div>
                  <div class="grey--text text--darken-2">{{ detailDFE.cargoUsuarioPub }}</div>
                  <div class="text-md-center">
                    <v-btn ripple large flat @click="mostrarCarta()">
                      <v-icon>fas fa-envelope-open-text</v-icon>&nbsp;&nbsp;Ver carta
                    </v-btn>
                  </div>
                </v-flex>
              </v-layout>
            </v-flex>
            <v-flex xs1 row wrap align-center class="text-md-center pa-2" style="height: 100%">
              <div class="mt-1">
                <strong>Tamaño de universo</strong>
              </div>
              <h4 class="grey--text text--darken-2">{{ detailDFE.estadisticas.cantidadTotal }}</h4>
              <div class="mt-2">
                <strong>Leidos</strong>
              </div>
              <h4 class="grey--text text--darken-2">{{ detailDFE.estadisticas.countLeidos }}</h4>
              <div class="mt-2">
                <strong>No leidos</strong>
              </div>
              <h4 class="grey--text text--darken-2">{{ detailDFE.estadisticas.countNoLeidos }}</h4>
              <div class="mt-2">
                <strong>En Error</strong>
              </div>
              <h4
                class="grey--text text--darken-2"
              >{{ detailDFE.estadisticas.countErroneas>0?detailDFE.estadisticas.countErroneas:0 }}</h4>
            </v-flex>

            <!--v-flex-- xs4>
              <GChart
                :resizeDebounce="0"
                type="PieChart"
                :data="chartData()"
                :options="chartOptions()"
              />
            </!--v-flex-->
            <v-flex xs5>
              <ChartCampaniasRectificacion
                v-if="JSON.stringify(detailDFE.estadisticasByFecha) != '{}'"
                :estadisticas="detailDFE.estadisticasByFecha"
              />
              <span v-else>No hay corridas para graficar</span>
            </v-flex>
          </v-layout>
        </v-card>
      </v-hover>
    </v-container>
    <v-dialog v-if="showCartaComputed" v-model="showCartaComputed" width="600px">
      <Carta></Carta>
    </v-dialog>
  </div>
</template>
<script lang="ts">
import { Component, Prop, Watch, Vue } from "vue-property-decorator";
import { namespace } from "vuex-class";
import { GChart } from "vue-google-charts";
import Carta from "@/components/Ventanilla/Carta.vue";
import ChartCampaniasRectificacion from "@/components/Ventanilla/ChartCampaniasRectificacion.vue";
import {
  getIcon,
  getColorEstado,
  getIdUltimaCorrida,
  getDescEstado
} from "@/helpers";

const store = namespace("SeleccionarStore");

@Component({
  components: {
    GChart,
    Carta,
    ChartCampaniasRectificacion
  }
})
export default class CardVentanilla extends Vue {
  @store.Mutation("SET_CARTA") SET_CARTA: Function;
  @store.Mutation("CLEAR_CARTA") CLEAR_CARTA: Function;
  @store.Mutation("SET_SHOW_CARTA") SET_SHOW_CARTA: Function;
  @store.State("showCarta") showCarta: boolean;

  @Prop(Object) detailDFE: any;
  @Prop(Boolean) displayList;
  showDialog: Boolean = false;

  chartData() {
    return [
      ["Estado", "Cantidad"],
      ["Leidos", this.detailDFE.estadisticas.countLeidos],
      ["No leidos", this.detailDFE.estadisticas.countNoLeidos]
    ];
  }

  mostrarCarta() {
    this.SET_CARTA({
      encabezado: this.detailDFE.carta.encabezado,
      primerParrafo: this.detailDFE.carta.primerParrafo,
      segundoParrafo: this.detailDFE.carta.segundoParrafo,
      firmante: this.detailDFE.usuarioPub,
      cargo: this.detailDFE.cargoUsuarioPub,
      area: this.detailDFE.areaUsuarioPub
    });
    this.showCartaComputed = true;
  }

  chartOptions() {
    return {
      height: 250,
      width: 250,
      sliceVisibilityThreshold: 0,
      slices: {
        0: { color: "green" },
        1: { color: "blue" }
      }
    };
  }

  get showCartaComputed() {
    return this.showCarta;
  }

  set showCartaComputed(value) {
    this.SET_SHOW_CARTA(value);
  }

  setColor(estadisticas) {
    let value = estadisticas.countPendientes;
    let estado = "";

    if (estadisticas.countErroneas > 0) {
      estado = "ER";
    } else {
      if (value >= 0) {
        estado = "PE";
      } else {
        estado = "PR";
      }
    }

    return getColorEstado(estado);
  }

  setIcono() {
    return getIcon("detail");
  }
}
</script>
<style>
.theme--light.v-divider {
  border-color: rgb(250, 250, 250);
}

div.thumbnail {
  height: 100%;
}

.favourite-icon {
  font-size: 25px;
}

.ratings {
  padding-right: 10px;
  padding-left: 10px;
  color: #d17581;
}

.grow {
  transition: all 0.2s ease-in-out;
}

.thumbnail:hover .grow {
  transform: scale(1.1);
}

.item.list-group-item {
  border: none;
  float: none;
  width: 100%;
  background-color: #fafafa;
  margin-bottom: 10px;
}

.thumbnail-image {
  padding: 15px;
}

.list-group-item .thumbnail-image {
  margin-right: 10px;
  max-height: 150px;
}

.item.list-group-item .thumbnail {
  margin-bottom: 0px;
}

.item.list-group-item img {
  float: left;
}

.item.list-group-item:after {
  clear: both;
}

.chart {
  width: 100%;
  min-height: 250px;
  left: 0px;
  width: 250px;
}
</style>