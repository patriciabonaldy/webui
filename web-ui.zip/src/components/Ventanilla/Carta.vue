<template>
    <v-layout row >
        <v-card>
            <v-layout align-center justify-center row>
                <v-container grid-list-xl text-xs-center>
                    <span class="headline ">{{encabezado}}</span>
                </v-container>
                <v-layout class="mr-3 mt-3">
                    <v-icon color="grey darken-1" @click="SET_SHOW_CARTA(false)">close</v-icon>
                </v-layout>
            </v-layout>
            <v-card-text>{{primerParrafo}}</v-card-text>
            <v-card-text>{{segundoParrafo}}</v-card-text>
            <v-container class="pa-3" grid-list-xl text-xs-center>
                <v-spacer></v-spacer>
                <div>______________________________________</div>
                <div>{{firmante}}</div>
                <div>{{cargo}}</div>
                <div>{{area}}</div>
            </v-container>
        </v-card>
    </v-layout>
</template>

<script lang="ts">
    import {Component, Prop, Watch, Vue} from 'vue-property-decorator';
    import {namespace} from 'vuex-class';

    const store = namespace('SeleccionarStore');

    @Component({})
    export default class Carta extends Vue {
        @store.State('cartaEncabezado')     encabezado: string;
        @store.State('cartaPrimerParrafo')  primerParrafo: string;
        @store.State('cartaSegundoParrafo') segundoParrafo: string;
        @store.State('firmante') firmante: string;
        @store.State('cargo')       cargo: string;
        @store.State('area')         area: string;
        @store.Mutation('SET_SHOW_CARTA') SET_SHOW_CARTA: boolean;
    }
</script>