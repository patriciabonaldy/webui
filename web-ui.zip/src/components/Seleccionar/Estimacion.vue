<template>
    <div class="text-xs-center">
        <v-dialog persistent v-model="dialog" width="500">
            <v-card>
                <v-card-title class="headline primary white--text" primary-title>
                    Estimacion de consulta
                </v-card-title>
                <v-card-text style="text-align:center">
                    La consulta que usted desea realizar traera los siguientes resultados aproximadamente:
                    <br/>
                    <br/>
                    <div v-if="cantidad == null || ajuste == null ">
                        <beat-loader style="vertical-align: middle" color="lightgrey" size="0.5em"></beat-loader>
                        <div style="color:lightgrey;font-size:1.5em">&nbsp;Calculando estadisticas...</div>
                    </div>
                    <div v-else>
                        <b>Contribuyentes: {{setFormatNumber(cantidad)}}</b>
                        <br/>
                        <b>Ajuste total estimado: ${{setFormatPrice(ajuste)}}</b>
                        <br/>
                        <b>Minimo: {{setFormatPrice(minimoEstimado)}}</b>
                        <br/>
                        <b>Maximo: {{setFormatPrice(maximoEstimado)}}</b>
                        <br/>
                        <b>Promedio: {{setFormatPrice(promedioEstimado)}}</b>
                        <br/>
                        <b>Desvío Estándar: {{setFormatPrice(varianceEstimado)}}</b>
                    </div>
                    <br/>
                    <br/>
                    ¿Desea ejecutar la consulta y visualizar una muestra del resultado?
                </v-card-text>
                <v-divider></v-divider>
                <v-card-actions>
                    <v-spacer></v-spacer>
                    <v-btn color="primary" :disabled="cantidad == null" @click="runQuery()">Ejecutar</v-btn>
                    <v-btn color="error" @click="closeit()">Cancelar</v-btn>
                </v-card-actions>
            </v-card>
        </v-dialog>
    </div>
</template>

<script lang="ts">
    import {
        Component,
        Prop,
        Vue
    } from 'vue-property-decorator';
    import {namespace} from 'vuex-class';    
    import BeatLoader from 'vue-spinner/src/BeatLoader.vue';
    import {
        formatPrice, formatNumber 
    } from '@/helpers';

    const store = namespace('SeleccionarStore');

    @Component({
        components: {
            BeatLoader
        }
    })
    export default class Estimacion extends Vue {
        dialog: boolean = true;


        @store.State('cantidadDeContribuyentes') cantidad: string;
        @store.State('ajusteEstimado') ajuste: string;
        @store.State('minimoEstimado') minimoEstimado: string;
        @store.State('maximoEstimado') maximoEstimado: string;
        @store.State('promedioEstimado') promedioEstimado: string;
        @store.State('varianceEstimado') varianceEstimado: string;

        setFormatPrice(value) {
            return formatPrice(value);
        }

        setFormatNumber(value) {
            return formatNumber(value);
        }

        closeit() {
            this.$emit('closeEstimacion');
            this.dialog = false;
        }

        runQuery() {
            this.$emit('runQuery');
            this.dialog = false;
        }
    }
</script>