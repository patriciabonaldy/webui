<template>
  <v-list dense>
    <v-list-tile v-if="cubos[0].children == null">
      <beat-loader style="vertical-align: middle" color="lightgrey" size="0.5em"></beat-loader>
      <span>
        <div style="color:lightgrey;font-size:1.5em">&nbsp;Cargando origenes</div>
      </span>
    </v-list-tile>
    <v-list-group v-else v-model="par" v-for="item in cubos" :key="item.id" no-action>
      <v-list-tile slot="activator">
        <v-list-tile-content>
          <v-list-tile-title>{{item.nombre}}</v-list-tile-title>
        </v-list-tile-content>
      </v-list-tile>
      <div v-for="(subItem,i) in item.children" :key="subItem.id">
        <v-hover>
          <v-list-tile
            ripple
            active-class="highlighted"
            slot-scope="{ hover }"
            :class="(hover ? 'transition-fast-in-fast-out primary darken-1 white--text elevation-1 ' : ' ') + (selected == i ? ' cyan darken-1 white--text elevation-1 ':' ')"
            :style="hover ? 'cursor:pointer':''"
            @click="setCubo(subItem,i)"
          >
            <v-list-tile-action>
              <v-icon
                small
                :class="(hover ? 'white--text ' : ' ')  + (selected == i ? ' blue darken-1 white--text elevation-1 ':' ')"
              >fas fa-database</v-icon>
            </v-list-tile-action>
            <v-list-tile-content v-if="subItem.nombre">
              <v-tooltip bottom>
                <v-list-tile-title
                  :class="`${hover ? 'white--text' : ''}`"
                  slot="activator"
                >{{ subItem.nombre }}</v-list-tile-title>
                <span>{{ subItem.id }}</span>
              </v-tooltip>
            </v-list-tile-content>

            <v-list-tile-content v-else>
              <span>{{ subItem.id }}</span>
            </v-list-tile-content>
          </v-list-tile>
        </v-hover>
      </div>
    </v-list-group>
  </v-list>
</template>

<script lang="ts">
import { Component, Vue, Watch } from "vue-property-decorator";
import { State, namespace } from "vuex-class";
import BeatLoader from "vue-spinner/src/BeatLoader.vue";

const store = namespace("SeleccionarStore");

@Component({
  components: {
    BeatLoader
  }
})
export default class SelectorCubo extends Vue {
  @store.Action("getCubos") getCubos: Function;
  @store.State("cubos") cubos: Array<any>;
  @store.State("cuboSeleccionado") cuboSeleccionado: any;

  @store.Action("getDimensiones") getDimensiones: Function;
  @store.Mutation("SET_DIMENSIONES") SET_DIMENSIONES: Function;

  par: boolean = true;
  selected: number = -1;
  //cubos;

  async beforeMount() {
    await this.getCubos();
  }

  @Watch("cubos")
  cubosChange() {
  }

  @Watch("cuboSeleccionado")
  cuboSeleccionadoChange(val: string, oldVal: string) {
    if (this.cuboSeleccionado) {
      this.par = false;
    } else {
      this.par = true;
    }
  }

  setCubo(cubo, index) {
    if (index == this.selected) {
      //deseleccionando
      this.selected = -1;
      this.SET_DIMENSIONES([]);
    } else {
      this.selected = index;
      this.getDimensiones(cubo);
    }
  }
}
</script>