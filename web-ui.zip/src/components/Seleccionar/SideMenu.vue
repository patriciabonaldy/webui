<template>
  <v-navigation-drawer app clipped light fixed permanent>
    <v-navigation-drawer>
      <v-layout column>
        <v-list-tile>
          <v-list-tile-content
            class="caption tileContent info--text text--darken-3"
          >Tipo de Periodo:</v-list-tile-content>
          <v-list-tile-content class="align-end caption text-capitalize">{{tipoPeriodo()}}</v-list-tile-content>
        </v-list-tile>
        <v-list-tile>
          <v-list-tile-content class="caption tileContent info--text text--darken-3">Periodo Desde:</v-list-tile-content>
          <v-list-tile-content class="align-end caption text-capitalize">{{periodoDesde()}}</v-list-tile-content>
        </v-list-tile>
        <v-list-tile>
          <v-list-tile-content class="caption tileContent info--text text--darken-3">Periodo Hasta:</v-list-tile-content>
          <v-list-tile-content class="align-end caption text-capitalize">{{periodoHasta()}}</v-list-tile-content>
        </v-list-tile>
        <v-btn small outline color="primary" @click="SHOW_PERIODO(true)">Modificar Periodo</v-btn>
      </v-layout>
      <SelectorCubo />
      <SelectorDimension v-if="cuboSeleccionado" />
    </v-navigation-drawer>
  </v-navigation-drawer>
</template>

<script lang="ts">
import { Component, Vue, Watch } from "vue-property-decorator";
import SelectorCubo from "@/components/Seleccionar/SelectorCubo.vue";
import SelectorDimension from "@/components/Seleccionar/SelectorDimension.vue";
import Notificacion from "@/components/Notificacion.vue";
import { namespace } from "vuex-class";

const store = namespace("SeleccionarStore");

@Component({
  components: {
    SelectorCubo,
    SelectorDimension,
    Notificacion
  }
})
export default class SideMenu extends Vue {
  @store.State("universo") universo: Object;
  @store.State("cuboSeleccionado") cuboSeleccionado: any;
  @store.State("tipoPeriodoSeleccionado") tipoPeriodoSeleccionado: string;
  @store.State("periodoDesdeSeleccionado") periodoDesdeSeleccionado: string;
  @store.State("periodoHastaSeleccionado") periodoHastaSeleccionado: string;

  @store.State("cubos") cubos: Array<any>;
  @store.Action("getDimensiones") getDimensiones: Function;

  @store.Mutation("SHOW_PERIODO") SHOW_PERIODO: Function;
  @store.Mutation("SHOW_CARATULA") SHOW_CARATULA: Function;
  @store.Mutation("SET_NOTIFICACION") SET_NOTIFICACION: Function;

  response: any = {};

  async beforeMount() {
    this.tipoPeriodo();
  }

  @Watch("tipoPeriodoSeleccionado")
  tipoPeriodo(): String {
    let tipo: String =
      this.tipoPeriodoSeleccionado == "F" ? "Fiscal" : "Calendario";
    return tipo;
  }

  @Watch("periodoDesdeSeleccionado")
  periodoDesde(): String {
    return this.periodoDesdeSeleccionado;
  }

  @Watch("periodoHastaSeleccionado")
  periodoHasta(): String {
    return this.periodoHastaSeleccionado;
  }

  async guardarHipotesis() {
    if (!this.universo.hasOwnProperty("columns")) {
      this.SET_NOTIFICACION({
        titulo: "Error",
        color: "red",
        mensaje: "Debe completar la selección para poder guardar la Hipotesis",
        goToHome: false,
        goToCampana: false
      });
    } else await this.SHOW_CARATULA(true);
  }

  goToHipotesis() {
    this.$router.push({
      name: "Hipotesis",
      params: { idCaratula: this.response.id }
    });
  }

  enviarAInduccion() {
    alert("Aun no implementado!");
  }
}
</script>
