<template>
  <div>
    <v-dialog v-model="show" persistent max-width="1000px">
      <v-card>
        <v-card-title>
          <span class="headline">Carta electr&oacute;nica</span>
        </v-card-title>
        <v-card-text>
          <v-container grid-list-md md-row-height="1:2">
            <v-layout wrap>
              <v-flex xs12 sm4 style="margin-bottom: -5px;">
                <v-text-field
                  v-model="codigoDeCampania"
                  name="codigoDeCampania"
                  clearable
                  label="Código de campaña"
                  type="text"
                  :rules="verify_Text"
                  v-validate="'required|max:255'"
                  required
                  :error-messages="errors.collect('codigoDeCampania')"
                ></v-text-field>
              </v-flex>
              <v-flex xs12 sm4 style="margin-bottom: -5px;">
                <v-combobox
                  class="my-input"
                  v-model="idSistemaEVentanilla"
                  :items="sistemasEventanilla"
                  data-vv-name="Sistema E-Ventanilla"
                  :loading="sistemasEventanilla == null"
                  name="idSistemaEventanilla"
                  item-value="codigo"
                  item-text="descripcion"
                  label="Tema (Id sistema de E-Ventanilla)"
                  v-validate="'required|verify_tipoVentanilla'"
                  :rules="verify_tipoVentanilla"
                  :error-messages="errors.collect('idSistemaEVentanilla')"
                  required
                ></v-combobox>
              </v-flex>

              <v-flex xs12 sm4 style="margin-bottom: -5px;">
                <v-combobox
                  class="my-input"
                  v-model="tipoDesvio"
                  :items="tiposDesvios"
                  :loading="tiposDesvios == null"
                  :disabled="tiposDesvios == null"
                  data-vv-name="TipoDesvio"
                  name="tipoDesvio"
                  item-value="codigo"
                  item-text="descripcion"
                  label="Tipo Desvio"
                  v-validate="'required|verify_desvio'"
                  :rules="verify_desvio"
                  :error-messages="errors.collect('tipoDesvio')"
                ></v-combobox>
              </v-flex>

              <v-flex xs12 sm8 style="margin-bottom: -5px;">
                <v-combobox
                  class="my-input"
                  v-model="formulario"
                  :items="formularios"
                  data-vv-name="Formulario"
                  :loading="formularios == null"
                  multiple
                  name="formulario"
                  item-value="codigo"
                  item-text="descripcion"
                  small-chips
                  deletable-chips
                  label="Formularios a Monitorear"
                  v-validate="'required|verify_formulario'"
                  :rules="verify_formulario"
                  :error-messages="errors.collect('formulario')"
                ></v-combobox>
              </v-flex>

              <v-flex xs12 sm4 style="margin-bottom: -5px;">
                <v-text-field
                  v-model="pdfNombre"
                  name="pdfNombre"
                  clearable
                  label="Nombre del archivo adjunto"
                  type="text"
                  :rules="verify_Text"
                  v-validate="{ rules: { regex:  /^((?!.(pdf|csv|xls|txt)).)*$/, max:100} }"
                  required
                  :error-messages="errors.collect('pdfNombre')"
                ></v-text-field>
              </v-flex>

              <v-flex sm12 style="margin-bottom: -5px;">
                <v-text-field
                  v-model="encabezadoCarta"
                  name="encabezadoCarta"
                  clearable
                  label="Asunto"
                  type="text"
                  :rules="verify_Text"
                  v-validate="'required|max:4000'"
                  required
                  :error-messages="errors.collect('encabezadoCarta')"
                ></v-text-field>
              </v-flex>
              <v-flex sm12 style="margin-bottom: -5px;">
                <v-textarea
                  v-model="primerParrafo"
                  :rows="2"
                  name="primerParrafo"
                  clearable
                  label="Primer Parrafo"
                  type="text"
                  :rules="verify_Text"
                  v-validate="'required|max:4000'"
                  required
                  :error-messages="errors.collect('primerParrafo')"
                ></v-textarea>
              </v-flex>
              <v-flex sm12 style="margin-bottom: -5px;">
                <v-textarea
                  v-model="segundoParrafo"
                  :rows="2"
                  name="segundoParrafo"
                  clearable
                  label="Segundo Parrafo"
                  type="text"
                  :rules="verify_Text"
                  v-validate="'required|max:4000'"
                  required
                  :error-messages="errors.collect('segundoParrafo')"
                ></v-textarea>
              </v-flex>

              <v-flex sm4 style="margin-bottom: -5px;">
                <v-text-field
                  v-model="nombreUsuario"
                  name="nombreUsuario"
                  clearable
                  label="Nombre usuario"
                  type="text"
                  :rules="verify_Text"
                  v-validate="'required|max:100'"
                  required
                  :error-messages="errors.collect('nombreUsuario')"
                ></v-text-field>
              </v-flex>
              <v-flex sm4 style="margin-bottom: -5px;">
                <v-text-field
                  v-model="cargoUsuario"
                  name="cargoUsuario"
                  clearable
                  label="Cargo usuario"
                  type="text"
                  :rules="verify_Text"
                  v-validate="'required|max:100'"
                  required
                  :error-messages="errors.collect('cargoUsuario')"
                ></v-text-field>
              </v-flex>
              <v-flex sm4 style="margin-bottom: -5px;">
                <v-text-field
                  v-model="areaUsuario"
                  name="areaUsuario"
                  clearable
                  label="Area usuario"
                  type="text"
                  :rules="verify_Text"
                  v-validate="'required|max:100'"
                  required
                  :error-messages="errors.collect('areaUsuario')"
                ></v-text-field>
              </v-flex>
            </v-layout>
          </v-container>
        </v-card-text>
        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn color="blue" dark @click="validateAndSaveEnviarDFE">Enviar a DFE</v-btn>
          <v-btn color="red" dark @click="closeEnviarDFE">Cancelar</v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
    <Notificacion
      v-if="mensaje != null"
      :color="color"
      :titulo="titulo"
      :mensaje="mensaje"
      @enviarDFE="enviarDFE"
      @closeAlertDFE="closeAlertDFE"
      @close="mensaje = null"
      :saveCampania="campania"
    />
  </div>
</template>

<script lang="ts">
import { Component, Vue, Watch } from "vue-property-decorator";
import VueRouter from "vue-router";
import { State, namespace } from "vuex-class";
import {
  buscarKeyEnMap,
  buscarListFormulariosEnMap,
  buscarCodDirEnImpuestoMap
} from "@/helpers";
import VeeValidate from "vee-validate";
import VueMask from "v-mask";
import Notificacion from "@/components/Notificacion.vue";
import Spinner from "@/components/Seleccionar/Spinner.vue";
import { Validator } from "vee-validate";

Vue.use(VeeValidate);
Vue.use(VueMask);

const store = namespace("SeleccionarStore");

@Component({
  components: {
    Notificacion,
    Spinner
  }
})
export default class EnviarDFE extends Vue {
  msj: string = null;
  titulo: string = null;
  color: string = "red";
  // Campos del formulario
  // Nombre Usuario
  @store.State("nombreUsuarioState") nombreUsuarioState: number;
  @store.State("saveCampania") saveCampania: boolean;
  @store.Mutation("SET_FULL_PATH") SET_FULL_PATH: Function;
  @store.Mutation("SET_NOMBRE_USUARIO") SET_NOMBRE_USUARIO: Function;
  @store.Mutation("SET_SAVE_CAMPANIA") SET_SAVE_CAMPANIA: Function;
  @store.Mutation("REMOVE_ALL_DIMENSIONES_SELECCIONADAS")
  REMOVE_ALL_DIMENSIONES_SELECCIONADAS: Function;
  @store.Mutation("CLEAN_PERIODO") CLEAN_PERIODO: Function;
  @store.Mutation("CLEAN_SELECCIONES_ENVIAR_DFE")
  CLEAN_SELECCIONES_ENVIAR_DFE: Function;

  @store.State("tiposDesvios") tiposDesvios: Array<any>;
  @store.State("tipoDesvioSeleccionado") tipoDesvioSeleccionado: number;
  @store.Action("getTiposDesvio") getTiposDesvio: Function;
  @store.Mutation("SET_TIPO_DESVIO") SET_TIPO_DESVIO: Function;

  @store.State("formularios") formularios: Array<any>;
  @store.State("formulariosSeleccionados") formulariosSeleccionados: any;
  @store.Action("getFormularios") getFormularios: Function;
  @store.Mutation("SET_FORMULARIOS_SELECCIONADOS")
  SET_FORMULARIOS_SELECCIONADOS: Function;

  @store.State("universo") universo: Object;

  get nombreUsuario() {
    return this.nombreUsuarioState;
  }

  set nombreUsuario(value) {
    this.SET_NOMBRE_USUARIO(value);
  }

  get campania() {
    return this.saveCampania;
  }

  set campania(value) {
    this.SET_SAVE_CAMPANIA(value);
  }

  get tipoDesvio() {
    return this.tipoDesvioSeleccionado;
  }

  set tipoDesvio(value) {
    this.SET_TIPO_DESVIO(value);
  }

  // Sistemas E-Ventanilla
  @store.State("sistemasEventanilla") sistemasEventanilla: Array<any>;
  @store.State("sistemaEventanillaSeleccionado")
  sistemaEventanillaSeleccionado: number;
  @store.Action("getSistemasEVentanilla") getSistemasEVentanilla: Function;
  @store.Mutation("SET_SISTEMA_EVENTANILLA_SELECCIONADO")
  SET_SISTEMA_EVENTANILLA_SELECCIONADO: Function;

  // Area Usuario
  @store.State("areaUsuarioState") areaUsuarioState: number;
  @store.Mutation("SET_AREA_USUARIO") SET_AREA_USUARIO: Function;

  get areaUsuario() {
    return this.areaUsuarioState;
  }

  set areaUsuario(value) {
    this.SET_AREA_USUARIO(value);
  }

  // Cargo Usuario
  @store.State("cargoUsuarioState") cargoUsuarioState: number;
  @store.Mutation("SET_CARGO_USUARIO") SET_CARGO_USUARIO: Function;

  get cargoUsuario() {
    return this.cargoUsuarioState;
  }

  set cargoUsuario(value) {
    this.SET_CARGO_USUARIO(value);
  }

  // Codigo campaña
  @store.State("codigoDeCampaniaSeleccionado")
  codigoDeCampaniaSeleccionado: number;
  @store.Mutation("SET_CODIGO_CAMPANIA") SET_CODIGO_CAMPANIA: Function;

  get codigoDeCampania() {
    return this.codigoDeCampaniaSeleccionado;
  }

  set codigoDeCampania(value) {
    this.SET_CODIGO_CAMPANIA(value);
  }

  // Id sistema E-Ventanilla
  @store.State("idSistemaEVentanillaSeleccionado")
  idSistemaEVentanillaSeleccionado: number;
  @store.Mutation("SET_ID_SISTEMA_EVENTANILLA")
  SET_ID_SISTEMA_EVENTANILLA: Function;

  get idSistemaEVentanilla() {
    return this.idSistemaEVentanillaSeleccionado;
  }

  set idSistemaEVentanilla(value) {
    this.SET_ID_SISTEMA_EVENTANILLA(value);
  }

  get verify_tipoVentanilla() {
    return [
      v => !!v || "Valor requerido",
      v => {
        let x = buscarKeyEnMap(this.sistemasEventanilla, v);
        if (x != undefined) {
          return true;
        } else {
          return "Valor incorrecto.";
        }
      }
    ];
  }

  get verify_desvio() {
    return [
      v =>
        buscarKeyEnMap(this.tiposDesvios, v) != undefined ||
        "Valor incorrecto/requerido."
    ];
  }

  // Carta
  // Encabezado
  @store.State("encabezadoCartaState") encabezadoCartaState: number;
  @store.Mutation("SET_ENCABEZADO_CARTA") SET_ENCABEZADO_CARTA: Function;

  get encabezadoCarta() {
    return this.encabezadoCartaState;
  }

  set encabezadoCarta(value) {
    this.SET_ENCABEZADO_CARTA(value);
  }

  // Primer parrafo
  @store.State("primerParrafoState") primerParrafoState: number;
  @store.Mutation("SET_PRIMER_PARRAFO") SET_PRIMER_PARRAFO: Function;

  get primerParrafo() {
    return this.primerParrafoState;
  }

  set primerParrafo(value) {
    this.SET_PRIMER_PARRAFO(value);
  }

  // Segundo Parrafo
  @store.State("segundoParrafoState") segundoParrafoState: number;
  @store.Mutation("SET_SEGUNDO_PARRAFO") SET_SEGUNDO_PARRAFO: Function;

  get segundoParrafo() {
    return this.segundoParrafoState;
  }

  set segundoParrafo(value) {
    this.SET_SEGUNDO_PARRAFO(value);
  }

  // Primer parrafo
  @store.State("pdfNombreState") pdfNombreState: number;
  @store.Mutation("SET_PDF_NOMBRE") SET_PDF_NOMBRE: Function;

  get pdfNombre() {
    return this.pdfNombreState;
  }

  set pdfNombre(value) {
    this.SET_PDF_NOMBRE(value);
  }

  // Pantalla
  @store.State("openEnviarDFE") openEnviarDFE: boolean;
  @store.Mutation("SHOW_ENVIAR_DFE") SHOW_ENVIAR_DFE: Function;

  async closeEnviarDFE() {
    await this.SHOW_ENVIAR_DFE(false);
    this.campania = false;
  }

  get show() {
    return this.openEnviarDFE;
  }

  @store.State("showSeleccionarSpinner") showSeleccionarSpinner: boolean;
  //@store.State('openEnviarDFE') openEnviarDFE: boolean;
  @store.Mutation("SET_SHOW_SELECCIONAR_SPINNER")
  SET_SHOW_SELECCIONAR_SPINNER: Function;

  get showSpinner() {
    return this.showSeleccionarSpinner;
  }

  set showSpinner(value) {
    this.SET_SHOW_SELECCIONAR_SPINNER(value);
  }

  // Boton de guardado
  @store.Action("saveEnviarDFE") saveEnviarDFE: Function;

  @store.Mutation("SET_ENVIAR_DFE_VALIDO") SET_ENVIAR_DFE_VALIDO: Function;
  @store.State("enviarDFEValido") enviarDFEValido: boolean;

  @store.Mutation("SET_NOTIFICACION") SET_NOTIFICACION: Function;
  isValidaCampania: boolean;

  beforeMount() {
    this.CLEAN_SELECCIONES_ENVIAR_DFE();
    this.getSistemasEVentanilla();
    this.getFormularios();
    this.getTiposDesvio();
    this.validateLists();
  }

  validateLists() {
    VeeValidate.Validator.extend("verify_tipoVentanilla", {
      getMessage: field => `The field is not a valid coupon.`,
      validate: value =>
        new Promise(resolve => {
          resolve({
            valid:
              value &&
              buscarKeyEnMap(this.sistemasEventanilla, value) != undefined
          });
        })
    });
    VeeValidate.Validator.extend("verify_formulario", {
      getMessage: field => `Valor incorrecto/requerido.`,
      validate: value =>
        new Promise(resolve => {
          resolve({
            valid:
              value &&
              buscarListFormulariosEnMap(this.formularios, value) != undefined
          });
        })
    });
    VeeValidate.Validator.extend("verify_desvio", {
      getMessage: field => `Valor incorrecto/requerido.`,
      validate: value =>
        new Promise(resolve => {
          resolve({
            valid:
              value && buscarKeyEnMap(this.tiposDesvios, value) != undefined
          });
        })
    });
  }

  get verify_Text() {
    return [v => !!v || "Valor incorrecto/requerido"];
  }

  get verify_formulario() {
    return [
      v => !!v || "Valor requerido",
      v => {
        let x = buscarListFormulariosEnMap(this.formularios, v);
        if (x != undefined) {
          return true;
        } else {
          return "Valor incorrecto.";
        }
      }
    ];
  }

  get formulario() {
    return this.formulariosSeleccionados;
  }

  set formulario(value) {
    this.SET_FORMULARIOS_SELECCIONADOS(value);
  }

  get universoComputed() {
    return this.universo;
  }

  set universoComputed(value) {
    //            this.SET_UNIVERSO
  }

  get mensaje() {
    return this.msj;
  }
  set mensaje(value) {
    this.msj = value;
  }

  validarEnviarDFE() {
    if (
      !this.codigoDeCampania ||
      !this.idSistemaEVentanilla ||
      !this.encabezadoCarta ||
      !this.primerParrafo ||
      !this.segundoParrafo ||
      !this.pdfNombre ||
      !this.nombreUsuario ||
      !this.areaUsuario ||
      !this.cargoUsuario
    ) {
      this.SET_ENVIAR_DFE_VALIDO(false);
      this.SET_SAVE_CAMPANIA(false);
    } else {
      this.SET_ENVIAR_DFE_VALIDO(true);
    }
  }

  enviarDFE(openEnviarDFE) {
    if (this.isValidaCampania && openEnviarDFE) {
      this.showSpinner = true;
      this.saveEnviarDFE()
        .then(response => {
          this.showSpinner = false;
          this.REMOVE_ALL_DIMENSIONES_SELECCIONADAS();
          this.CLEAN_PERIODO();
          this.CLEAN_SELECCIONES_ENVIAR_DFE();
          this.SET_NOTIFICACION({
            titulo: "Campaña",
            mensaje: "Campaña guardada con exito",
            color: "green",
            goToHome: false,
            goToCampana: true
          });
        })
        .catch(e => {
          this.showSpinner = false;
          this.SET_NOTIFICACION({
            titulo: e.codigo,
            color: "red",
            mensaje: e.descripcion,
            goToHome: false,
            goToCampana: false
          });
        });
    }
    this.campania = false;
    this.SHOW_ENVIAR_DFE(false);
  }

  closeAlertDFE(value) {
    this.campania = value;
    this.mensaje = "";
  }

  validateAndSaveEnviarDFE() {
    this.$validator.validate().then(result => {
      this.validarEnviarDFE();

      if (!result) {
        //this.SHOW_ENVIAR_DFE(true);
        this.SET_NOTIFICACION({
          titulo: "Error",
          color: "red",
          mensaje:
            "El campo " +
            this.$validator.errors.items[0].field +
            " es obligatorio",
          goToHome: false,
          goToCampana: false,
          saveCampania: false
        });
        return;
      }

      if (!this.enviarDFEValido) {
        this.SET_NOTIFICACION({
          titulo: "Error",
          color: "red",
          mensaje:
            "Debe completar los campos requeridos para poder realizar el envío a DFE",
          goToHome: false,
          goToCampana: false,
          saveCampania: false
        });
        return;
      }

      if (!this.universoComputed.hasOwnProperty("columns")) {
        //si no tiene le object columns es porque no exploro
        this.SET_NOTIFICACION({
          titulo: "Error",
          color: "red",
          mensaje: "Debe completar la selección para poder guardar la caratula",
          goToHome: false,
          goToCampana: false,
          saveCampania: false
        });
        return;
      }
      this.isValidaCampania = result;
      this.titulo = "Advertencia";
      this.color = "yellow darken-4";
      this.mensaje =
        "ATENCIÓN: Al pulsar ACEPTAR, usted enviará notificaciones por ventanilla a los contribuyentes finales ¿Desea proceder?";
      this.campania = true;
      this.SET_FULL_PATH("/Ventanilla");
      this.SET_NOTIFICACION({
        titulo: this.titulo,
        color: this.color,
        mensaje: this.mensaje,
        goToHome: false,
        goToCampana: true,
        saveCampania: this.campania
      });
    });
  }
}
</script>

<style></style>