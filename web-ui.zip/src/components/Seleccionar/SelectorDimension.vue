<template>
        <v-list dense>
            <v-list-tile v-if="dimensiones[0].children == null">
                <beat-loader style="vertical-align: middle" color="lightgrey" size="0.5em"></beat-loader><span ><div style="color:lightgrey;font-size:1.5em">&nbsp;Cargando dimensiones</div></span>
            </v-list-tile>
            <v-list-group v-else v-model="par" v-for="item in dimensiones" :key="item.nombre" no-action>
                <v-list-tile ripple slot="activator">
                    <v-list-tile-content>
                        <v-list-tile-title>{{item.nombre}}</v-list-tile-title>
                    </v-list-tile-content>
                </v-list-tile>
                <Drag v-for="subItem in item.children" :key="subItem.columna" :transfer-data="subItem" class="drag"
                    :effect-allowed="['copy']" drop-effect="copy">
                    <v-hover>
                        <v-list-tile ripple slot-scope="{ hover }" :class="hover ? 'transition-fast-in-fast-out primary darken-1 white--text elevation-1' : ''"
                            :style="hover ? 'cursor:pointer':''" :key="subItem.columna">
                            <v-list-tile-action>
                                <v-icon small :class="hover ? 'white--text' : ''">{{ setIcon(subItem.tipo) }}</v-icon>
                            </v-list-tile-action>
                            <v-list-tile-content>
                                <v-tooltip bottom>
                                    <v-list-tile-title :class="`${hover ? 'white--text' : ''}`" slot="activator">{{ subItem.columna }}</v-list-tile-title>
                                    <span>{{ subItem.nombre? subItem.nombre: "Sin Descripcion" }}</span>
                                </v-tooltip>                                
                            </v-list-tile-content>
                        </v-list-tile>
                    </v-hover>
                </Drag>
            </v-list-group>
        </v-list>
</template>

<script lang="ts">
    import {
        Component,
        Vue,
        Watch
    } from 'vue-property-decorator';
    import {
        State,
        namespace
    } from 'vuex-class';
    import {
        getIcon
    } from '@/helpers';
    import {
        Drag
    } from 'vue-drag-drop';
    import BeatLoader  from 'vue-spinner/src/BeatLoader.vue';

    const store = namespace('SeleccionarStore');

    @Component({
        components: {
            Drag,
            BeatLoader
        }
    })
    export default class SelectorDimension extends Vue {
        @store.State('dimensiones') dimensiones: Array < any > ;
        @store.State('cuboSeleccionado') cuboSeleccionado: any ;

        par: boolean = true;

        setIcon(type) {
            return getIcon(type);
        }

        @Watch('cuboSeleccionado')
        cuboSeleccionadoChange(val: string, oldVal: string) {
            this.par = !!this.cuboSeleccionado;
        }
    }
</script>