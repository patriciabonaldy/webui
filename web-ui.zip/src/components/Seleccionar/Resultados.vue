<template>
    <div>
        <v-container grid-list-md text-xs-center>
            <v-layout row wrap>
                <v-flex xs3 v-if="cantidadDeContribuyentes"><strong>Cantidad Contribuyentes: </strong>{{setFormatNumber(cantidadDeContribuyentes)}}
                </v-flex>
                <v-flex xs3 v-if="ajusteEstimado"><strong>Ajuste Estimado: </strong>{{setFormatPrice(ajusteEstimado)}}
                </v-flex>
                <v-flex xs3 v-if="ajusteEstimado"><strong>Minimo Estimado: </strong>{{setFormatPrice(minimoEstimado)}}
                </v-flex>
                <v-flex xs3 v-if="ajusteEstimado"><strong>Máximo Estimado: </strong>{{setFormatPrice(maximoEstimado)}}
                </v-flex>
                <v-flex xs3 v-if="ajusteEstimado"><strong>Promedio Estimado: </strong>{{setFormatPrice(promedioEstimado)}}
                </v-flex>
                <v-flex xs3 v-if="ajusteEstimado"><strong>Desvío Estándar: </strong>{{setFormatPrice(varianceEstimado)}}
                </v-flex>
                <v-flex xs3 v-if="periodoDesdeSeleccionado"><strong>Periodo Desde: </strong>{{periodoDesdeSeleccionado}}
                </v-flex>
                <v-flex xs3 v-if="periodoHastaSeleccionado"><strong>Periodo Hasta: </strong>{{periodoHastaSeleccionado}}
                </v-flex>
            </v-layout>
        </v-container>
        <v-container grid-list-xl v-if="rows != null">
            <v-data-table :headers="columns" :items="rows" :loading="rows == null" align="center" class="text-xs-center" disable-initial-sort rows-per-page-text="paginas">
                <v-progress-linear slot="progress" color="blue" indeterminate></v-progress-linear>
                <template slot="no-data">
                    <div v-if="rows != null && rows.length == 0">No hay resultados :(</div>
                </template>
                <template slot="items" slot-scope="props">
                    <td v-for="(msg,i) in props.item" :key="i" style="text-align: left;">{{msg}}</td>
                </template>
            </v-data-table>
        </v-container>
    </div>
</template>

<script lang="ts">
    import {
        Component,
        Watch,
        Vue
    } from 'vue-property-decorator';
    import {
        State,
        namespace
    } from 'vuex-class';
    import {
        formatPrice, formatNumber
    } from '@/helpers';

    const store = namespace('SeleccionarStore');

    @Component({
        components: {}
    })
    export default class Resultados extends Vue {
        @store.State('universo') universo: any;

        @store.State('cantidadDeContribuyentes') cantidadDeContribuyentes: any;
        @store.State('ajusteEstimado') ajusteEstimado: any;
        @store.State('minimoEstimado') minimoEstimado: any;
        @store.State('maximoEstimado') maximoEstimado: any;
        @store.State('promedioEstimado') promedioEstimado: any;
        @store.State('varianceEstimado') varianceEstimado: any;
        @store.State('periodoDesdeSeleccionado') periodoDesdeSeleccionado: any;
        @store.State('periodoHastaSeleccionado') periodoHastaSeleccionado: any;

        @store.Action('getCubos') getCubos: Function;

        columnsInt: Array<any> = [];
        rowsInt: Array<any> = null;

        beforeMount() {
            this.setUniverso();
        }

        get columns() {
            return this.columnsInt;
        }

        set columns(value) {
            this.columnsInt = value;
        }

        get rows() {
            return this.rowsInt;
        }

        set rows(value) {
            this.rowsInt = value;
        }

        @Watch('universo')
        setUniverso() {
            if (this.universo && this.universo.columns) {
                this.columns = this.universo.columns.map(column => {
                    let copiedColumn: any = {};
                    Object.assign(copiedColumn, column);
                    copiedColumn.sortable = false;
                    copiedColumn.align = 'left';
                    //Se pusieron comillas para evitar caracteres escpeciales. Ahora hay que quitarlas.
                    copiedColumn.value = column.value.replace("`", "").replace("`", "")
                    return copiedColumn;
                });
            }
            if (this.universo && this.universo.rows) {
                this.rows = this.universo.rows.map(row => {
                    let array = [];

                    this.columns.forEach(column => {
                        if (column.type === 'number' && column.text != 'CUIT') {
                            row[column.value] = this.setFormatNumber(row[column.value]);
                        }

                        array.push(row[column.value])
                    });

                    return array;
                });
            }

        }

        setFormatPrice(value) {
            return formatPrice(value);
        }

        setFormatNumber(value) {
            return formatNumber(value);
        }


    }
</script>