<template>
    <div style="text-align:center">
        <Columnas/>
        <Filtros/>

        <Estimacion v-if="showEstimacion" @runQuery="runQuery()" @closeEstimacion="showEstimacion = false"/>
        <Resultados v-if="showResultados"/>
        <div style="text-align:center">
            <v-btn v-if="!showResultados" color="primary" @click="ejecutarConsulta()">Calcular</v-btn>            
            <v-btn v-if="showResultados" color="primary" @click="guardarHipotesis()">Guardar hipotesis</v-btn>
            <v-btn v-if="showResultados" color="secondary" @click="enviarAInduccion()">Enviar a induccion</v-btn>
        </div>
    </div>
</template>

<script lang="ts">

    import {
        Component,
        Watch,
        Vue
    } from 'vue-property-decorator';
    import Columnas from '@/components/Seleccionar/Columnas.vue';
    import Filtros from '@/components/Seleccionar/Filtros.vue';
    import Estimacion from '@/components/Seleccionar/Estimacion.vue';
    import Notificacion from '@/components/Notificacion.vue';
    import Resultados from '@/components/Seleccionar/Resultados.vue';
    import {namespace} from 'vuex-class';

    const store = namespace('SeleccionarStore');

    @Component({
        components: {
            Columnas,
            Filtros,
            Estimacion,
            Notificacion,
            Resultados
        }
    })
    export default class QueryBuilder extends Vue {
        @store.State('impuestoSeleccionado') impuestoSeleccionado: number;
        @store.State('universo') universo: any;
        @store.State('periodoDesdeSeleccionado') periodoDesdeSeleccionado: string;
        @store.State('periodoHastaSeleccionado') periodoHastaSeleccionado: string;
        @store.State('cuboSeleccionado') cuboSeleccionado: any;
        @store.State('dimensionesSeleccionadas') dimensionesSeleccionadas: Array<any>;
        @store.State('filtrosSeleccionados') filtrosSeleccionados: Array<any>;
        @store.State('caratulaValida') caratulaValida: boolean;

        @store.Action('getEstadisticas') getEstadisticas: Function;        
        @store.Action('getUniverso') getUniverso: Function;

        @store.Mutation('SET_UNIVERSO') SET_UNIVERSO: Function;
        @store.Mutation('SHOW_CARATULA') SHOW_CARATULA: Function;
        @store.Mutation('SHOW_ENVIAR_DFE') SHOW_ENVIAR_DFE: Function;
        @store.Mutation('SET_NOTIFICACION') SET_NOTIFICACION: Function;
        @store.Mutation('SET_SHOW_SELECCIONAR_SPINNER') SET_SHOW_SELECCIONAR_SPINNER: Function;
        @store.Mutation('SET_BTN_CANCEL_RQ') SET_BTN_CANCEL_RQ: Function;

        estima: boolean = false;
        resul: boolean = false;

        get showEstimacion() {
            return this.estima;
        }

        set showEstimacion(value) {
            this.estima = value;
        }

        get showResultados() {
            return this.resul;
        }

        set showResultados(value) {
            this.resul = value;
        }

        ejecutarConsulta() {
            if (this.dimensionesSeleccionadas.length === 0) {
                this.SET_NOTIFICACION({titulo: "Error", color: "red", mensaje: "Debes tener seleccionado por lo menos una columna.", goToHome: false});
                return false;
            }
            this.SET_BTN_CANCEL_RQ(true);
            this.SET_SHOW_SELECCIONAR_SPINNER(true);
            this.getEstadisticas().then((x) => {
                this.SET_SHOW_SELECCIONAR_SPINNER(false);
                this.showEstimacion = true;
            });
        }

        runQuery() {
            this.showEstimacion = false;
            this.SET_BTN_CANCEL_RQ(true);
            this.SET_SHOW_SELECCIONAR_SPINNER(true);
            this.getUniverso().then((x) => {
                this.showResultados = true;
                this.SET_SHOW_SELECCIONAR_SPINNER(false);
            });

        }

        get watchQuery() {
            return `${this.periodoDesdeSeleccionado}|${this.periodoHastaSeleccionado}|${this.dimensionesSeleccionadas}|${this.cuboSeleccionado}|${this.filtrosSeleccionados}`
        }

        @Watch('watchQuery')
        resettable() {
            this.SET_UNIVERSO(null);
            this.showResultados = false;
        }

        guardarHipotesis() {
            if (!this.universo || !this.universo.hasOwnProperty("columns")) {
                this.SET_NOTIFICACION({titulo: "Error", color: "red", mensaje: "Debe completar la selección para poder guardar la Hipotesis", goToHome: false,goToCampana: false});
                return;
            } else if (this.universo.rows.length<1 ) {
                this.SET_NOTIFICACION({titulo: "Error", color: "red", mensaje: "No se puede crear la Hipotesis debido a que el cálculo no arrojó resultados", goToHome: false, goToCampana: false});
                return;
            } else if (this.universo.rows.length<1 ) {
                this.SET_NOTIFICACION({titulo: "Error", color: "red", mensaje: "No se puede crear la Hipotesis debido a que el cálculo no arrojó resultados", goToHome: false});
                return;
            }
            this.SHOW_CARATULA(true);
        }

        enviarAInduccion() {
            if (!this.universo || !this.universo.hasOwnProperty("columns")) {
                this.SET_NOTIFICACION({titulo: "Error", color: "red", mensaje: "Debe completar la selección para poder realizar el env&iacute;o a DFE", goToHome: false, goToCampana: false});
                return;
            } else if (this.universo.rows.length<1 ) {
                this.SET_NOTIFICACION({titulo: "Error", color: "red", mensaje: "No se puede enviar a DFE debido a que el cálculo no arrojó resultados", goToHome: false, goToCampana: false});
                return;
            }

            this.SHOW_ENVIAR_DFE(true);
        }
    }
</script>
