<template>
    <div>
    <v-container>
        <v-card class="elevation-12">
            <v-layout>
                <v-flex style="width:80vw" sm1>
                    <v-card-text>
                        <div key="title" class="font-weight-light pa-3 text-xs-center">
                            Columnas
                        </div>
                    </v-card-text>
                </v-flex>
                <v-flex sm11>
                    <div style="text-align:right;  margin-right: 0px;">
                        <v-btn v-if="idx>0" flat icon color="blue-grey darken-1" @click="undo()">
                            <v-icon>fas fa-reply</i></v-icon>
                        </v-btn>  
                        <v-btn  v-if="lenghtState>0 && idx<lenghtState" flat icon color="blue-grey darken-1" @click="redo()">
                            <v-icon>fas fa-share</v-icon>
                        </v-btn>  
                        <v-btn flat icon color="blue-grey darken-1" @click="cleanAllChip()">
                            <v-icon>fas fa-trash</v-icon>
                        </v-btn>                       
                        
                    </div>
                    <Drop @drop="handleDrop" class="drop">
                        <v-card-text>
                            <div v-if="dimensionesSeleccionadas" key="title" class="font-weight-light grey--text pa-3 text-xs-center">
                                Arrastre las columnas que quiere visualizar desde el menu "Dimensiones"
                            </div>
                            <v-scroll-x-transition group hide-on-leave>
                                <v-chip v-for="(selection, i) in selections" :key="i" text-color="white" color="primary"
                                    close @input="(removeChip(i))">
                                    <v-avatar>
                                        <v-icon small>{{ setIcon(selection.tipo) }}</v-icon>
                                    </v-avatar>                                    
                                    <v-tooltip bottom>
                                        <v-flex v-if="selection.agregacion!='NULL'" slot="activator">
                                            {{labelSelect(selection.agregacion)}}{{ selection.columna==null?"": selection.columna}}
                                        </v-flex>
                                        <v-flex v-else slot="activator">
                                            {{ selection.columna }}
                                        </v-flex> 
                                        <span>{{ selection.nombre? selection.nombre: "Sin Descripcion" }}</span>  
                                    </v-tooltip> 
                                </v-chip>
                            </v-scroll-x-transition>
                        </v-card-text>
                    </Drop>
                            
                </v-flex>
            </v-layout>
        </v-card>
    </v-container>
    <SelectFiltro v-if="mostrarFiltro" :campo="campo" @close="closed" @save="saved" />
    </div>
</template>

<script lang="ts">
    import {
        Component,
        Vue,
        Watch
    } from 'vue-property-decorator';
    import {
        State,
        namespace
    } from 'vuex-class';
    import {
        Drop
    } from 'vue-drag-drop';
    import {
        getIcon, formatSelect
    } from '@/helpers';
    import SelectFiltro from '@/components/Seleccionar/SelectFiltro.vue';
    import {CloneState} from '@/components/CloneState.ts';

    const store = namespace('SeleccionarStore');

    @Component({
        components: {
            Drop,
            SelectFiltro
        }
    })
    export default class Columnas extends Vue {
        @store.State('cuboSeleccionado') cuboSeleccionado: any;
        @store.State('dimensionesSeleccionadas') dimensionesSeleccionadas: Array < any > ;

        @store.Mutation('ADD_DIMENSIONES_SELECCIONADAS') ADD_DIMENSIONES_SELECCIONADAS: Function;
        @store.Mutation('REMOVE_DIMENSIONES_SELECCIONADAS') REMOVE_DIMENSIONES_SELECCIONADAS: Function;
        @store.Mutation('REMOVE_ALL_DIMENSIONES_SELECCIONADAS') REMOVE_ALL_DIMENSIONES_SELECCIONADAS: Function;        

        selections: Array < any > = [];
        mostrar : boolean = false;
        flt : any = null;
        cmp : any = null;
        state = new CloneState();
        indexState: number = 0;

        get mostrarFiltro(){
            return this.mostrar;
        }
        set mostrarFiltro(value){
            this.mostrar = value;
        }
        get filtro(){
            return this.flt;
        }
        set filtro(value){
            this.flt = value;
        }
        get campo(){
            return this.cmp;
        }
        set campo(value){
            this.cmp = value;
        }       
        
        labelSelect(value){
            return formatSelect(value);
        }

        cloneState(){ 
            this.$store.state.SeleccionarStore.changeState=1;           
            this.state.addState(this.$store.state.SeleccionarStore);
        }

        @Watch('dimensionesSeleccionadas')
        dimensionesSeleccionadasChange(val: string, oldVal: string) {
            this.selections = this.dimensionesSeleccionadas;                    
        }

        @Watch('cuboSeleccionado')
        cuboSeleccionadoChange(val: string, oldVal: string) {
            this.state = new CloneState();  
        }


        handleDrop(data) {
            this.campo = data;
            this.mostrarFiltro = true;
        }
        removeChip(index) {
            this.REMOVE_DIMENSIONES_SELECCIONADAS(index);
            this.cloneState();   
        }
        setIcon(type) {
            return getIcon(type);
        }
        closed(){
            this.mostrarFiltro = false;
        }
        saved(obj){
            this.filtro = obj;
            this.filtro.nombre = this.filtro.nombre==null?this.filtro.columna:this.filtro.nombre;
            this.ADD_DIMENSIONES_SELECCIONADAS(this.filtro);
            this.cloneState();   
        }
        cleanAllChip() {
            this.selections.splice(0, this.selections.length);
            this.REMOVE_ALL_DIMENSIONES_SELECCIONADAS();
            this.cloneState();   
        }

        undo() {
            this.state.undo(1);
        }

        redo(){
            this.state.redo(1);
        }
        get idx(){
            return this.state.getIdx();
        }

        get lenghtState(){
            return this.state.getLenghtState();
        }
        
    }
</script>