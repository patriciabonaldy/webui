<template>
    <div class="text-xs-center">
        <v-dialog :hide-overlay="true" v-model="dialog" width="500" persistent>
            <v-card>
                <v-card-title>
                    <span class="headline">Componer Filtro</span>
                </v-card-title>
                <v-card-text>
                    <v-container grid-list-xs>
                        <v-layout wrap>
                            <v-flex xs4 sm6>
                                <v-text-field
                                    disabled
                                    v-text="campo.columna"
                                    >
                                </v-text-field>
                            </v-flex>
                            <v-flex xs4 sm6>
                                <v-select 
                                    v-model="funcion" 
                                    :items="funciones"
                                    item-value="codigo"
                                    item-text="descripcion"
                                    label="Agregacion"
                                    v-validate="'required'" 
                                >
                                </v-select>
                            </v-flex>                            
                        </v-layout>
                    </v-container>
                </v-card-text>
                <v-divider/>
                <v-card-actions>
                    <v-spacer></v-spacer>
                    <v-btn color="green white--text " @click="saveIt()">Guardar</v-btn>
                    <v-btn color="red white--text " @click="cancelt()">Cancelar</v-btn>
                </v-card-actions>
            </v-card>
        </v-dialog>
        <Notificacion v-if="mensaje != null" :color="color" :titulo="titulo" :mensaje="mensaje" @close="mensaje = null"/>
    </div>
</template>

<script lang="ts">
    import {
        Component,
        Prop,
        Vue
    } from 'vue-property-decorator';
    import {
        State,
        namespace
    } from 'vuex-class';
    import {
        Drop
    } from 'vue-drag-drop';
    import {
        getIcon
    } from '@/helpers';
    import Notificacion from '@/components/Notificacion.vue';
    const store = namespace('SeleccionarStore');

    @Component({
        components:{
            Drop,
            Notificacion
        }
    })
    export default class SelectFiltro extends Vue {
        @Prop(Boolean) mostrar!: boolean;
        @Prop(Object) campo!: any;
        
        msj : string = null;
        titulo : string = null;
        color : string = 'red';
        dialog : boolean = true;
        colComp : any = null;        
        funciones : Array<any> = [
            {
                codigo : "SUM",
                descripcion : "Sumar"
            },
            {
                codigo : "AVG",
                descripcion : "Promedio"
            },
            {
                codigo : "COUNT",
                descripcion : "Contar"
            },
            {
                codigo : "COUNTDISTINCT",
                descripcion : "Contar Exclusivo"
            },
            {
                codigo : "MIN",
                descripcion : "Minimo"
            },
            {
                codigo : "MAX",
                descripcion : "Maximo"
            }
        ]
        fn : string = 'SUM';

        get funcion(){
            return this.fn;
        }
        set funcion(value){
            this.fn = value;
        }

        get columnaComparada(){
            return this.colComp;
        }
        set columnaComparada(value){
            this.colComp = value;
        }

        get mensaje(){
            return this.msj;
        }
        set mensaje(value){
            this.msj = value;
        }
        
        handleDrop(data) {
            this.columnaComparada = data;
        }

        removeChip() {
            this.columnaComparada = null;
        }
        setIcon(type) {
            return getIcon(type);
        }

        saveIt() {
            this.$validator.validate().then(result => {
                if (!result) {
                    this.titulo = "Error";
                    this.color = "red";
                    this.mensaje = "El campo " + this.$validator.errors.items[0].field + " es obligatorio";
                    this.removeChip();
                }
                else {

                    let idx = this.funciones.find(x => x.codigo == this.funcion);
                    this.campo.agregacion = idx.codigo;
                    this.$emit('save', this.campo);
                    this.closeIt();
                }
            });
        }


        cancelt(){
            this.removeChip();
            this.closeIt();
        }
        
        closeIt(){
            this.dialog = false;
            this.$emit('close');
        }
    }
</script>