<template>
  <div>
    <v-dialog v-model="show" persistent max-width="1000px">
      <v-card>
        <v-card-title>
          <span class="headline">Periodo de la Hipotesis</span>
        </v-card-title>
        <v-card-text>
          <v-container grid-list-md>
            <v-layout wrap>
              <v-flex xs12 sm4>
                <v-switch
                  :label="`Tipo periodo: ${tipoPeriodo ? 'Fiscal' : 'Calendario'}`"
                  v-model="tipoPeriodo"
                  id="vtipoPeriodo"
                ></v-switch>
              </v-flex>
              <v-flex xs12 sm4>
                <v-menu
                  v-if="!tipoPeriodo"
                  key="periodoDesde"
                  :close-on-click="false"
                  :close-on-content-click="false"
                  v-model="menuPeriodoDesde"
                  :nudge-right="40"
                  transition="scale-transition"
                  offset-y
                  full-width
                  min-width="290px"
                >
                  <v-text-field
                    slot="activator"
                    v-model="periodoDesde"
                    label="Seleccione periodo desde"
                    prepend-icon="event"
                    readonly
                  ></v-text-field>
                  <v-date-picker
                    locale="es-ES"
                    id="vperiodoDesdeM"
                    v-model="periodoDesde"
                    type="month"
                    no-title
                    @input="menuPeriodoDesde = false"
                    data-vv-name="Periodo desde"
                    name="periodoDesde"
                  ></v-date-picker>
                </v-menu>
                <v-select
                  v-else
                  :items="anios"
                  key="periodoDesde"
                  v-model="periodoDesde"
                  data-vv-name="Periodo desde"
                  label="Periodo desde"
                ></v-select>
              </v-flex>
              <v-flex xs12 sm4>
                <v-menu
                  v-if="!tipoPeriodo"
                  key="periodoHasta"
                  :close-on-click="false"
                  :close-on-content-click="false"
                  v-model="menuPeriodoHasta"
                  :nudge-right="40"
                  transition="scale-transition"
                  offset-y
                  full-width
                  min-width="290px"
                >
                  <v-text-field
                    slot="activator"
                    id="periodoHastaMensual"
                    v-model="periodoHasta"
                    label="Seleccione periodo hasta"
                    prepend-icon="event"
                    readonly
                  ></v-text-field>
                  <v-date-picker
                    locale="es-ES"
                    :return-value.sync="periodoHasta"
                    v-model="periodoHasta"
                    type="month"
                    no-title
                    @input="menuPeriodoHasta = false"
                    data-vv-name="Periodo hasta"
                    name="periodoHasta"
                  ></v-date-picker>
                </v-menu>
                <v-select
                  v-else
                  :items="anios"
                  key="periodoHasta"
                  v-model="periodoHasta"
                  data-vv-name="Periodo hasta"
                  label="Periodo hasta"
                ></v-select>
              </v-flex>
            </v-layout>
          </v-container>
        </v-card-text>
        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn color="primary" dark @click="savePeriodo">Aceptar</v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Watch } from "vue-property-decorator";
import VueRouter from "vue-router";
import { namespace } from "vuex-class";
import { buscarKeyEnMap } from "@/helpers";
import VeeValidate from "vee-validate";

Vue.use(VeeValidate);
const store = namespace("SeleccionarStore");

@Component({
  components: {}
})
export default class Periodo extends Vue {
  @store.State("openPeriodo") openPeriodo: boolean;
  @store.State("tipoPeriodoSeleccionado") tipoPeriodoSeleccionado: string;
  @store.State("periodoDesdeSeleccionado") periodoDesdeSeleccionado: string;
  @store.State("periodoHastaSeleccionado") periodoHastaSeleccionado: string;

  @store.Mutation("SHOW_PERIODO") SHOW_PERIODO: Function;
  @store.Mutation("SET_TIPO_PERIODO") SET_TIPO_PERIODO: Function;
  @store.Mutation("SET_PERIODO_DESDE") SET_PERIODO_DESDE: Function;
  @store.Mutation("SET_PERIODO_HASTA") SET_PERIODO_HASTA: Function;
  @store.Mutation("CLEAN_SELECCIONES_PERIODO")
  CLEAN_SELECCIONES_PERIODO: Function;

  @store.Mutation("SET_NOTIFICACION") SET_NOTIFICACION: Function;

  menuPeriodoDesde: boolean = false;
  menuPeriodoHasta: boolean = false;
  anios: Array<string> = [];
  pDesde: string = "";
  pHasta: string = "";

  beforeMount() {
    let esteanio = new Date().getUTCFullYear();
    this.anios = [];
    for (let x = esteanio; x >= 1980; x--) this.anios.push(x.toString());
  }

  get show() {
    return this.openPeriodo;
  }

  get tipoPeriodo() {
    return this.tipoPeriodoSeleccionado == "F";
  }

  set tipoPeriodo(value) {
    this.SET_PERIODO_DESDE("");
    this.SET_PERIODO_HASTA("");
    this.menuPeriodoDesde = false;
    this.menuPeriodoHasta = false;
    value ? this.SET_TIPO_PERIODO("F") : this.SET_TIPO_PERIODO("C");
    this.pDesde = "";
    this.pHasta = "";
  }

  get periodoDesde(): string {
    if (!this.pDesde) this.pDesde = this.periodoDesdeSeleccionado;
    return this.pDesde;
  }

  set periodoDesde(value: string) {
    if (this.tipoPeriodo) {
      this.pDesde = value.toString();
    } else {
      let [year, month] = value.toString().split("-");
      this.pDesde = year.toString() + month.toString();
    }
  }

  get periodoHasta(): string {
    if (!this.pHasta) this.pHasta = this.periodoHastaSeleccionado;
    return this.pHasta;
  }

  set periodoHasta(value: string) {
    if (this.tipoPeriodo) {
      this.pHasta = value.toString();
    } else {
      let [year, month] = value.toString().split("-");
      this.pHasta = year.toString() + month.toString();
    }
  }

  async closePeriodo() {
    await this.SHOW_PERIODO(false);
  }

  savePeriodo() {
    var self = this;
    this.$validator.validate().then(result => {
      if (!self.periodoDesde) {
        self.SHOW_PERIODO(true);
        self.SET_NOTIFICACION({
          titulo: "Error",
          color: "red",
          mensaje: "El campo Periodo Desde es obligatorio",
          goToHome: false,
          goToCampana: false
        });
      } else if (!self.periodoHasta) {
        self.SHOW_PERIODO(true);
        self.SET_NOTIFICACION({
          titulo: "Error",
          color: "red",
          mensaje: "El campo Periodo Hasta es obligatorio",
          goToHome: false,
          goToCampana: false
        });
      } else {
        if (self.periodoDesde > self.periodoHasta) {
          self.SHOW_PERIODO(true);
          self.SET_NOTIFICACION({
            titulo: "Error",
            color: "red",
            mensaje: "El periodo desde no puede ser mayor al periodo hasta",
            goToHome: false,
            goToCampana: false
          });
        } else {
          this.SET_PERIODO_DESDE(this.pDesde);
          this.SET_PERIODO_HASTA(this.pHasta);
          this.pDesde = null;
          this.pHasta = null;
          self.CLEAN_SELECCIONES_PERIODO();
          self.SHOW_PERIODO(false);
        }
      }
    });
  }
}
</script>
