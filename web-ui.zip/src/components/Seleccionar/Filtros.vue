<template>
    <div>
    <v-container>
        <v-card class="elevation-12">
            <v-layout>
                <v-flex style="width:80vw" sm1>
                    <v-card-text>
                        <div key="title" class="font-weight-light pa-3 text-xs-center">
                            Filtros
                        </div>
                    </v-card-text>
                </v-flex>
                <v-flex sm11>
                    <div style="text-align:right;  margin-right: 0px;">
                        <v-btn v-if="idx>0" flat icon color="blue-grey darken-1" @click="undo()">
                            <v-icon>fas fa-reply</i></v-icon>
                        </v-btn>  
                        <v-btn  v-if="lenghtState>0 && idx<lenghtState" flat icon color="blue-grey darken-1" @click="redo()">
                            <v-icon>fas fa-share</v-icon>
                        </v-btn>  
                        <v-btn flat icon color="blue-grey darken-1" @click="cleanAllChip()">
                            <v-icon>fas fa-trash</v-icon>
                        </v-btn>  
                    </div>
                    <Drop @drop="handleDrop" class="drop">
                        <v-card-text>
                            <div v-if="filtrosSeleccionados.length === 0" key="title" class="font-weight-light grey--text pa-3 text-xs-center">
                                Arrastre los filtros que quiere aplicar desde el menu "Dimensiones"
                            </div>
                            <v-scroll-x-transition group hide-on-leave>
                                <v-chip v-for="(selection, i) in selections" :key="i" text-color="white" color="success"
                                    close @input="(removeChip(i))">
                                    <v-avatar>
                                        <v-icon small>{{ setIcon(selection.campo.tipo) }}</v-icon>
                                    </v-avatar>
                                    <v-tooltip bottom>
                                        <v-flex v-if="selection.campo.agregacion!='NULL'" slot="activator">
                                            {{ '"' + labelSelect(selection.campo.agregacion)+ selection.campo.columna + '" ' + selection.operacion.descripcion + ' "' + selection.valor.columna + '"' }}
                                        </v-flex>
                                        <v-flex v-else slot="activator">
                                            {{ '"' + selection.campo.columna + '" ' + selection.operacion.descripcion + ' "' + selection.valor.columna + '"' }}
                                        </v-flex>
                                        <span>{{ selection.campo.columna? selection.campo.columna: "Sin Descripcion" }}</span>
                                    </v-tooltip>                                  
                                </v-chip>
                            </v-scroll-x-transition>
                        </v-card-text>
                    </Drop>
                </v-flex>
            </v-layout>
        </v-card>
    </v-container>
    <ComponerFiltro v-if="mostrarFiltro" :campo="campo" @close="closed" @save="saved" />
    </div>
</template>

<script lang="ts">
    import {
        Component,
        Vue,
        Watch
    } from 'vue-property-decorator';
    import {
        State,
        namespace
    } from 'vuex-class';
    import {
        Drop
    } from 'vue-drag-drop';
    import {
        getIcon, buscarFiltroEnMapWhere, formatSelect 
    } from '@/helpers';
    import ComponerFiltro from '@/components/Seleccionar/ComponerFiltro.vue';
    import {CloneState} from '@/components/CloneState.ts';

    const store = namespace('SeleccionarStore');

    @Component({
        components: {
            Drop,
            ComponerFiltro
        }
    })
    export default class Filtros extends Vue {
        @store.State('cuboSeleccionado') cuboSeleccionado: any;
        @store.State('filtrosSeleccionados') filtrosSeleccionados: Array < any > ;

        @store.Mutation('ADD_FILTROS_SELECCIONADOS') ADD_FILTROS_SELECCIONADOS: Function;
        @store.Mutation('REMOVE_FILTROS_SELECCIONADOS') REMOVE_FILTROS_SELECCIONADOS: Function;
        @store.Mutation('REMOVE_ALL_FILTROS_SELECCIONADOS') REMOVE_ALL_FILTROS_SELECCIONADOS: Function;

        selections: Array < any > = [];
        mostrar : boolean = false;
        flt : any = null;
        cmp : any = null;
        state = new CloneState();
        indexState: number = 0;

        get mostrarFiltro(){
            return this.mostrar;
        }
        set mostrarFiltro(value){
            this.mostrar = value;
        }
        get filtro(){
            return this.flt;
        }
        set filtro(value){
            this.flt = value;
        }
        get campo(){
            return this.cmp;
        }
        set campo(value){
            this.cmp = value;
        }

        @Watch('cuboSeleccionado')
        cuboSeleccionadoChange(val: string, oldVal: string) {
            this.state = new CloneState();  
        }

        @Watch('filtrosSeleccionados')
        filtrosSeleccionadosChange(val: string, oldVal: string) {
            this.selections = this.filtrosSeleccionados;
        }

        handleDrop(data) {  
            this.campo = data;
            this.mostrarFiltro = true;
        }

        removeChip(index) {
            this.REMOVE_FILTROS_SELECCIONADOS(index);
            this.cloneState();   
        }

        cleanAllChip() {
            this.selections.splice(0, this.selections.length);
            this.REMOVE_ALL_FILTROS_SELECCIONADOS();
            this.cloneState();   
        }
        
        setIcon(type) {
            return getIcon(type);
        }
        closed(){
            this.mostrarFiltro = false;
        }
        saved(obj){
            this.filtro = obj;
            this.ADD_FILTROS_SELECCIONADOS(this.filtro);
            this.cloneState();  
        }

        labelSelect(value){
            return formatSelect(value);
        }

        cloneState(){ 
            this.$store.state.SeleccionarStore.changeState=2;           
            this.state.addState(this.$store.state.SeleccionarStore);
        }

        undo() {
            this.state.undo(2);
        }

        redo(){
            this.state.redo(2);
        }
        get idx(){
            return this.state.getIdx();
        }

        get lenghtState(){
            return this.state.getLenghtState();
        }

    }
</script>