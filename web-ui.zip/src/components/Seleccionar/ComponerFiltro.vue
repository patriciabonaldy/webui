<template>
    <div class="text-xs-center">
        <v-dialog :hide-overlay="true" v-model="dialog" width="800" persistent>
            <v-card>
                <v-card-title>
                    <span class="headline">Componer Filtro</span>
                </v-card-title>
                <v-card-text>
                    <v-container grid-list-md>
                        <v-layout wrap>
                            <v-flex xs6 sm6>
                                <v-text-field
                                    disabled
                                    v-text="campo.columna"
                                    >
                                </v-text-field>
                            </v-flex>
                            <v-flex xs6 sm6>
                                <v-select
                                    v-model="funcion"
                                    :items="funciones"
                                    item-value="codigo"
                                    item-text="descripcion"
                                    label="Agregacion"
                                    v-validate="'required'"
                                >
                                </v-select>
                            </v-flex>
                            <v-flex xs12 sm12>
                                <v-select
                                    v-model="operacion"
                                    :items="operaciones"
                                    item-value="signo"
                                    item-text="descripcion"
                                    label="Operacion"
                                >
                                </v-select>
                            </v-flex>
                            <v-flex xs12 sm12>
                                <v-switch
                                    :label="`${tipoComparacion ? 'contra un valor' : 'contra otra columna'}`"
                                    v-model="tipoComparacion"
                                ></v-switch>
                            </v-flex>
                            <v-flex v-if="tipoComparacion">
                                <v-menu v-if="tipoComparacion && campo.tipo === 'date'"
                                    :close-on-content-click="false"
                                    v-model="menu"
                                    :nudge-right="40"
                                    transition="scale-transition"
                                    offset-y
                                    full-width
                                    min-width="290px"
                                >
                                    <v-text-field slot="activator" v-model="valorComparado" label="Seleccione fecha" prepend-icon="event" readonly></v-text-field>
                                    <v-date-picker
                                        locale="es-ES"
                                        v-model="valorComparado"
                                        no-title
                                        key="fecha"
                                        name="fecha"
                                        data-vv-name="Fecha"
                                        v-validate="'required'"
                                        @input="menu = false"
                                    ></v-date-picker>
                                </v-menu>
                                <v-text-field v-else
                                    label="Valor"
                                    key="valor"
                                    name="valor"
                                    v-model="valorComparado"
                                    data-vv-name="Valor"
                                    v-validate="'required'"
                                >
                                </v-text-field>
                            </v-flex>
                            <v-flex v-else>
                                <Drop @drop="handleDrop" class="drop">
                                    <v-card-text>
                                        <div v-if="columnaComparada == null" key="title" class="font-weight-light grey--text pa-3 text-xs-center">
                                            Arrastre la columna contra la cual quiere comparar"
                                        </div>
                                        <div v-else>
                                            <v-scroll-x-transition group hide-on-leave>
                                                <v-chip :key="0" text-color="white" color="primary" close @input="removeChip()">
                                                    <v-avatar>
                                                        <v-icon small>{{ setIcon(columnaComparada.tipo) }}</v-icon>
                                                    </v-avatar>
                                                    {{columnaComparada.columna}}
                                                </v-chip>
                                            </v-scroll-x-transition>
                                        </div>
                                    </v-card-text>
                                </Drop>
                            </v-flex>
                        </v-layout>
                    </v-container>
                </v-card-text>
                <v-divider/>
                <v-card-actions>
                    <v-spacer></v-spacer>
                    <v-btn color="green white--text " @click="saveIt()">Guardar</v-btn>
                    <v-btn color="red white--text " @click="closeIt()">Cancelar</v-btn>
                </v-card-actions>
            </v-card>
        </v-dialog>
        <SelectFiltro v-if="mostrarFiltro" :campo="campoSelect" @close="closed" @save="save" />
    </div>
</template>

<script lang="ts">
    import {
        Component,
        Prop,
        Vue
    } from 'vue-property-decorator';
    import {
        State,
        namespace
    } from 'vuex-class';
    import {
        Drop
    } from 'vue-drag-drop';
    import { getIcon } from '@/helpers';
    import Notificacion from '@/components/Notificacion.vue';
    import SelectFiltro from '@/components/Seleccionar/SelectFiltro.vue';
    const store = namespace('SeleccionarStore');

    @Component({
        components:{
            Drop,
            Notificacion,
            SelectFiltro
        }
    })
    export default class ComponerFiltro extends Vue {
        @Prop(Boolean) mostrar!: boolean;
        @Prop(Object) campo!: any;

        @store.Mutation('SET_NOTIFICACION') SET_NOTIFICACION: Function;

        mostrarSelect : boolean = false;
        cmp : any = null;
        menu : boolean = false;
        msj : string = null;
        titulo : string = null;
        color : string = 'red';
        fc : string = '';
        dialog : boolean = true;
        colComp : any = null;
        flt : any = null;

        tipoComp : boolean = true; //true para valor, false para columna
        funciones : Array<any> = [
            {
                codigo : "SUM",
                descripcion : "Sumar"
            },
            {
                codigo : "AVG",
                descripcion : "Promedio"
            },
            {
                codigo : "COUNT",
                descripcion : "Contar"
            },
            {
                codigo : "COUNTDISTINCT",
                descripcion : "Contar Exclusivo"
            },
            {
                codigo : "MIN",
                descripcion : "Minimo"
            },
            {
                codigo : "MAX",
                descripcion : "Maximo"
            }
        ]
        fn : string = 'SUM';
        operaciones : Array<any> = [
            {
                signo : "=",
                descripcion : "igual"
            },
            {
                signo : "<>",
                descripcion : "distinto"
            },
            {
                signo : ">",
                descripcion : "Mayor"
            },
            {
                signo : ">=",
                descripcion : "Mayor o igual"
            },
            {
                signo : "<",
                descripcion : "Menor"
            },
            {
                signo : "<",
                descripcion : "Menor o igual"
            }
        ]
        op : string = '=';

        get mostrarFiltro(){
            return this.mostrarSelect;
        }
        set mostrarFiltro(value){
            this.mostrarSelect = value;
        }

        get campoSelect(){
            return this.cmp;
        }
        set campoSelect(value){
            this.cmp = value;
        }

        get filtroSelect(){
            return this.flt;
        }
        set filtroSelect(value){
            this.flt = value;
        }

        closed(){
            this.mostrarFiltro = false;
        }

        get funcion(){
            return this.fn;
        }
        set funcion(value){
            this.fn = value;
        }

        get operacion(){
            return this.op;
        }
        set operacion(value){
            this.op = value;
        }

        get valorComparado(){
            return this.fc;
        }
        set valorComparado(value){
            this.fc = value;
        }

        get columnaComparada(){
            return this.colComp;
        }
        set columnaComparada(value){
            this.colComp = value;
        }

        get mensaje(){
            return this.msj;
        }
        set mensaje(value){
            this.msj = value;
        }

        get tipoComparacion(){
            return this.tipoComp;
        }
        set tipoComparacion(value){
            this.valorComparado = null;
            this.columnaComparada = null;
            this.tipoComp = value;
        }
        handleDrop(data) {
            this.campoSelect = data;
            this.mostrarFiltro = true;
        }

        removeChip() {
            this.columnaComparada = null;
        }
        setIcon(type) {
            return getIcon(type);
        }

        save(obj){
            this.columnaComparada = obj;
            this.filtroSelect = obj;
        }

        saveIt(){
            this.$validator.validate().then(result => {
                if (!result) {
                    this.mensaje = "El campo "+this.$validator.errors.items[0].field+" es obligatorio";
                    this.SET_NOTIFICACION({titulo: "Error", color: "red", mensaje: this.mensaje, goToHome: false});
                } else if(!this.tipoComparacion && !this.columnaComparada){
                    this.mensaje = "La columna a comparar es obligatoria. Arrastre una desde el menú lateral.";
                    this.SET_NOTIFICACION({titulo: "Error", color: "red", mensaje: this.mensaje, goToHome: false});
                }
                else{
                    let idx = this.operaciones.find(x => x.signo == this.operacion);
                    let idFx = this.funciones.find(x => x.codigo == this.funcion);
                    this.campo.agregacion = idFx.codigo;
                    let tipoComparacion = this.tipoComparacion ? "valor" : "columna";



                    //this.campo.agregacion = idFx;
                    this.$emit('save',{
                        "campo" : this.campo,
                        "operacion" : idx,
                        "tipoComparacion" : tipoComparacion,
                        "valor" : this.filtroSelect || {
                            "nombre": this.valorComparado,
                            "columna": this.valorComparado,
                            "tipo" : "string"
                        }
                    });
                    this.closeIt();
                }
            });
        }

        closeIt(){
            this.dialog = false;
            this.$emit('close');
        }
    }
</script>