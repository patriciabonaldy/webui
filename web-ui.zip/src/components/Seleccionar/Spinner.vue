<template>
    <div class="text-xs-center">
        <v-dialog persistent v-model="dialog" width="500">
            <v-card>
                <v-card-title class="title primary white--text" primary-title>
                    Procesando...
                </v-card-title>
                <v-card-text style="text-align:center">
                    <beat-loader style="vertical-align: middle" color="lightgrey" size="0.5em"></beat-loader>
                </v-card-text>
                <v-divider></v-divider>
                <div style="text-align:center" v-if="showBtnCancelRQ">
                    <v-btn  color="red white--text " @click="cancelOperation()">Detener Consulta</v-btn>
                </div>
            </v-card>
        </v-dialog>
    </div>
</template>

<script lang="ts">
    import {
        Component,
        Prop,
        Vue
    } from 'vue-property-decorator';
    import {namespace} from 'vuex-class';

    const store = namespace('SeleccionarStore');
    import BeatLoader from 'vue-spinner/src/BeatLoader.vue';

    @Component({
        components: {
            BeatLoader
        }
    })

    export default class Spinner extends Vue {
        @store.Action('cancelOperation') cancelOperation: Function;
        @store.State('showBtnCancelRQ') showBtnCancelRQ: boolean;
        
        dialog: boolean = true;

        closeit() {
            this.$emit('closeEstimacion');
            this.dialog = false;
        }

        runQuery() {
            this.$emit('runQuery');
            this.dialog = false;
        }
    }
</script>