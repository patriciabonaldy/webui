<template>
    <div>
        <v-dialog v-model="show" persistent max-width="1000px">
            <v-card>
                <v-card-title>
                    <span class="headline">Caratula de la Hipotesis</span>
                </v-card-title>
                <v-card-text>
                    <v-container grid-list-md>
                        <v-layout wrap>
                            <v-flex xs12 sm6>
                                <v-text-field class="my-input" v-model="nombreHipotesis" name="nombreHipotesis" clearable label="Nombre de Hipotesis" type="text" :rules="verify_Text"  v-validate="'required|max:500'" required :error-messages="errors.collect('nombreHipotesis')"></v-text-field>
                            </v-flex>
                            <v-flex xs12 sm6>
                                <v-text-field class="my-input" v-model="objetivoHipotesis" name="objetivoHipotesis" clearable label="Objetivo de la Hipotesis" type="text" :rules="verify_Text" v-validate="'required|max:4000'" required :error-messages="errors.collect('objetivoHipotesis')"></v-text-field>
                            </v-flex>
                            <v-flex xs12 sm12>
                                <v-text-field class="my-input" v-model="descripcionHipotesis" name="descripcionHipotesis" clearable label="Descripcion de la Hipotesis" type="text" :rules="verify_Text" v-validate="'required|max:4000'" required :error-messages="errors.collect('descripcionHipotesis')"></v-text-field>
                            </v-flex>
                            <v-flex xs12 sm4>
                                <v-text-field class="my-input" v-model="codigoDeInstructivo" name="codigoDeInstructivo" clearable label="Codigo de instructivo" type="text" :rules="verify_Text" v-validate="'required|max:20'" required :error-messages="errors.collect('codigoDeInstructivo')" mask="NNN-NNNN-####"></v-text-field>
                            </v-flex>
                            <v-flex xs12 sm4>
                                <v-combobox class="my-input" v-model="tipoDesvio" :items="tiposDesvios" :loading="tiposDesvios == null" :disabled="tiposDesvios == null" data-vv-name="TipoDesvio" name="tipoDesvio" item-value="codigo" item-text="descripcion" label="Tipo Desvio" v-validate="'required|verify_desvio|max:10'" :rules="verify_desvio" :error-messages="errors.collect('tipoDesvio')"></v-combobox>
                            </v-flex>
                            <v-flex xs12 sm4>
                                <v-combobox class="my-input" v-model="dirGral" :items="tiposDirGral" data-vv-name="Direccion General" :loading="tiposDirGral == null" name="tipo" item-value="codigo" item-text="descripcion" label="Direccion General" v-validate="'required|verify_tipoH|max:20'" :rules="verify_tipoH"  @change="changeDireccion()" :error-messages="errors.collect('dirGral')" required></v-combobox>
                            </v-flex>
                            <v-flex xs12 sm6>
                                <v-combobox class="my-input" v-model="impuesto" v-if="dirGralSeleccionado" :items="listImpuestos" data-vv-name="Impuesto" :loading="listImpuestos == null" name="impuesto" item-value="codigo" item-text="label" label="Impuesto" v-validate="'required|verify_impuesto|max:4'" :rules="verify_impuesto" :error-messages="errors.collect('impuesto')" required></v-combobox>
                            </v-flex>
                            <v-flex xs12 sm6>
                                <v-combobox class="my-input" v-model="formulario" :items="formularios" data-vv-name="Formulario" :loading="formularios == null" multiple name="formulario" item-value="codigo" item-text="descripcion" small-chips deletable-chips label="Formularios" v-validate="'required|verify_formulario'" :rules="verify_formulario" :error-messages="errors.collect('formulario')"></v-combobox>
                            </v-flex>
                            <v-flex xs12 sm6>
                                <v-combobox class="my-input" v-model="concepto" :loading="conceptos == null" data-vv-name="Concepto" @change="changeConcepto()" name="concepto" :items="conceptos" item-value="codigo" item-text="descripcion" label="Concepto" v-validate="'required|verify_concepto|max:3'" :rules="verify_concepto" :error-messages="errors.collect('concepto')"></v-combobox>
                            </v-flex>
                            <v-flex xs12 sm6>
                                <v-combobox class="my-input" v-model="origen" v-if="conceptoSeleccionado" :items="origenes" :loading="origenes == null" :disabled="origenes == null" data-vv-name="Origen" no-data-text="Primero debe seleccionar el concepto" name="origen" item-value="codigo" item-text="descripcion" label="Origen" v-validate="'required|verify_origen|max:3'" :rules="verify_origen" :error-messages="errors.collect('concepto')"></v-combobox>
                            </v-flex>
                            <v-flex xs12 sm6>
                                <v-combobox class="my-input" v-model="tipoRelevancia" :loading="tiposRelevancia == null" data-vv-name="Tipo Relevancia" name="tipoRelevancia" :items="tiposRelevancia" item-value="codigo" item-text="descripcion" label="Tipo Relevancia" v-validate="'required|verify_relevancia|max:30'" :rules="verify_relevancia" :error-messages="errors.collect('tipoRelevancia')"></v-combobox>
                            </v-flex>
                            <v-flex xs12 sm6>
                                <v-combobox class="my-input" v-model="tipoPonderacion" :items="tiposPonderacion" :loading="tiposPonderacion == null" :disabled="tiposPonderacion == null" data-vv-name="TipoPonderacion" name="tipoPonderacion" item-value="codigo" item-text="codigo" label="Tipo Ponderacion" v-validate="'required|verify_ponderacion|max:10'" :rules="verify_ponderacion" :error-messages="errors.collect('tipoPonderacion')"></v-combobox>
                            </v-flex>
                            
                            <v-flex xs12 sm6>
                                <v-combobox class="my-input" v-model="exclusividad" data-vv-name="Exclusividad" name="exclusividad" :loading="exclusividades == null" :items="exclusividades" item-value="codigo" item-text="descripcion" label="Exclusividad" v-validate="'required|verify_exclusividad|max:4'" :rules="verify_exclusividad" :error-messages="errors.collect('exclusividad')"></v-combobox>
                            </v-flex>
                            <v-flex xs12 sm6>
                                <v-combobox class="my-input" v-model="areaDefinidora" data-vv-name="Area Definidora" name="areaDefinidora" :items="areasDefinidoras" :loading="areasDefinidoras == null" item-value="codigo" item-text="descripcion" label="Area Definidora" v-validate="'required|verify_areaDefinidora|max:50'" :rules="verify_areaDefinidora" :error-messages="errors.collect('areaDefinidora')"></v-combobox>
                            </v-flex>
                            <v-flex><span style="font-size: 1.3em; color:red">*Una vez guardada la hipotesis los datos no podr&aacute;n ser modificados</span></v-flex>
                        </v-layout>
                    </v-container>
                </v-card-text>
                <v-card-actions>
                    <v-spacer></v-spacer>
                    <v-btn color="primary" dark @click="saveCaratula">Guardar y enviar los casos a matriz</v-btn>
                    <v-btn color="red" dark @click="closeCaratula">Cancelar</v-btn>
                </v-card-actions>
            </v-card>
        </v-dialog>
    </div>

</template>

<script lang="ts">
    import {
        Component,
        Vue, Watch
    } from 'vue-property-decorator';
    import VueRouter from 'vue-router';
    import {namespace} from 'vuex-class';
    import Notificacion from '@/components/Notificacion.vue';
    import {buscarKeyEnMap,buscarListFormulariosEnMap,buscarCodDirEnImpuestoMap, buscarTipoDesvioEnTipoDesviosMap} from '@/helpers';
    import VeeValidate from 'vee-validate';
    import VueMask from 'v-mask'
    import Spinner from '@/components/Seleccionar/Spinner.vue';

    Vue.use(VeeValidate);
    Vue.use(VueMask);

    const store = namespace('SeleccionarStore');

    @Component({
        components: {
            Notificacion,
            Spinner
        }
    })
    export default class Caratula extends Vue {

        @store.State('goToHome') goToHome: boolean;
        @store.State('titulo') titulo: string;
        @store.State('mensajeHipotesis') mensajeHipotesis: string;
        @store.State('openCaratula') openCaratula: boolean;

        // Campos del formulario
        @store.State('codigoDeInstructivoSeleccionado') codigoDeInstructivoSeleccionado: number;
        @store.Mutation('SET_CODIGO_INSTRUCTIVO') SET_CODIGO_INSTRUCTIVO: Function;

        @store.State('tipoPeriodoSeleccionado') tipoPeriodoSeleccionado: string;

        @store.State('impuestos') impuestos: Array<any>;
        @store.State('impuestoSeleccionado') impuestoSeleccionado: number;
        @store.Action('getImpuestosSefi') getImpuestosSefi: Function;
        @store.Mutation('SET_IMPUESTO') SET_IMPUESTO: Function;
        @store.Mutation('SET_IMPUESTOS') SET_IMPUESTOS: Function;

        @store.State('formularios') formularios: Array<any>;
        @store.State('formulariosSeleccionados') formulariosSeleccionados: any;
        @store.Action('getFormularios') getFormularios: Function;
        @store.Mutation('SET_FORMULARIOS_SELECCIONADOS') SET_FORMULARIOS_SELECCIONADOS: Function;

        @store.State('origenes') origenes: Array<any>;
        @store.State('origenSeleccionado') origenSeleccionado: number;
        @store.Action('getOrigenes') getOrigenes: Function;
        @store.Mutation('SET_ORIGEN') SET_ORIGEN: Function;

        @store.State('conceptos') conceptos: Array<any>;
        @store.State('conceptoSeleccionado') conceptoSeleccionado: any;
        @store.Action('getConceptos') getConceptos: Function;
        @store.Mutation('SET_CONCEPTO') SET_CONCEPTO: Function;

        @store.State('tiposDirGral') tiposDirGral: Array<any>;
        @store.State('dirGralSeleccionado') dirGralSeleccionado: number;
        @store.Action('getTipos') getTipos: Function;
        @store.Mutation('SET_DIR_GRAL') SET_DIR_GRAL: Function;

        @store.State('exclusividades') exclusividades: Array<any>;
        @store.State('exclusividadSeleccionada') exclusividadSeleccionada: number;
        @store.Action('getExclusividades') getExclusividades: Function;
        @store.Mutation('SET_EXCLUSIVIDAD') SET_EXCLUSIVIDAD: Function;

        @store.State('areasDefinidoras') areasDefinidoras: Array<any>;
        @store.State('areaDefinidoraSeleccionada') areaDefinidoraSeleccionada: number;
        @store.Action('getAreasDefinidoras') getAreasDefinidoras: Function;
        @store.Mutation('SET_AREA_DEFINIDORA') SET_AREA_DEFINIDORA: Function;

        @store.State('tiposRelevancia') tiposRelevancia: number;
        @store.State('tiposRelevanciaSeleccionado') tiposRelevanciaSeleccionado: number;
        @store.Action('getTiposRelevancia') getTiposRelevancia: Function;
        @store.Mutation('SET_TIPO_RELEVANCIA') SET_TIPO_RELEVANCIA: Function;

        @store.State('tiposPonderacion') tiposPonderacion: number;
        @store.State('tipoPonderacionSeleccionado') tipoPonderacionSeleccionado: string;
        @store.Action('getTiposPonderacion') getTiposPonderacion: Function;
        @store.Mutation('SET_TIPO_PONDERACION') SET_TIPO_PONDERACION: Function;

        @store.State('tiposDesvios') tiposDesvios: Array<any>;
        @store.State('tipoDesvioSeleccionado') tipoDesvioSeleccionado: number;
        @store.Action('getTiposDesvio') getTiposDesvio: Function;
        @store.Mutation('SET_TIPO_DESVIO') SET_TIPO_DESVIO: Function;

        @store.State('nombreHipotesis') hipNombre: string;
        @store.Mutation('SET_NOMBRE_HIPOTESIS') SET_NOMBRE_HIPOTESIS: Function;

        @store.State('descripcionHipotesis') hipDescripcion: string;
        @store.Mutation('SET_DESCRIPCION_HIPOTESIS') SET_DESCRIPCION_HIPOTESIS: Function;

        @store.State('objetivoHipotesis') hipObjetivo: string;
        @store.Mutation('SET_OBJETIVO_HIPOTESIS') SET_OBJETIVO_HIPOTESIS: Function;

        @store.State('showSeleccionarSpinner') showSeleccionarSpinner: boolean;
        @store.Mutation('SET_SHOW_SELECCIONAR_SPINNER') SET_SHOW_SELECCIONAR_SPINNER: Function;

        // Boton de guardado
        @store.Action('saveHipotesis') saveHipotesis: Function;

        @store.Mutation('SHOW_CARATULA') SHOW_CARATULA: Function;


        @store.State('caratulaValida') caratulaValida: boolean;
        @store.State('universo') universo: Object;

        @store.Mutation('CLEAN_SELECCIONES') CLEAN_SELECCIONES: Function;
        @store.Mutation('CLEAN_SELECCIONES_CARATULA') CLEAN_SELECCIONES_CARATULA: Function;
        @store.Mutation('CLEAN_PERIODO') CLEAN_PERIODO: Function;
        @store.Mutation('REMOVE_ALL_DIMENSIONES_SELECCIONADAS') REMOVE_ALL_DIMENSIONES_SELECCIONADAS: Function;
        @store.Mutation('REMOVE_ALL_FILTROS_SELECCIONADOS') REMOVE_ALL_FILTROS_SELECCIONADOS: Function;        

        @store.Mutation('SET_TITULO') SET_TITULO: Function;

        @store.Mutation('SET_CARATULA_VALIDA') SET_CARATULA_VALIDA: Function;
        @store.Mutation('SET_NOTIFICACION') SET_NOTIFICACION: Function;

        menuPeriodoDesde: boolean = false;
        menuPeriodoHasta: boolean = false;
        listImpuestos: Array<any> = [];
        tipoImpuesto: String ='';

        beforeMount() {
            this.CLEAN_SELECCIONES_CARATULA();
            this.getExclusividades();
            this.getConceptos();
            this.getTipos();
            this.getAreasDefinidoras();
            this.getTiposRelevancia();
            this.getTiposPonderacion();
            this.getTiposDesvio();
            this.getFormularios()
            
            this.formatListaImpuesto(this.impuestos);
        }
        created(){
            this.validateLists();  
        }

        formatListaImpuesto(impuestos){
            for (let i = 0; i < impuestos.length; i++) {
                var imp = impuestos[i];
                var props = Object.getOwnPropertyNames(imp);
                this.listImpuestos.push({
                    codigo: imp["codigo"],
                    descripcion: imp["descripcion"],
                    perVto: imp["perVto"],
                    label: imp["codigo"] + " - " + imp["descripcion"]
                });
            }
        }

        validateLists(){
           VeeValidate.Validator.extend('verify_tipoH', {
                getMessage: (field) => `Valor incorrecto/requerido.`,
                validate: (value) => new Promise(resolve => {
                resolve({
                    valid: value && (buscarKeyEnMap(this.tiposDirGral, value)!= undefined)
                    });
                })
            });   
            VeeValidate.Validator.extend('verify_ponderacion', {
                getMessage: (field) => `Valor incorrecto/requerido.`,
                validate: (value) => new Promise(resolve => {
                resolve({
                    valid: value && (buscarKeyEnMap(this.tiposPonderacion, value)!= undefined)
                    });
                })
            });   

            VeeValidate.Validator.extend('verify_desvio', {
                getMessage: (field) => `Valor incorrecto/requerido.`,
                validate: (value) => new Promise(resolve => {
                resolve({
                    valid: value
                    });
                })
            });   
            
            VeeValidate.Validator.extend('verify_exclusividad', {
                getMessage: (field) => `Valor incorrecto/requerido.`,
                validate: (value) => new Promise(resolve => {
                resolve({
                    valid: value && (buscarKeyEnMap(this.exclusividades, value)!= undefined)
                    });
                })
            });   
            VeeValidate.Validator.extend('verify_areaDefinidora', {
                getMessage: (field) => `Valor incorrecto/requerido.`,
                validate: (value) => new Promise(resolve => {
                resolve({
                    valid: value && (buscarKeyEnMap(this.areasDefinidoras, value)!= undefined)
                    });
                })
            });   
            VeeValidate.Validator.extend('verify_origen', {
                getMessage: (field) => `Valor incorrecto/requerido.`,
                validate: (value) => new Promise(resolve => {
                resolve({
                    valid: value && (buscarKeyEnMap(this.origenes, value)!= undefined)
                    });
                })
            });   
            VeeValidate.Validator.extend('verify_concepto', {
                getMessage: (field) => `Valor incorrecto/requerido.`,
                validate: (value) => new Promise(resolve => {
                resolve({
                    valid: value && (buscarKeyEnMap(this.conceptos, value)!= undefined)
                    });
                })
            }); 
            VeeValidate.Validator.extend('verify_impuesto', {
                getMessage: (field) => `Valor incorrecto/requerido.`,
                validate: (value) => new Promise(resolve => {
                resolve({
                    valid: value && (this.isValidoImpuestoSeleccionado(value)!= undefined)
                    });
                })
            });   
            VeeValidate.Validator.extend('verify_formulario', {
                getMessage: (field) => `Valor incorrecto/requerido.`,
                validate: (value) => new Promise(resolve => {
                resolve({
                    valid: value && (buscarListFormulariosEnMap(this.formularios, value)!= undefined)
                    });
                })
            });   
            VeeValidate.Validator.extend('verify_relevancia', {
                getMessage: (field) => `Valor incorrecto/requerido.`,
                validate: (value) => new Promise(resolve => {
                resolve({
                    valid: value && (buscarKeyEnMap(this.tiposRelevancia, value)!= undefined)
                    });
                })
            });             
        }

        forceUppercase(e, o, prop) {
            let start = e.target.selectionStart;
            e.target.value = e.target.value.toUpperCase();
            this.$set(o, prop, e.target.value);
            e.target.setSelectionRange(start, start);
        }

        get verify_Text() {
            return [v => !!v || 'Valor incorrecto/requerido'];
        }

        get verify_tipoH() {
            return [v => !!v || 'Valor requerido',
                    v => {
                            let x = buscarKeyEnMap(this.tiposDirGral, v);
                            if(x!= undefined){
                                return true;
                            }else{ 
                                return "Valor incorrecto." ;
                            }       
                        }];    
        }

        isValidoImpuestoSeleccionado(v){
            let x = buscarKeyEnMap(this.impuestos, v);
            if(x!= undefined){
                if(!(x.perVto=='A' && this.tipoPeriodoSeleccionado=='C')){
                    return x;
                }               
            } 
            return undefined;
        }

        get verify_impuesto() {
            return [v => !!v || 'Valor requerido',
                    v => {
                        if(this.isValidoImpuestoSeleccionado(v)==undefined){
                            return "Valor incorrecto/El impuesto seleccionado no es compatible con el Tipo de periodo." ;
                        } else{ 
                            return true ;
                        }     
                    }]; 
        }

        get verify_formulario() {
            return [v => !!v || 'Valor requerido',
                    v => {
                        let x = buscarListFormulariosEnMap(this.formularios, v);
                        if(x!= undefined){
                            return true;
                        }else{ 
                            return "Valor incorrecto." ;
                        }       
                    }];  
        }

        get verify_concepto() {
            return [v => !!v || 'Valor requerido',
                    v => {
                        let x = buscarKeyEnMap(this.conceptos, v);
                        if(x!= undefined){
                            return true;
                        }else{ 
                            return "Valor incorrecto." ;
                        }       
                    }]; 
        }

        get verify_origen() {
            return [v => !!v || 'Valor requerido',
                    v => {
                        let x = buscarKeyEnMap(this.origenes, v);
                        if(x!= undefined){
                            return true;
                        }else{ 
                            return "Valor incorrecto." ;
                        }       
                    }]; 
        }

        get verify_exclusividad() {
            return [v => !!v || 'Valor requerido',
                    v => {
                        let x = buscarKeyEnMap(this.exclusividades, v);
                        if(x!= undefined){
                            return true;
                        }else{ 
                            return "Valor incorrecto." ;
                        }       
                    }]; 
        }

        get verify_areaDefinidora() {
            return [v => !!v || 'Valor requerido',
                    v => {
                        let x = buscarKeyEnMap(this.areasDefinidoras, v);
                        if(x!= undefined){
                            return true;
                        }else{ 
                            return "Valor incorrecto." ;
                        }       
                    }];         
        }

        get verify_relevancia() {
            return [v => !!v || 'Valor requerido',
                    v => {
                        let x = buscarKeyEnMap(this.tiposRelevancia, v);
                        if(x!= undefined){
                            return true;
                        }else{ 
                            return "Valor incorrecto." ;
                        }       
                    }]; 
        }

        get verify_ponderacion() {
            return [v => buscarKeyEnMap(this.tiposPonderacion, v) != undefined || "Valor incorrecto/requerido."];
        }

        get verify_desvio() {
            return [v => !!v || 'Valor requerido',
                    v => {
                        let x = buscarKeyEnMap(this.tiposDesvios,v);
                        if(x!= undefined){
                            return true;
                        }else{ 
                            return "Valor incorrecto." ;
                        }       
                    }]; 
        }

        get show() {
            return this.openCaratula;
        }

        get tipoDesvio() {
            return this.tipoDesvioSeleccionado;
        }

        set tipoDesvio(value) {
            this.SET_TIPO_DESVIO(value);
        }

        get codigoDeInstructivo() {
            return this.codigoDeInstructivoSeleccionado;
        }

        set codigoDeInstructivo(value) {
            this.SET_CODIGO_INSTRUCTIVO(value);
        }

        get dirGral() {
            return this.dirGralSeleccionado;
        }

        set dirGral(value) {
            this.SET_DIR_GRAL(value);
        }

        get impuesto() {
            return this.impuestoSeleccionado;
        }

        set impuesto(value) {
            this.SET_IMPUESTO(value);
        }

        async changeDireccion() {
            if (this.dirGralSeleccionado) {
                let direccion = JSON.parse(JSON.stringify(this.dirGralSeleccionado));
                let tipo = direccion.descripcion;
                this.tipoImpuesto = "";
                switch(tipo){
                    case "DGI":
                        this.tipoImpuesto="I";
                        break;
                    default:
                        this.tipoImpuesto="P";
                        break;
                }
                this.SET_IMPUESTO('');                
                this.getImpuestoSefi(this.tipoImpuesto);
            }
        }

        getImpuestoSefi(codigo){
            let listImpuestos = [];
            if(codigo!=null){
                listImpuestos = buscarCodDirEnImpuestoMap(codigo,this.impuestos);
            }            
            this.listImpuestos = [];
            this.formatListaImpuesto(listImpuestos);            
        }

        /*getTipoDesvio(desvio, map){
            let tipoDesvio; 
            if(desvio && desvio.codigo!=null){
                tipoDesvio = buscarTipoDesvioEnTipoDesviosMap(desvio.codigo, map)[0];
            }            
            return tipoDesvio
        }*/

        get formulario() {
            return this.formulariosSeleccionados;
        }

        set formulario(value) {
            this.SET_FORMULARIOS_SELECCIONADOS(value);
        }

        get origen() {
            return this.origenSeleccionado;
        }

        set origen(value) {
            this.SET_ORIGEN(value);
        }

        get concepto() {
            return this.conceptoSeleccionado;
        }

        set concepto(value) {
            this.SET_CONCEPTO(value);
        }        

        get exclusividad() {
            return this.exclusividadSeleccionada;
        }

        set exclusividad(value) {
            this.SET_EXCLUSIVIDAD(value);
        }

        get areaDefinidora() {
            return this.areaDefinidoraSeleccionada;
        }

        set areaDefinidora(value) {
            this.SET_AREA_DEFINIDORA(value);
        }

        set nombreHipotesis(value) {
            this.SET_NOMBRE_HIPOTESIS(value);
        }

        get nombreHipotesis() {
            return this.hipNombre;
        }

        set descripcionHipotesis(value) {
            this.SET_DESCRIPCION_HIPOTESIS(value);
        }

        get descripcionHipotesis() {
            return this.hipDescripcion;
        }

        set objetivoHipotesis(value) {
            this.SET_OBJETIVO_HIPOTESIS(value);
        }

        get objetivoHipotesis() {
            return this.hipObjetivo;
        }

        get tipoRelevancia() {
            return this.tiposRelevanciaSeleccionado;
        }

        set tipoRelevancia(value) {
            this.SET_TIPO_RELEVANCIA(value);
        }

        get tipoPonderacion() {
            return this.tipoPonderacionSeleccionado;
        }

        set tipoPonderacion(value) {
            this.SET_TIPO_PONDERACION(value);
        }

        get showSpinner() {
            return this.showSeleccionarSpinner;
        }

        set showSpinner(value) {
            this.SET_SHOW_SELECCIONAR_SPINNER(value);
        }

        get universoComputed() {
            return this.universo;
        }

        set universoComputed(value) {
//            this.SET_UNIVERSO
        }

        async closeCaratula() {
            await this.SHOW_CARATULA(false);
        }

        async changeConcepto() {
            if (this.conceptoSeleccionado) {
                this.SET_ORIGEN('');
                this.getOrigenes(this.conceptoSeleccionado.codigo);
            }
        }      

        validarCaratula() {
            if (
                !this.dirGralSeleccionado ||
                !this.codigoDeInstructivoSeleccionado ||
                !this.impuestoSeleccionado ||
                !this.origenSeleccionado ||
                !this.conceptoSeleccionado ||
                !this.exclusividadSeleccionada ||
                !this.tiposRelevanciaSeleccionado ||
                !this.tipoPonderacionSeleccionado) {

                this.SET_CARATULA_VALIDA(false);
            }
            else {
                this.SET_CARATULA_VALIDA(true);
            }
        }

        saveCaratula() {
            this.$validator.validateAll()
            .then(result => {
                this.validarCaratula();
                let item= this.$validator.errors.items[0];
                if (!result) {
                    let msj = "El campo " + item.field + " es obligatorio";
                    if(item.msg){
                        msj = item.msg;
                    }
                    this.SHOW_CARATULA(true);
                    this.SET_NOTIFICACION({titulo: "Error", color: "red", mensaje: "El campo " + item.field + " es obligatorio", goToHome: false, goToCampana: false});
                    return;
                }
                if (!this.caratulaValida) {
                    this.SET_NOTIFICACION({titulo: "Error", color: "red", mensaje: "Debe completar los campos requeridos para poder guardar la Hipotesis", goToHome: false, goToCampana: false});
                    return;
                }
                if (!this.universoComputed.hasOwnProperty("columns")) {
                    //si no tiene le object columns es porque no exploro
                    this.SET_NOTIFICACION({titulo: "Error", color: "red", mensaje: "Debe completar la selección para poder guardar la caratula", goToHome: false, goToCampana: false});
                    return;
                }
                this.showSpinner = true;
                this.saveHipotesis()
                    .then((response) => {
                        this.showSpinner = false;
                        this.REMOVE_ALL_DIMENSIONES_SELECCIONADAS();
                        this.REMOVE_ALL_FILTROS_SELECCIONADOS();
                        this.CLEAN_PERIODO();
                        this.SET_NOTIFICACION({titulo: "Hipotesis", mensaje: "Hipotesis guardada con exito", color: "green", goToHome: true,goToCampana: false});
                    })
                    .catch((e) => {
                        this.showSpinner = false;
                        this.SET_NOTIFICACION({titulo: e.codigo, color: "red", mensaje: e.descripcion, goToHome: false, goToCampana: false});
                    });

                this.SHOW_CARATULA(false);
            })
            ;
        }
    }
</script>

<style>
    .my-input input {
        text-transform: uppercase
    }
</style>