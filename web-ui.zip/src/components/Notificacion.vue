<template>
    <div class="text-xs-center">
        <v-dialog v-model="dialog" persistent width="500">
            <v-card>
                <v-card-title :class="'headline ' + color + ' white--text'" primary-title>
                    {{titulo}}
                </v-card-title>
                <v-card-text>
                    {{mensaje}}
                </v-card-text>
                <v-divider></v-divider>
                <v-card-actions>
                    <v-spacer></v-spacer>
                    <v-btn v-if="path!=''" color="blue darken-1" flat="flat" @click="cerarDialog()">Cancelar</v-btn>
                    <v-btn id="btnAceptarNotificacion" :color="color + ' white--text '" @click="closeit()">Aceptar</v-btn>
                </v-card-actions>
            </v-card>
        </v-dialog>
    </div>
</template>

<script lang="ts">
    import {
        Component,
        Prop,
        Vue
    } from 'vue-property-decorator';
    import {State,namespace} from 'vuex-class';

    const store = namespace('SeleccionarStore');


    @Component
    export default class Notificacion extends Vue {
        @Prop(String) mensaje!: string;
        @Prop({default: 'red'}) color!: string;
        @Prop({default: 'Error'}) titulo!: string;
        @Prop({default: 'false'}) goToHome: boolean;
        @Prop({default: 'false'}) goToCampana: boolean;
        @Prop() saveCampania: boolean;
        @Prop() path: string;    
        @store.Mutation('CLEAR_NOTIFICACION') clear: Function ;
        dialog : boolean = true;

        cerarDialog(){
            this.dialog = false;  
            this.$emit('closeAlertDFE',false);
            this.clear();            
        }
        closeit(){
            this.dialog = false;                     
            if(this.path=='' && JSON.parse(this.goToHome.toString())){
                this.$router.push({path: '/Hipotesis'}); 
            } else if(JSON.parse(this.goToCampana.toString())){
                this.$router.push({path: '/Ventanilla'}); 
            } else {
                if(this.path!=''){
                    this.$router.push({path: this.path}); 
                }                 
            }
            this.$emit('enviarDFE',true);  
            this.$emit('close');
        }
    }
</script>