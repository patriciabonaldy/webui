import "vuetify/dist/vuetify.min.css";
import "@fortawesome/fontawesome-free/css/all.css";
import "material-design-icons-iconfont/dist/material-design-icons.css";
import Vue from "vue";
import App from "./App.vue";
import router from "./router";
import store from "./store";
import "./registerServiceWorker";
import Vuetify from "vuetify";
import VeeValidate from "vee-validate";
import { GChart } from "vue-google-charts";
import "./class-component-hooks";
import moment from "moment";
import InfiniteScroll from "vue-infinite-scroll";
/*import VueMoment from "vue-moment";

Vue.use(VueMoment, {
  moment
});*/

Vue.filter("formatDate", function(value) {
  if (value) {
    return moment(String(value)).format("MM/DD/YYYY hh:mm");
  }
});

Vue.filter("formatDate2", function(value) {
  if (value) {
    return moment(String(value)).format("DD/MM/YYYY");
  }
});

Vue.config.productionTip = false;

Vue.use(Vuetify, { iconfont: "fa" });
Vue.use(VeeValidate);
Vue.use(GChart);
Vue.use(InfiniteScroll);

new Vue({
  data() {
    return {
      publicPath: process.env.BASE_URL
    };
  },
  router,
  store,
  render: h => h(App)
}).$mount("#app");
