<template>
    <div class="containerFiltro">
        <SideMenu style="margin-top: 50px;max-height: calc(100% - 5px);height: 94%;"/>
        <QueryBuilder/>
        <Caratula v-if="openCaratula"/>
        <EnviarDFE v-if="openEnviarDFE"/>
        <Periodo/>
        <div v-if="showSeleccionarSpinner">
            <Spinner/>
        </div>
    </div>
</template>

<script lang="ts">
    import {Component, Vue} from 'vue-property-decorator';
    import SideMenu from '@/components/Seleccionar/SideMenu.vue';
    import Caratula from '@/components/Seleccionar/Caratula.vue';
    import EnviarDFE from '@/components/Seleccionar/EnviarDFE.vue';
    import Periodo from '@/components/Seleccionar/Periodo.vue';
    import QueryBuilder from '@/components/Seleccionar/QueryBuilder.vue';
    import Spinner from '@/components/Seleccionar/Spinner.vue';

    import {namespace} from 'vuex-class';

    const store = namespace('SeleccionarStore');

    @Component({
        components: {
            SideMenu,
            Caratula,
            EnviarDFE,
            Periodo,
            QueryBuilder,
            Spinner
        }
    })
    export default class Seleccionar extends Vue {
        @store.State('openCaratula') openCaratula: boolean;
        @store.State('openEnviarDFE') openEnviarDFE: boolean;
        @store.State('showSeleccionarSpinner') showSeleccionarSpinner: boolean;

        @store.Mutation('CLEAN_SELECCIONES') CLEAN_SELECCIONES: Function;
        @store.Mutation('SHOW_PERIODO') SHOW_PERIODO: Function;


        async beforeMount() {
            await this.SHOW_PERIODO(true);
            await this.CLEAN_SELECCIONES();
        }

        async beforeDestroy() {
            await this.CLEAN_SELECCIONES();
        }

        changePeriodo() {
            this.SHOW_PERIODO(true);
        }

    }
</script>

<style>
    .moveInUp-enter-active {
        animation: fadeIn 1s ease-in;
    }

    @keyframes fadeIn {
        0% {
            opacity: 0;
        }
        50% {
            opacity: 0.5;
        }
        100% {
            opacity: 1;
        }
    }

    .containerFiltro {
        -webkit-box-flex: 1;
        -ms-flex: 1 1 100%;
        flex: 1 1 80%;
        margin-left: 22%;
        padding: 24px;
        /*width: auto;*/
    }
</style>