<template>
    <v-container align-content-center fluid>
        <v-card class="elevation-12">
            <v-toolbar flat>
                <div key="search" class="font-weight-light">
                    <input type="text" class="inputText mdc-text-field__input" id="css-only-text-field-box" v-model="word" placeholder="Search anything...">
                </div>
                <v-spacer></v-spacer>
                <v-btn icon>
                    <v-icon>search</v-icon>
                </v-btn>
            </v-toolbar>
        </v-card>
        <v-spacer></v-spacer>
        <v-layout column align-center justify-center >
            <div v-infinite-scroll="loadMore" infinite-scroll-disabled="busy" infinite-scroll-distance="limit">
                <CardVentanilla v-for="(dfe, i) in listCampaniasComputed" :key="i"  :detailDFE="dfe" :displayList="displayList"></CardVentanilla>
                <v-spacer></v-spacer>
                <div v-if="listCampaniasComputed != null && listCampaniasComputed.length == 0">No hay resultados :(</div>                
            </div>    
        </v-layout>   
        <div v-if="showHipotesisSpinner">
            <Spinner/>
        </div>
    </v-container>
</template>

<script lang="ts">
    import {Component, Prop, Watch, Vue} from 'vue-property-decorator';
    import {namespace} from 'vuex-class';
    import Slider from 'vue-plain-slider';
    import CardVentanilla from '@/components/Ventanilla/CardVentanilla.vue';
    import Spinner from '@/components/Seleccionar/Spinner.vue';
    import {buscarCampaniaEnMap} from '../helpers';


    const store = namespace('SeleccionarStore');
    @Component({
        components: {
            CardVentanilla, Spinner
        }
    })
    export default class Ventanilla extends Vue {        
        @store.Action('getAllCampaniasOfState') getAllCampaniasOfState: Function;
        @store.Action('getAllCampanias') getAllCampanias: Function;
        @store.State('listadoCampanias') listadoCampanias: Array<any>;
        @store.State('showHipotesisSpinner') showHipotesisSpinner: boolean;
        @store.Mutation('SET_SHOW_HIPOTESIS_SPINNER') SET_SHOW_HIPOTESIS_SPINNER: Function;
        
        listCampanias: Array<any> =[];
        displayList: Boolean = false;
        word: String = '';
        offsetTop: 0;
        busy: Boolean = false;
        limit: Number = 2;


        setDisplay(value) {
            this.displayList = value;
        }

        onScroll (e) {
            this.offsetTop = e.target.scrollTop
        }

        get changeDisplay() {
            return this.displayList;
        }

        @Watch('word')
        async wordChange(val: string, oldVal: string) {
            this.listCampaniasComputed = await this.getCampanias();
        }

        /*@Watch('listadoCampanias')
        reloadCampanias() {
            //this.listCampanias = this.getCampanias();
            this.listCampaniasComputed = this.listadoCampanias;
        }*/

        getCampanias() {
            if (this.word != '' && this.word) {
                let buscarHipotesiEnMap = buscarCampaniaEnMap(this.word, this.listadoCampanias);
                return buscarHipotesiEnMap;
            } else {
                //this.listCampanias =[];
                this.setCampanias();
            }
            return this.listCampanias;
        }

        get listCampaniasComputed() {
            return this.listCampanias;
        }

        set listCampaniasComputed(value) {
            this.listCampanias = value;            
        }

        loadMore() {
            this.busy = true;
            this.SET_SHOW_HIPOTESIS_SPINNER(this.busy);
            if(this.listadoCampanias.length==0){
                this.getAllCampanias().then((x) => {
                    this.setCampanias();
                }); 
            } else {
                this.setCampanias();
            }
                      
        }

        setCampanias(){
            this.getAllCampaniasOfState().then((x) => {
                const append = x.slice(
                    this.listCampanias.length,
                    this.listCampanias.length +  Number(this.limit)
                );
                this.listCampanias = this.listCampanias.concat(append);
                let logCampanias = this.listCampanias.length ;
                this.busy = false;
                this.SET_SHOW_HIPOTESIS_SPINNER(false);
                if(logCampanias>=x.length){
                    this.busy = true;
                }
                
                
            });  
        }
    }

</script>
<style>
    .is-flex {
        display: flex;
        flex-wrap: wrap;
        margin-top: 25px;
    }

    .loadingItem {
        align-items: center;
        justify-content: center;
        display: flex;
    }

    .is-flex > [class*='col-'] {
        display: flex;
        flex-direction: column;
        margin-right: 5px;
        margin-bottom: 10px;
    }

    .action-panel {
        margin-bottom: 10px;
        margin-right: 5px;
    }

</style>