<template>
    <v-container align-content-center fluid>
        <v-card class="elevation-12">
            <v-toolbar flat>
                <div key="search" class="font-weight-light">
                    <input type="text" class="inputText mdc-text-field__input" id="css-only-text-field-box" v-model="word" placeholder="Search anything...">
                </div>
                <v-spacer></v-spacer>
                <v-btn icon>
                    <v-icon>search</v-icon>
                </v-btn>
            </v-toolbar>
        </v-card>
        <CarouselHip :keyHip="word" :hipotesis="hipotesis" :misHipotesis="misHipotesis"></CarouselHip>
        <div v-if="showHipotesisSpinner">
            <Spinner/>
        </div>
    </v-container>
</template>
<script lang="ts">
    import {Component, Prop, Vue} from 'vue-property-decorator';
    import {namespace} from 'vuex-class';
    import CarouselHip from '@/components/Hipotesis/CarouselHip.vue';
    import ChartHip from '@/components/Hipotesis/ChartHip.vue';
    import DetailHip from '@/components/Hipotesis/DetailHip.vue';
    import Spinner from '@/components/Seleccionar/Spinner.vue';

    const store = namespace('SeleccionarStore');

    @Component({
        components: {
            CarouselHip, ChartHip, DetailHip, Spinner
        }
    })
    export default class Hipotesis extends Vue {
        @store.State('showDetailHip') showDetailHip: Boolean;
        @store.State('hipotesis') hipotesis: Array<any>;
        @store.State('misHipotesis') misHipotesis: Array<any>;
        @store.State('showHipotesisSpinner') showHipotesisSpinner: boolean;

        @store.Action('getAllHipotesis') getAllHipotesis: Function;
        @store.Action('getMisHipotesis') getMisHipotesis: Function;

        @store.Mutation('SET_SHOW_HIPOTESIS_SPINNER') SET_SHOW_HIPOTESIS_SPINNER: Function;
        
        word: String = '';
        hipotesi: Object;

        beforeMount() {
            let loadingMisHipotesis = true;
            let loadingAllHipotesis = true;
            this.SET_SHOW_HIPOTESIS_SPINNER(loadingAllHipotesis && loadingMisHipotesis);
            this.getMisHipotesis().then((x) => {
                loadingMisHipotesis = false;
                this.SET_SHOW_HIPOTESIS_SPINNER(loadingAllHipotesis && loadingMisHipotesis);
            });
            this.getAllHipotesis().then((x) => {
                loadingAllHipotesis = false;
                this.SET_SHOW_HIPOTESIS_SPINNER(loadingAllHipotesis && loadingMisHipotesis);
            });
        }

        get show() {
            return this.showDetailHip;
        }
    }

</script>
<style>
    .mdc-card {
        background: #fff;
        -webkit-box-shadow: 0 1px 6px -1px rgba(0, 0, 0, 0.15);
        -moz-box-shadow: 0 1px 6px -1px rgba(0, 0, 0, 0.15);
        box-shadow: 0 1px 6px -1px rgba(0, 0, 0, 0.15);
    }

    .pl-2 {
        padding-right: 2rem;
    }

    .pl-2 {
        padding-left: 2rem;
    }

    .py-3 {
        padding-top: 3rem;
        padding-bottom: 3rem;
    }

    .flex-row {
        -webkit-flex-direction: row;
        flex-direction: row;
    }

    .d-flex {
        display: -webkit-flex;
        display: flex;
    }

    .stretch-card {
        display: -webkit-flex;
        display: flex;
    }

    .mdc--tile.mdc--tile-danger {
        background: #e53a36;
        -webkit-box-shadow: 0px 9px 19px -9px rgba(229, 58, 54, 0.65);
        -moz-box-shadow: 0px 9px 19px -9px rgba(229, 58, 54, 0.65);
        box-shadow: 0px 9px 19px -9px rgba(229, 58, 54, 0.65);
    }

    .mdc--tile.mdc--tile-success {
        background: #4ca74f;
        -webkit-box-shadow: 0px 9px 19px -9px rgba(76, 167, 79, 0.65);
        -moz-box-shadow: 0px 9px 19px -9px rgba(76, 167, 79, 0.65);
        box-shadow: 0px 9px 19px -9px rgba(76, 167, 79, 0.65);
    }

    .mdc--tile.mdc--tile-warning {
        background: #fea11d;
        -webkit-box-shadow: 0px 9px 19px -9px rgba(254, 161, 29, 0.65);
        -moz-box-shadow: 0px 9px 19px -9px rgba(254, 161, 29, 0.65);
        box-shadow: 0px 9px 19px -9px rgba(254, 161, 29, 0.65);
    }

    .mdc--tile.mdc--tile-primary {
        background: #11b2c6;
        -webkit-box-shadow: 0px 9px 19px -9px rgba(17, 178, 198, 0.65);
        -moz-box-shadow: 0px 9px 19px -9px rgba(17, 178, 198, 0.65);
        box-shadow: 0px 9px 19px -9px rgba(17, 178, 198, 0.65);
    }

    .mdc--tile {
        width: 86px;
        height: 86px;
        display: -webkit-flex;
        display: flex;
        -webkit-align-items: center;
        align-items: center;
        -webkit-justify-content: center;
        justify-content: center;
    }

    .rounded {
        -webkit-border-radius: 3px;
        -moz-border-radius: 3px;
        -ms-border-radius: 3px;
        -o-border-radius: 3px;
        border-radius: 3px;
    }

    .inputText {
        min-width: 800px;
    }

</style>