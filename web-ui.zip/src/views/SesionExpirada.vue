<template>
    <div class="text-xs-center">
        <v-dialog persistent width="500px" v-model="show">
            <v-card>
                <v-card-title class="headline primary white--text" primary-title>
                    Sesion expirada
                </v-card-title>
                <v-card-text style="text-align:center">
                    Su sesi&oacute;n ha expirado. Por favor vuelva a ingresar para continuar.
                </v-card-text>
                <v-divider></v-divider>
                <v-card-actions>
                    <v-spacer></v-spacer>
                    <v-btn color="error" @click="closeit()">Ir a inicio</v-btn>
                </v-card-actions>
            </v-card>
        </v-dialog>
    </div>
</template>

<script lang="ts">
    import {Component, Prop, Watch, Vue} from 'vue-property-decorator';
    import {namespace} from 'vuex-class';
    import {buscarKeyEnMap} from '@/helpers';
    import VeeValidate from 'vee-validate';

    @Component({
        components: {
        }
    })

    export default class SesionExpirada extends Vue {
        dialog: boolean = true;

        get show() {
            return this.dialog;
        }

        closeit(evt) {
            this.dialog = false;
            window.location.href = 'https://authint.afip.gob.ar/persona/'
        }
    }
</script>
<style scoped>
    .mpresentaciones span {
        color: #17a2b8;
        border-left: 2px solid #eee;
        padding: 0px 30px;
        margin-left: 13px;
        font-size: 17px;
    }

    #per .display-4 {
        font-size: 2.5rem;
        font-weight: 300;
        margin-bottom: 29px;
        margin-top: -49px;
    }

</style>
