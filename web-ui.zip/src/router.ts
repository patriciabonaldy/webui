import Vue from 'vue'
import Router from 'vue-router'
import Seleccionar from './views/Seleccionar.vue'
import Hipotesis from './views/Hipotesis.vue'
import Ventanilla from './views/Ventanilla.vue'

import Boards from './views/Boards.vue'
import SesionExpirada from './views/SesionExpirada.vue'
import store from './store';

Vue.use(Router)

export default new Router({
    routes: [
        {
            path: '/',
            component: Hipotesis,
        },
        {
            path: '/Seleccionar',
            name: 'Seleccionar',
            component: Seleccionar,           
            
        },
        {
            path: '/Hipotesis',
            name: 'Hipotesis',
            component: Hipotesis,
            beforeEnter: (to, from, next) => {
                let changeTab:Boolean = false;
                store.dispatch('SeleccionarStore/isFullPath').then(x => {
                    if(from && from.name=='Seleccionar' && !x.isValido){
                        if(x.hasDimensAndFilters){
                            store.dispatch('SeleccionarStore/showNotificacion', to.fullPath);
                        } else {
                            next();
                        }
                    } else {
                        store.dispatch('SeleccionarStore/clearFullPath').then(data => {
                            next();
                        }); 
                    }
                });    
            } 
        },
        {
            path: '/Ventanilla',
            name: 'Ventanilla',
            component: Ventanilla,
            beforeEnter: (to, from, next) => { 
                let changeTab:Boolean = false;
                store.dispatch('SeleccionarStore/isFullPath').then(x => {
                    changeTab = x;
                    if(from && from.name=='Seleccionar' && !x.isValido){
                        if(x.hasDimensAndFilters){
                            store.dispatch('SeleccionarStore/showNotificacion', to.fullPath);
                        } else {
                            next();
                        }
                    } else {
                        store.dispatch('SeleccionarStore/clearFullPath').then(data => {
                            next();
                        }); 
                    }
                });        
            } 
        },        
        {
            path: '/Boards',
            name: 'Boards',
            component: Boards,
            beforeEnter: (to, from, next) => { 
                let changeTab:Boolean = false;
                store.dispatch('SeleccionarStore/isFullPath').then(x => {
                    changeTab = x;
                    if(from && from.name=='Seleccionar' && !x.isValido){
                        if(x.hasDimensAndFilters){
                            store.dispatch('SeleccionarStore/showNotificacion', to.fullPath);
                        } else {
                            next();
                        }
                    } else {
                        store.dispatch('SeleccionarStore/clearFullPath').then(data => {
                            next();
                        }); 
                    }
                });        
            } 
        },
        {
            path: '/SesionExpirada',
            name: 'SesionExpirada',
            component: SesionExpirada,
            meta: {
                title: 'ERROR'
            },
        }
    ]
})
