export const getIcon = (tipo: string): string => {
    switch (tipo) {
        case 'number':
            return 'fas fa-hashtag';
        case 'string':
            return 'fas fa-font';
        case 'date':
            return 'fas fa-clock';
        case 'detail':
            return 'fas text-primary fa-lg fa-info-circle';
        default:
            break;
    }
}

export function sleep(milliseconds) {
    var start = new Date().getTime();
    for (var i = 0; i < 1e7; i++) {
        if ((new Date().getTime() - start) > milliseconds){
        break;
        }
    }
}

export function buscarHipotesisEnMap(word: String, map: Array<any>) {
    if (map) {
        return map.filter(value => {
            let matchConcepto = value.concepto.toLowerCase().indexOf(word.toLowerCase()) > -1;
            let matchNombre = value.nombreHipotesis.toLowerCase().indexOf(word.toLowerCase()) > -1;
            let matchDireccionGeneral = value.dirGral.toLowerCase().indexOf(word.toLowerCase()) > -1;
            let matchOrigen = value.origen.toLowerCase().indexOf(word.toLowerCase()) > -1;
            return matchConcepto || matchNombre || matchDireccionGeneral || matchOrigen;
        });
    }
}

export function buscarCampaniaEnMap(word: String, map: Array<any>) {
    if (map) {
        return map.filter(value => {
            //let matchIdCampania = value.idCampania.toString().toLowerCase().indexOf(word.toLowerCase()) > -1;
            let matchCodCampania = value.codCampania.toLowerCase().indexOf(word.toLowerCase()) > -1;
            return /*matchIdCampania ||*/ matchCodCampania;
        });
    }
}

export function buscarCodDirEnImpuestoMap(word: String, map: Array<any>) {
    if (map) {
        return map.filter(value => {
            let matchCodCampania = value.tipo.indexOf(word) > -1;
            return matchCodCampania;
        });
    }
}

export function buscarFiltroEnMapWhere(word, map) {
    return map.filter(value => value.campo.nombre.toLowerCase().indexOf(word.toLowerCase()) > -1);
}

export function buscarKeyEnMapbuscarTipoDesvioEnTipoDesviosMap(word: String, map: Array<any>) {
    if (map) {
        let desvio = map.filter(value => {
            let matchCodDesvio = value.codigo.indexOf(word) > -1;
            return matchCodDesvio;
        });
        return desvio[0];
    }
}


export function buscarKeyEnMap(map, searchValue) {
    if (searchValue == null || map == null)
        return undefined;
    for (let [key, value] of map.entries()) {
        if (isEquivalent(map[key], searchValue)) {
            return map[key];
        }
    }
    return undefined;
}

export function buscarListFormulariosEnMap(map, listValue) {
    let valido;
    let cont = 0;
    if (listValue == null || map == null)
        return undefined;
    for (let [key1, value1] of listValue.entries()) {  
        let key = listValue[key1];
        valido = buscarKeyEnMap(map, key);
        if(!valido)
            cont++;
    }    
    if(cont>0)
        return undefined;
    return valido;
}

export function isEquivalent(a, b) {
    // Create arrays of property names
    var aProps = Object.getOwnPropertyNames(a);
    var bProps = Object.getOwnPropertyNames(b);
    var propName = aProps[0]; //get codigo
    var desc = a[aProps[1]];    //get descripcion

    if (a[propName] !== b[propName]) {
        return false;
    }
    return true;
}

export function formatPrice(value) {
    if(isNaN(value))
        return value;
    let val = (value / 1).toFixed(2).replace('.', ',');
    return val.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
}

export function formatNumber(value) {
    return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
}

export function hyphenate(value) {
    return value.replace(/(\S{3})(\S{4})(\S+)/, '$1-$2-$3')
}

export function formatSelect(value) {
    switch (value) {
        case 'SUM':
            return "Sumatoria de ";
        case 'AVG':
            return "Promedio de ";
        case 'COUNT':
            return "Ocurrencias de ";
        case 'COUNTDISTINCT':
            return "Variantes de ";
        case 'MIN':
            return "Minimo de ";
        case 'MAX':
            return "Maximo de ";
        default:
            break;
    }
}

export function getColorEstado(value) {
    switch (value) {
        case 'PE':
            return "orange";
        case 'PR':
            return "green";
        case 'ER':
            return "red";
        default:
            return "blue"
            break;
    }
}

export function getDescEstado(value) {
    switch (value) {
        case 'PE':
            return "Pendiente";
        case 'PR':
            return "Procesado";
        case 'ER':
            return "Error";
        default:
            return ""
            break;
    }
}

export function paginator(arr, perPage) {
    if (perPage < 1 || !arr) return () => [];

    return function (page) {
        const basePage = page * perPage;

        return page < 0 || basePage >= arr.length
            ? [] : arr.slice(basePage, basePage + perPage);
    };
}

export function getIdUltimaCorrida(map) {
    let idx = 0;
    let val = 0;
    if (map.length > 0) {
        val = map[0].idCorrida;
        for (let i = 1; i < map.length; i++) {
            if (map[i].idCorrida > val) {
                val = map[i].idCorrida;
                idx = i;
            }
        }
    }
    return idx;
}

 