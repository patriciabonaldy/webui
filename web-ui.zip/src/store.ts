import Vue from 'vue'
import Vuex from 'vuex'
import SeleccionarStore from '@/stores/SeleccionarStore'

Vue.use(Vuex)

const store = new Vuex.Store({
    modules:{
        SeleccionarStore
    }
});

export default store;