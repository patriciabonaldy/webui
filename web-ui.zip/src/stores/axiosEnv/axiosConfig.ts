import axios from 'axios';
import {namespace} from 'vuex-class';
import store from '@/store'
import MockAdapter from 'axios-mock-adapter'
import router from '@/router';

export const AXIOS = axios.create({
    baseURL: process.env.VUE_APP_API_URL
});

export const cancelToken = axios.CancelToken;
export const source = cancelToken.source();


AXIOS.interceptors.response.use(function (response) {
    return response;
}, error => {
    
    store.dispatch('SeleccionarStore/showBtnCancel', false);
    store.dispatch('SeleccionarStore/closeNotification');  
    if (error.__CANCEL__) {             
        store.dispatch('SeleccionarStore/showError', {codigo: "Error", descripcion: error.message});
        return Promise.reject(error.message);
    } else if (error.response == undefined) {
        store.dispatch('SeleccionarStore/showError', {codigo: "Error de conexion", descripcion: 'Ocurrio un error de red, vuelva a cargar la aplicacion porque los datos no seran guardados!'});
    } else if (error.response.status === 401) {
        router.push('SesionExpirada')
    } else if (error.response.status === 400) {
        store.dispatch('SeleccionarStore/showError', error.response.data);
    } else if (error.response.status === 403) {
        store.dispatch('SeleccionarStore/showError', error.response.data);
    } else if (error.response.data) {
        store.dispatch('SeleccionarStore/showError', error.response.data);
    } else {
        store.dispatch('SeleccionarStore/showError', {codigo: "Error desconocido", descripcion: "Ha ocurrido un error desconocido. Contactese con el administrador del sistema"});
    }

    return Promise.reject(error.response);
});
console.log(process.env.NODE_ENV);

export function getSource(){
    let cancelToken = axios.CancelToken;
    let source = cancelToken.source();
    return source;
}

if (process.env.NODE_ENV == "local-mock") {
    const cubo = [
        {
            id: "ft_contribuyentes",
            nombre: "Contribuyentes",
            fecha_actualizacion: "10/05/2018"
        },
        {
            id: "declas_factu",
            nombre: "DDJJ y Factura Electronica",
            fecha_actualizacion: "01/08/2018"
        }
    ];

    const dimension = [
        {
            nombre: "CUIT",
            columna: "CON_CUIT",
            tipo: "string"
        },
        {
            nombre: "Fecha inscripcion mono",
            columna: "CON_FECHA_MONO",
            tipo: "date"
        },
        {
            nombre: "Deuda",
            columna: "CON_DEUDA",
            tipo: "number"
        },
        {
            nombre: "Inscripto ley99999",
            columna: "CON_LEY9999",
            tipo: "string"
        },
        {
            nombre: "Nombre y apellido",
            columna: "CON_NOMBRE",
            tipo: "string"
        },
        {
            nombre: "IVA",
            columna: "IVA",
            tipo: "string"
        },
        {
            nombre: "Gastos",
            columna: "GASTOS",
            tipo: "string"
        },
        {
            nombre: "Erogaciones",
            columna: "EROGACIONES",
            tipo: "string"
        },
        {
            nombre: "Donaciones a terceros",
            columna: "DONACIONES",
            tipo: "string"
        },
        {
            nombre: "Multas",
            columna: "MULTAS",
            tipo: "string"
        },
        {
            nombre: "Hijos",
            columna: "HIJOS",
            tipo: "string"
        },
        {
            nombre: "Alicuota",
            columna: "ALICUOTA",
            tipo: "string"
        },
        {
            nombre: "Días",
            columna: "DIAS",
            tipo: "string"
        },
        {
            nombre: "Cantidad",
            columna: "CANTIDAD",
            tipo: "string"
        },
    ];
    const instructivo = [{
        codigo: 1,
        descripcion: "IDSA-12323"
    }, {
        codigo: 2,
        descripcion: "ASEW-89789"
    }, {
        codigo: 3,
        descripcion: "RRDS-3234"
    }, {
        codigo: 4,
        descripcion: "AAQW-1122"
    }];
    const exclusividad = [{
        codigo: -1,
        descripcion: "Ninguno"
    },
        {
            codigo: 1,
            descripcion: "SEFI"
        }, {
            codigo: 2,
            descripcion: "VERIFICA"
        }];

    const areaDefinidora = [{
        codigo: 1,
        descripcion: "DINEF"
    }, {
        codigo: 2,
        descripcion: "DPYNR"
    }, {
        codigo: 3,
        descripcion: "DPYNF"
    }, {
        codigo: 4,
        descripcion: "DICOMO"
    }];
    const impuesto = [
        {
            codigo: 1,
            descripcion: "F713"
        }, {
            codigo: 2,
            descripcion: "F749 v2"
        }, {
            codigo: 3,
            descripcion: "F311 v8"
        }, {
            codigo: 4,
            descripcion: "F578 v33"
        }
    ];
    const concepto = [{
        codigo: 1,
        descripcion: "concepto1"
    }, {
        codigo: 2,
        descripcion: "concepto23"
    }, {
        codigo: 3,
        descripcion: "abaaoaaoa"
    }, {
        codigo: 4,
        descripcion: "whatsaaaap"
    }];

    const tipoHipotesis = [{
        codigo: 1,
        descripcion: "DGI"
    }, {
        codigo: 2,
        descripcion: "DGA"
    }, {
        codigo: 3,
        descripcion: "Seguridad Social"
    }, {
        codigo: 4,
        descripcion: "Monotributo"
    }];

    const universoMuestra = {
        columns: [{
            text: "cuit",
            value: "cuit"
        },
            {
                text: "Nombre y apellido",
                value: "nombre_y_apellido"
            },
            {
                text: "inscripto ley99999",
                value: "inscripto_ley99999"
            },
            {
                text: "Ajuste estimado",
                value: "ajuste_estimado"
            },
            {
                text: "Deuda",
                value: "deuda"
            }
        ],
        rows: [{
            cuit: "20889789878",
            nombre_y_apellido: "Jhon Doe",
            deuda: "5489785",
            inscripto_ley99999: "S",
            ajuste_estimado: "8465789"
        },
            {
                cuit: "27987456311",
                nombre_y_apellido: "Jessica Jones",
                deuda: "5489785",
                inscripto_ley99999: "S",
                ajuste_estimado: "8465789"
            },
            {
                cuit: "20665987442",
                nombre_y_apellido: "Steve Rogers",
                deuda: "5489785",
                inscripto_ley99999: "S",
                ajuste_estimado: "8465789"
            },
            {
                cuit: "20999999990",
                nombre_y_apellido: "Clark Kent",
                deuda: "0",
                inscripto_ley99999: "N",
                ajuste_estimado: "0"
            },
            {
                deuda: "0",
                cuit: "20998744564",
                nombre_y_apellido: "Peter Parker",
                inscripto_ley99999: "S",
                ajuste_estimado: "123456"
            },
            {
                cuit: "20665489787",
                nombre_y_apellido: "Tony fuckin Stark",
                deuda: "5000000000",
                inscripto_ley99999: "N",
                ajuste_estimado: "1"
            }
        ]
    };
    const estadistica = {
        cantidadDeContribuyentes: 15478954,
        ajusteEstimado: "8468879",
        min: "8468879",
        max: "8468879",
        avg: "8468879",
        variance: "8468879"
    };

    const formulario = [{
        codigo: 1,
        descripcion: "F713"
    }, {
        codigo: 2,
        descripcion: "F749 v2"
    }, {
        codigo: 3,
        descripcion: "F311 v8"
    }, {
        codigo: 4,
        descripcion: "F578 v33"
    }]

    const origenes = [{
        codigo: 1,
        descripcion: "superOrigen"
    }, {
        codigo: 2,
        descripcion: "MegaOrigen"
    }, {
        codigo: 3,
        descripcion: "OtroOrigen"
    }, {
        codigo: 4,
        descripcion: "GranOrigen"
    }]

    const origenes2 = [{
        codigo: 1,
        descripcion: "superOrigen"
    },  {
        codigo: 3,
        descripcion: "OtroOrigen"
    }]

    const tiposRelevancia = [{
        codigo: 1,
        descripcion: "baja"
    }, {
        codigo: 2,
        descripcion: "media"
    }, {
        codigo: 3,
        descripcion: "alta"
    }, {
        codigo: 4,
        descripcion: "critica"
    }]

    const tiposPonderacion = [{
        codigo: 1,
        descripcion: "baja"
    }, {
        codigo: 2,
        descripcion: "media"
    }, {
        codigo: 3,
        descripcion: "alta"
    }, {
        codigo: 4,
        descripcion: "critica"
    }]

    const tiposDesvios = [
        {codigo:"1",descripcion:"FALTA DE DJ"},
        {codigo:"2",descripcion:"DESVIO DE DJ"},
        {codigo:"3",descripcion:"OTROS"
    }]

    const hipotesisPropias = [
        {
            idHipotesis: 187,
            nombreHipotesis: "Fallada Propia WWWXXXYYYZZZ",
            descripcionHipotesis: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed eiusmod tempor incidunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquid ex ea commodi consequat.",
            objetivoHipotesis: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed eiusmod tempor incidunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquid ex ea commodi consequat.",
            dirGral: "DI COMO",
            tipoRelevancia: "Acreditaciones entre 1.000.000 y 2.000.000",
            areaDefinidoraSeleccionada: "DI INEF",
            formulaAjuste: "MONTO",
            tipoPonderacion: "Mediana relevancia",
            query: "SELECT CUIT, MONTO, PERIODO FROM FISCAR.ebafis WHERE PERIODO >= 200901 AND PERIODO <= 201901 LIMIT 50",
            estado: "AC",
            fechaEstado: null,
            usuarioAlt: 20323943770,
            exclusividadSeleccionada: "VERIFICA",
            fAlta: "2019-01-31",
            concepto: "CONTROL DE EGRESOS, GASTOS Y/O DEDUCCIONES QUE DISMINUYEN IMP.DETERMINADO Y/O A INGRESAR",
            origen: "Costos operativos superiores a ingresos - Dif. entre  suma compras+remuenraciones+contribuciones  y ventas declaradas (IVA y/o ganancias)",
            codigoDeInstructivoSeleccionado: "AAA-BBBB-1234",
            idImpuesto: 30,
            impuesto: "Der. Expo. Adicional 4 Coeficiente 2 decreto 793/18 y 865/18",
            hipotesisFormularios: ["COMPRA DE MATERIALES RECICLABLES (FISC)","COMPRA DE MATERIALES RECICLABLES (FISC)","COMPRA DE MATERIALES RECICLABLES (FISC)"],
            hipotesisCorridas: [
                {
                    idCorrida: 109,
                    fechaEjecucion: "2019-04-09",
                    dQuery: "SELECT CUIT, MONTO, PERIODO FROM FISCAR.ebafis WHERE PERIODO >= 200901 AND PERIODO <= 201901 LIMIT 50",
                    nCantReg: 10000,
                    idImpuesto: 30,
                    nPeriodoDesde: 200900,
                    nPeriodoHasta: 201012,
                    iAjustePotencial: 500000,
                    cUsuarioAlt: 20323943770,
                    estado: "ER"
                },
                {
                    idCorrida: 109,
                    fechaEjecucion: "2019-04-09",
                    dQuery: "SELECT CUIT, MONTO, PERIODO FROM FISCAR.ebafis WHERE PERIODO >= 200901 AND PERIODO <= 201901 LIMIT 50",
                    nCantReg: 11000,
                    idImpuesto: 30,
                    nPeriodoDesde: 201000,
                    nPeriodoHasta: 201112,
                    iAjustePotencial: 1000000,
                    cUsuarioAlt: 20323943770,
                    estado: "ER"
                },
                {
                    idCorrida: 109,
                    fechaEjecucion: "2019-04-09",
                    dQuery: "SELECT CUIT, MONTO, PERIODO FROM FISCAR.ebafis WHERE PERIODO >= 200901 AND PERIODO <= 201901 LIMIT 50",
                    nCantReg: 20000,
                    idImpuesto: 30,
                    nPeriodoDesde: 201200,
                    nPeriodoHasta: 201312,
                    iAjustePotencial: 750000,
                    cUsuarioAlt: 20323943770,
                    estado: "ER"
                },                {
                    idCorrida: 109,
                    fechaEjecucion: "2019-04-09",
                    dQuery: "SELECT CUIT, MONTO, PERIODO FROM FISCAR.ebafis WHERE PERIODO >= 200901 AND PERIODO <= 201901 LIMIT 50",
                    nCantReg: 15000,
                    idImpuesto: 30,
                    nPeriodoDesde: 201300,
                    nPeriodoHasta: 201412,
                    iAjustePotencial: 987000,
                    cUsuarioAlt: 20323943770,
                    estado: "ER"
                }
            ]
        },
        {
            idHipotesis: 188,
            nombreHipotesis: "Pendiente Propia",
            descripcionHipotesis: "Pendiente desc",
            objetivoHipotesis: "Estar pendiente",
            dirGral: "1",
            tipoRelevancia: "5",
            areaDefinidoraSeleccionada: "1",
            formulaAjuste: "MONTO",
            tipoPonderacion: "1",
            query: "SELECT CUIT, MONTO, PERIODO FROM FISCAR.ebafis WHERE PERIODO >= 200901 AND PERIODO <= 201901 LIMIT 50",
            estado: "AC",
            fechaEstado: null,
            usuarioAlt: 20323943770,
            exclusividadSeleccionada: "1",
            fAlta: "2019-01-31",
            concepto: 1,
            origen: 1,
            codigoDeInstructivoSeleccionado: "1",
            idImpuesto: 30,
            hipotesisFormularios: [],
            hipotesisCorridas: [
                {
                    idCorrida: 110,
                    fechaEjecucion: "2019-04-09",
                    dQuery: "SELECT CUIT, MONTO, PERIODO FROM FISCAR.ebafis WHERE PERIODO >= 200901 AND PERIODO <= 201901 LIMIT 50",
                    nCantReg: 231597,
                    idImpuesto: 30,
                    nPeriodoDesde: 200901,
                    nPeriodoHasta: 201901,
                    iAjustePotencial: 87572222651.28,
                    cUsuarioAlt: 20323943770,
                    estado: "PE"
                }
            ]
        },
        {
            idHipotesis: 189,
            nombreHipotesis: "Dividendos Cobrados Propia",
            descripcionHipotesis: "Dividendos Cobrados",
            objetivoHipotesis: "Obtener el .... blah blah",
            dirGral: "1",
            tipoRelevancia: "5",
            areaDefinidoraSeleccionada: "1",
            formulaAjuste: "MONTO",
            tipoPonderacion: "1",
            query: "SELECT CUIT, MONTO, PERIODO FROM FISCAR.ebafis WHERE PERIODO >= 200901 AND PERIODO <= 201901 LIMIT 50",
            estado: "AC",
            fechaEstado: null,
            usuarioAlt: 20323943770,
            exclusividadSeleccionada: "1",
            fAlta: "2019-01-31",
            concepto: 1,
            origen: 1,
            codigoDeInstructivoSeleccionado: "1",
            idImpuesto: 30,
            hipotesisFormularios: [],
            hipotesisCorridas: [
                {
                    idCorrida: 111,
                    fechaEjecucion: "2019-04-09",
                    dQuery: "SELECT CUIT, MONTO, PERIODO FROM FISCAR.ebafis WHERE PERIODO >= 200901 AND PERIODO <= 201901 LIMIT 50",
                    nCantReg: 231597,
                    idImpuesto: 30,
                    nPeriodoDesde: 200901,
                    nPeriodoHasta: 201901,
                    iAjustePotencial: 87572222651.28,
                    cUsuarioAlt: 20323943770,
                    estado: "PR"
                }
            ]
        }];

    const hipotesis = [
        {
            idHipotesis: 187,
            nombreHipotesis: "Fallada",
            descripcionHipotesis: "deberia fallar",
            objetivoHipotesis: "fallar",
            dirGral: "1",
            tipoRelevancia: "5",
            areaDefinidoraSeleccionada: "1",
            formulaAjuste: "MONTO",
            tipoPonderacion: "1",
            query: "SELECT CUIT, MONTO, PERIODO FROM FISCAR.ebafis WHERE PERIODO >= 200901 AND PERIODO <= 201901 LIMIT 50",
            estado: "AC",
            fechaEstado: null,
            usuarioAlt: 20323943770,
            exclusividadSeleccionada: "1",
            fAlta: "2019-01-31",
            concepto: 1,
            origen: 1,
            codigoDeInstructivoSeleccionado: "1",
            idImpuesto: 30,
            hipotesisFormularios: ["1","73","234"],
            hipotesisCorridas: [
                {
                    idCorrida: 109,
                    fechaEjecucion: "2019-01-31",
                    dQuery: "SELECT CUIT, MONTO, PERIODO FROM FISCAR.ebafis WHERE PERIODO >= 200901 AND PERIODO <= 201901 LIMIT 50",
                    nCantReg: 231597,
                    idImpuesto: 30,
                    nPeriodoDesde: 200901,
                    nPeriodoHasta: 201901,
                    iAjustePotencial: 87572222651.28,
                    cUsuarioAlt: 20323943770,
                    estado: "ER"
                }
            ]
        },
        {
            idHipotesis: 188,
            nombreHipotesis: "Pendiente",
            descripcionHipotesis: "Pendiente desc",
            objetivoHipotesis: "Estar pendiente",
            dirGral: "1",
            tipoRelevancia: "5",
            areaDefinidoraSeleccionada: "1",
            formulaAjuste: "MONTO",
            tipoPonderacion: "1",
            query: "SELECT CUIT, MONTO, PERIODO FROM FISCAR.ebafis WHERE PERIODO >= 200901 AND PERIODO <= 201901 LIMIT 50",
            estado: "AC",
            fechaEstado: null,
            usuarioAlt: 20323943770,
            exclusividadSeleccionada: "1",
            fAlta: "2019-01-31",
            concepto: 1,
            origen: 1,
            codigoDeInstructivoSeleccionado: "1",
            idImpuesto: 30,
            hipotesisFormularios: [],
            hipotesisCorridas: [
                {
                    idCorrida: 110,
                    fechaEjecucion: "2019-01-31",
                    dQuery: "SELECT CUIT, MONTO, PERIODO FROM FISCAR.ebafis WHERE PERIODO >= 200901 AND PERIODO <= 201901 LIMIT 50",
                    nCantReg: 231597,
                    idImpuesto: 30,
                    nPeriodoDesde: 200901,
                    nPeriodoHasta: 201901,
                    iAjustePotencial: 87572222651.28,
                    cUsuarioAlt: 20323943770,
                    estado: "PE"
                }
            ]
        },
        {
            idHipotesis: 189,
            nombreHipotesis: "Dividendos Cobrados",
            descripcionHipotesis: "Dividendos Cobrados",
            objetivoHipotesis: "Obtener el .... blah blah",
            dirGral: "1",
            tipoRelevancia: "5",
            areaDefinidoraSeleccionada: "1",
            formulaAjuste: "MONTO",
            tipoPonderacion: "1",
            query: "SELECT CUIT, MONTO, PERIODO FROM FISCAR.ebafis WHERE PERIODO >= 200901 AND PERIODO <= 201901 LIMIT 50",
            estado: "AC",
            fechaEstado: null,
            usuarioAlt: 20323943770,
            exclusividadSeleccionada: "1",
            fAlta: "2019-01-31",
            concepto: 1,
            origen: 1,
            codigoDeInstructivoSeleccionado: "1",
            idImpuesto: 30,
            hipotesisFormularios: [],
            hipotesisCorridas: [
                {
                    idCorrida: 111,
                    fechaEjecucion: "2019-01-31",
                    dQuery: "SELECT CUIT, MONTO, PERIODO FROM FISCAR.ebafis WHERE PERIODO >= 200901 AND PERIODO <= 201901 LIMIT 50",
                    nCantReg: 231597,
                    idImpuesto: 30,
                    nPeriodoDesde: 200901,
                    nPeriodoHasta: 201901,
                    iAjustePotencial: 87572222651.28,
                    cUsuarioAlt: 20323943770,
                    estado: "PR"
                }
            ]
        }];

    const idsSistemasEventanilla = [
        {
            codigo: 108,
            descripcion: "Domicilio Fiscal Electrónico"
        }, {
            codigo: 109,
            descripcion: "Libro de Sueldos Digital"
        }, {
            codigo: 110,
            descripcion: "Sistema Registral"
        }, {
            codigo: 111,
            descripcion: "Comunicaciones"
        }
    ];

    const listDfe = [
        {
            campania: "Campania-1",
            asunto: "Descripcion de tema de e-ventanilla",
            fechaEnvio: new Date(),
            nombreArchivoAdjunto: "NOMBRE_ARCHIVO_001.pdf",
            usuarioPub: "Cosme Fulanito Iñigo Montoya",
            cargoUsuarioPub: "Vengador de muertes de padres",
            areaUsuarioPub: "Asociacion Federal Cooperativa Club Social",
            carta : {
                encabezado: "El encabezado de la carta que va a ser relativamente corto",
                primerParrafo: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.",
                segundoParrafo: "On the other hand, we denounce with righteous indignation and dislike men who are so beguiled and demoralized by the charms of pleasure of the moment, so blinded by desire, that they cannot foresee the pain and trouble that are bound to ensue; and equal blame belongs to those who fail in their duty through weakness of will, which is the same as saying through shrinking from toil and pain. These cases are perfectly simple and easy to distinguish. In a free hour, when our power of choice is untrammelled and when nothing prevents our being able to do what we like best, every pleasure is to be welcomed and every pain avoided. But in certain circumstances and owing to the claims of duty or the obligations of business it will frequently occur that pleasures have to be repudiated and annoyances accepted. The wise man therefore always holds in these matters to this principle of selection: he rejects pleasures to secure other greater pleasures, or else he endures pains to avoid worse pains.",
            },
            estadisticas : {
                cantidadTotal: 50323,
                countLeidos: 7345,
                countNoLeidos: 42978
            },
            estadisticasByFecha: {
                1546225200000: { //2019-00-00
                    cantidadPresentados: 0,
                    cantidadTotal: 100,
                    codigoCampani: null,
                    countLeidos: 0,
                    countNoLeidos: 100,
                    countPendientes: 0
                },
                1549767600000: {  //2019-01-10
                    cantidadPresentados: 3,
                    cantidadTotal: 100,
                    codigoCampani: null,
                    countLeidos: 10,
                    countNoLeidos: 100,
                    countPendientes: 0
                },
                1552186800000: {  //2019-02-10
                    cantidadPresentados: 13,
                    cantidadTotal: 100,
                    codigoCampani: null,
                    countLeidos: 21,
                    countNoLeidos: 79,
                    countPendientes: 0
                },
                1572547923633: {  //2019-02-10
                    cantidadPresentados: 25,
                    cantidadTotal: 100,
                    codigoCampani: null,
                    countLeidos: 21,
                    countNoLeidos: 79,
                    countPendientes: 0
                }
            }
        },
        {
            campania: "Campania-2",
            asunto: "Reconquista de Westeros",
            fechaEnvio: new Date(),
            nombreArchivoAdjunto: "NOMBRE_ARCHIVO_001.pdf",           
            usuarioPub: "Danaerys Targaryen",
            cargoUsuarioPub: "Madre de dragones, Rompedora de cadenas, Reina de los 7 reinos de Westeros",
            areaUsuarioPub: "Casa Targaryen",
            carta : {
                encabezado: "El encabezado de la carta que va a ser relativamente corto",
                primerParrafo: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.",
                segundoParrafo: "On the other hand, we denounce with righteous indignation and dislike men who are so beguiled and demoralized by the charms of pleasure of the moment, so blinded by desire, that they cannot foresee the pain and trouble that are bound to ensue; and equal blame belongs to those who fail in their duty through weakness of will, which is the same as saying through shrinking from toil and pain. These cases are perfectly simple and easy to distinguish. In a free hour, when our power of choice is untrammelled and when nothing prevents our being able to do what we like best, every pleasure is to be welcomed and every pain avoided. But in certain circumstances and owing to the claims of duty or the obligations of business it will frequently occur that pleasures have to be repudiated and annoyances accepted. The wise man therefore always holds in these matters to this principle of selection: he rejects pleasures to secure other greater pleasures, or else he endures pains to avoid worse pains.",
            },
            estadisticas : {
                cantidadTotal: 651987,
                countLeidos: 505489,
                countNoLeidos: 87572
            },
            estadisticasByFecha: {
                1546225200000: { //2019-00-00
                    cantidadPresentados: 0,
                    cantidadTotal: 100,
                    codigoCampani: null,
                    countLeidos: 0,
                    countNoLeidos: 100,
                    countPendientes: 0
                },
                1549767600000: {  //2019-01-10
                    cantidadPresentados: 3,
                    cantidadTotal: 100,
                    codigoCampani: null,
                    countLeidos: 10,
                    countNoLeidos: 100,
                    countPendientes: 0
                },
                1552186800000: {  //2019-02-10
                    cantidadPresentados: 13,
                    cantidadTotal: 100,
                    codigoCampani: null,
                    countLeidos: 21,
                    countNoLeidos: 79,
                    countPendientes: 0
                },
                1572547923633: {  //2019-02-10
                    cantidadPresentados: 25,
                    cantidadTotal: 100,
                    codigoCampani: null,
                    countLeidos: 21,
                    countNoLeidos: 79,
                    countPendientes: 0
                }
            }
        },
        {
            campania: "Campania-1",
            asunto: "Descripcion de tema de e-ventanilla",
            fechaEnvio: new Date(),
            nombreArchivoAdjunto: "NOMBRE_ARCHIVO_001.pdf",
            usuarioPub: "Cosme Fulanito Iñigo Montoya",
            cargoUsuarioPub: "Vengador de muertes de padres",
            areaUsuarioPub: "Asociacion Federal Cooperativa Club Social",
            carta : {
                encabezado: "El encabezado de la carta que va a ser relativamente corto",
                primerParrafo: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.",
                segundoParrafo: "On the other hand, we denounce with righteous indignation and dislike men who are so beguiled and demoralized by the charms of pleasure of the moment, so blinded by desire, that they cannot foresee the pain and trouble that are bound to ensue; and equal blame belongs to those who fail in their duty through weakness of will, which is the same as saying through shrinking from toil and pain. These cases are perfectly simple and easy to distinguish. In a free hour, when our power of choice is untrammelled and when nothing prevents our being able to do what we like best, every pleasure is to be welcomed and every pain avoided. But in certain circumstances and owing to the claims of duty or the obligations of business it will frequently occur that pleasures have to be repudiated and annoyances accepted. The wise man therefore always holds in these matters to this principle of selection: he rejects pleasures to secure other greater pleasures, or else he endures pains to avoid worse pains.",
            },
            estadisticas : {
                cantidadTotal: 50323,
                countLeidos: 7345,
                countNoLeidos: 42978
            },
            estadisticasByFecha: {
                1546225200000: { //2019-00-00
                    cantidadPresentados: 0,
                    cantidadTotal: 100,
                    codigoCampani: null,
                    countLeidos: 0,
                    countNoLeidos: 100,
                    countPendientes: 0
                },
                1549767600000: {  //2019-01-10
                    cantidadPresentados: 3,
                    cantidadTotal: 100,
                    codigoCampani: null,
                    countLeidos: 10,
                    countNoLeidos: 100,
                    countPendientes: 0
                },
                1552186800000: {  //2019-02-10
                    cantidadPresentados: 13,
                    cantidadTotal: 100,
                    codigoCampani: null,
                    countLeidos: 21,
                    countNoLeidos: 79,
                    countPendientes: 0
                },
                1572547923633: {  //2019-02-10
                    cantidadPresentados: 25,
                    cantidadTotal: 100,
                    codigoCampani: null,
                    countLeidos: 21,
                    countNoLeidos: 79,
                    countPendientes: 0
                }
            }
        },
        {
            campania: "Campania-1",
            asunto: "Descripcion de tema de e-ventanilla",
            fechaEnvio: new Date(),
            nombreArchivoAdjunto: "NOMBRE_ARCHIVO_001.pdf",
            usuarioPub: "Cosme Fulanito Iñigo Montoya",
            cargoUsuarioPub: "Vengador de muertes de padres",
            areaUsuarioPub: "Asociacion Federal Cooperativa Club Social",
            carta : {
                encabezado: "El encabezado de la carta que va a ser relativamente corto",
                primerParrafo: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.",
                segundoParrafo: "On the other hand, we denounce with righteous indignation and dislike men who are so beguiled and demoralized by the charms of pleasure of the moment, so blinded by desire, that they cannot foresee the pain and trouble that are bound to ensue; and equal blame belongs to those who fail in their duty through weakness of will, which is the same as saying through shrinking from toil and pain. These cases are perfectly simple and easy to distinguish. In a free hour, when our power of choice is untrammelled and when nothing prevents our being able to do what we like best, every pleasure is to be welcomed and every pain avoided. But in certain circumstances and owing to the claims of duty or the obligations of business it will frequently occur that pleasures have to be repudiated and annoyances accepted. The wise man therefore always holds in these matters to this principle of selection: he rejects pleasures to secure other greater pleasures, or else he endures pains to avoid worse pains.",
            },
            estadisticas : {
                cantidadTotal: 50323,
                countLeidos: 7345,
                countNoLeidos: 42978
            },
            estadisticasByFecha: {
                1546225200000 : { //2019-00-00
                    cantidadPresentados: 0,
                    cantidadTotal: 100,
                    codigoCampani: null,
                    countLeidos: 0,
                    countNoLeidos: 100,
                    countPendientes: 0
                },
                1549767600000: {  //2019-01-10
                    cantidadPresentados: 3,
                    cantidadTotal: 100,
                    codigoCampani: null,
                    countLeidos: 10,
                    countNoLeidos: 100,
                    countPendientes: 0
                },
                1552186800000: {  //2019-02-10
                    cantidadPresentados: 13,
                    cantidadTotal: 100,
                    codigoCampani: null,
                    countLeidos: 21,
                    countNoLeidos: 79,
                    countPendientes: 0
                },
                1572547923633: {  //2019-02-10
                    cantidadPresentados: 25,
                    cantidadTotal: 100,
                    codigoCampani: null,
                    countLeidos: 21,
                    countNoLeidos: 79,
                    countPendientes: 0
                }
            }
        },
        {
            campania: "Campania-1",
            asunto: "Descripcion de tema de e-ventanilla",
            fechaEnvio: new Date(),
            nombreArchivoAdjunto: "NOMBRE_ARCHIVO_001.pdf",
            usuarioPub: "Cosme Fulanito Iñigo Montoya",
            cargoUsuarioPub: "Vengador de muertes de padres",
            areaUsuarioPub: "Asociacion Federal Cooperativa Club Social",
            carta : {
                encabezado: "El encabezado de la carta que va a ser relativamente corto",
                primerParrafo: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.",
                segundoParrafo: "On the other hand, we denounce with righteous indignation and dislike men who are so beguiled and demoralized by the charms of pleasure of the moment, so blinded by desire, that they cannot foresee the pain and trouble that are bound to ensue; and equal blame belongs to those who fail in their duty through weakness of will, which is the same as saying through shrinking from toil and pain. These cases are perfectly simple and easy to distinguish. In a free hour, when our power of choice is untrammelled and when nothing prevents our being able to do what we like best, every pleasure is to be welcomed and every pain avoided. But in certain circumstances and owing to the claims of duty or the obligations of business it will frequently occur that pleasures have to be repudiated and annoyances accepted. The wise man therefore always holds in these matters to this principle of selection: he rejects pleasures to secure other greater pleasures, or else he endures pains to avoid worse pains.",
            },
            estadisticas : {
                cantidadTotal: 100,
                countLeidos: 0,
                countNoLeidos: 0
            },
            estadisticasByFecha: {
                1546225200000: { //2019-00-00
                    cantidadPresentados: 0,
                    cantidadTotal: 100,
                    codigoCampani: null,
                    countLeidos: 0,
                    countNoLeidos: 100,
                    countPendientes: 0
                },
                1549767600000: {  //2019-01-10
                    cantidadPresentados: 3,
                    cantidadTotal: 100,
                    codigoCampani: null,
                    countLeidos: 10,
                    countNoLeidos: 100,
                    countPendientes: 0
                },
                1552186800000: {  //2019-02-10
                    cantidadPresentados: 13,
                    cantidadTotal: 100,
                    codigoCampani: null,
                    countLeidos: 21,
                    countNoLeidos: 79,
                    countPendientes: 0
                },
                1572547923633: {  //2019-02-10
                    cantidadPresentados: 25,
                    cantidadTotal: 100,
                    codigoCampani: null,
                    countLeidos: 21,
                    countNoLeidos: 79,
                    countPendientes: 0
                }
            }
        }
    ];
     

    let mock = new MockAdapter(AXIOS, {delayResponse: 500});  


    mock.onGet('/version').reply(200, "1.1.40");
    mock.onGet('/cubo').reply(200, cubo);
    mock.onGet('/cubo/ft_contribuyentes/dimension').reply(200, dimension);
    mock.onGet('/cubo/declas_factu/dimension').reply(200, dimension);
    mock.onGet('/instructivo').reply(200, instructivo);
    mock.onGet('/exclusividad').reply(200, exclusividad);
    mock.onGet('/area-definidora').reply(200, areaDefinidora);
    mock.onGet('/impuesto').reply(200, impuesto);
    mock.onGet('/impuesto/sefi').reply(200, impuesto);
    mock.onGet('/impuesto/1/formulario').reply(200, formulario);
    mock.onGet('/impuesto/2/formulario').reply(200, formulario);
    mock.onGet('/impuesto/3/formulario').reply(200, formulario);
    mock.onGet('/impuesto/4/formulario').reply(200, formulario);
    mock.onGet('/impuesto/formulario').reply(200, formulario);
    mock.onGet('/concepto').reply(200, concepto);
    mock.onGet('/concepto/1/origen').reply(200, origenes);
    mock.onGet('/concepto/2/origen').reply(200, origenes2);
    mock.onGet('/concepto/3/origen').reply(200, origenes);
    mock.onGet('/concepto/4/origen').reply(200, origenes2);
    mock.onGet('/tipo-hipotesis').reply(200, tipoHipotesis);
    mock.onPost('/universo/muestra').reply(200, universoMuestra);
    mock.onPost('/universo/estadistica').reply(200, estadistica);
    mock.onGet('/tipo-relevancia').reply(200, tiposRelevancia);
    mock.onGet('/tipo-ponderacion').reply(200, tiposPonderacion);
    mock.onGet('/tipo-desvio').reply(200, tiposDesvios);
    mock.onGet('/sistema-eventanilla').reply(200, idsSistemasEventanilla);
    mock.onPost('/hipotesis').reply(200);
    mock.onPost('/enviarDFE').reply(200);
    mock.onGet('/hipotesis').reply(200, hipotesis);
    mock.onGet('/campaniasDFE').reply(200, listDfe);


    mock.onGet('/hipotesis/propias').reply(200, hipotesisPropias);
    mock.onPost('/hipotesis/correr').reply(200);
    //mock.onPost('/hipotesis/187/correr?tipoPeriodo=M&periodoDesde=201901&periodoHasta=201904').reply(200);
    //mock.onPost('/hipotesis/188/correr?tipoPeriodo=M&periodoDesde=201901&periodoHasta=201904').reply(200);
    //mock.onPost('/hipotesis/189/correr?tipoPeriodo=M&periodoDesde=201901&periodoHasta=201904').reply(200);
}





