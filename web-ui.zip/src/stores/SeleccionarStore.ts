import {AXIOS, cancelToken, source, getSource} from './axiosEnv/axiosConfig';
var pjson = require('../../package.json');
const v_url = process.env.VUE_APP_API_URL;
let token;

const SeleccionarStore = {
    namespaced: true,
    state: {
        //Selección
        showSeleccionarSpinner: false,
        //versionApi
        versionUI: pjson.version,
        versionMddw: '',
        versionApi: '',
        //Seleccionables
        cubos: [
            {
                "nombre": "Origen de datos",
                "children": null
            }
        ],


        dimensiones: [
            {
                "nombre": "Dimensiones",
                "children": null
            }
        ],

        operations: ["avg", "sum", "count", "max", "min", "countDistinct"],

        //Seleccion
        tipoPeriodoSeleccionado: 'C', //'F' para anual, 'C' para mensual
        periodoDesdeSeleccionado: '',
        periodoHastaSeleccionado: '',
        cuboSeleccionado: null,
        dimensionesSeleccionadas: [],
        filtrosSeleccionados: [],

        //Hipotesis
        //Seleccionables
        codigosDeInstructivo: null,
        tiposDirGral: null, //DGI, DGA, SS, MONO
        tiposRelevancia: null,
        tiposPonderacion: null,
        tiposDesvios: null,
        impuestos: null,
        formularios: null,
        exclusividades: null,
        origenes: null,
        conceptos: null,
        areasDefinidoras: null,

        //Seleccion
        codigoDeInstructivoSeleccionado: '',
        tiposRelevanciaSeleccionado: null,
        tiposSeleccionado: '',
        tipoPonderacionSeleccionado: null,
        tipoDesvioSeleccionado: null,
        dirGralSeleccionado: '',
        impuestoSeleccionado: null,
        formulariosSeleccionados: [],
        exclusividadSeleccionada: '', //Puede ser VERI, SEFI, SSOC, MONO o vacio si no es exclusiva de nadie.
        origenSeleccionado: '',
        conceptoSeleccionado: null,
        areaDefinidoraSeleccionada: '',
        nombreHipotesis: '',
        descripcionHipotesis: '',
        objetivoHipotesis: '',
        mensajeHipotesis: '',
        codigoHipotesis: '',

        //Estadisticas
        cantidadDeContribuyentes: null,
        ajusteEstimado: '',
        minimoEstimado: '',
        maximoEstimado: '',
        promedioEstimado: '',
        varianceEstimado: '',

        //Enviar a DFE
        openEnviarDFE: false,

        nombreUsuarioState: null,
        cargoUsuarioState: null,
        areaUsuarioState: null,
        codigoDeCampaniaSeleccionado: null,
        idSistemaEVentanillaSeleccionado: null,
        encabezadoCartaState: null,
        primerParrafoState: null,
        segundoParrafoState: null,
        pdfNombreState: null,
        sistemasEventanilla: null,
        listadoCampanias: [],

        // Carta
        cartaEncabezado: null,
        cartaPrimerParrafo: null,
        cartaSegundoParrafo: null,
        firmante: null,
        cargo: null,
        area: null,        
        showCarta: false,

        //Caratula
        openCaratula: false,
        openPeriodo: false,
        caratulaValida: false,

        //Listado de hipotesis
        showHipotesisSpinner: false,
        showBtnCancelRQ: false,

        hipotesis: null,
        misHipotesis: null,
        otherHipotesis: [],
        hipotesisSeleccionada: null,
        showDetailHip: false,

        //Notificacion
        titulo: null,
        color: null,
        mensaje: null,
        goToHome: false,
        goToCampana: false,
        saveCampania: false,

        universo: null,
        fullPath: '',
        changeTab: false


    },
    actions: {
        getVersionMddw(context) {
            return new Promise((resolve, reject) => {
                (function (context, reject) {
                    AXIOS.get(process.env.VUE_APP_API_URL + '/versionMiddleware')
                        .then(x => x.data)
                        .then(version => {
                            context.commit('SET_VERSION_MIDDLEWARE', version);
                            resolve(version);
                        })
                        .catch(
                            (e) => {
                                context.commit('SET_VERSION_MIDDLEWARE', '1.7.0');
                                //reject(e.data);
                            });
                })(context, reject);
            })
        },

        getVersionApi(context) {
            return new Promise((resolve, reject) => {
                (function (context, reject) {
                    AXIOS.get(process.env.VUE_APP_API_URL + '/version')
                        .then(x => x.data)
                        .then(version => {
                            context.commit('SET_VERSION_API', version);
                            resolve(version);
                        })
                        .catch(
                            (e) => {
                                context.commit('SET_VERSION_API', '1.7.0');
                                //reject(e.data);
                            });
                })(context, reject);
            })
        },


        getCubos(context) {
            context.commit('CLEAN_CUBOS');

            return new Promise((resolve, reject) => {
                (function (context, reject) {
                    AXIOS.get(process.env.VUE_APP_API_URL + '/cubo')
                        .then(x => x.data)
                        .then(cubos => {
                            context.commit('SET_CUBOS', cubos);
                            resolve(cubos);
                        });
                })(context, reject);
            })
        },
        getDimensiones(context, value) {
            context.commit('SET_CUBO_SELECCIONADO', value);
            context.commit('SET_DIMENSIONES', value);
            context.commit('CLEAN_DIMENSIONES');

            return new Promise((resolve, reject) => {
                (function (context, reject) {
                    AXIOS.get(process.env.VUE_APP_API_URL + '/cubo/' + value.id + '/dimension')
                        .then(x => x.data)
                        .then(dimensiones => {
                            context.commit('SET_DIMENSIONES', dimensiones);
                            resolve(dimensiones);
                        });
                })(context, reject);
            })
        },
        getCodigosDeInstructivo(context) {
            return new Promise((resolve, reject) => {
                (function (context, reject) {
                    AXIOS.get(process.env.VUE_APP_API_URL + '/instructivo')
                        .then(x => x.data)
                        .then(codigosDeInstructivo => {
                            context.commit('SET_CODIGOS_INSTRUCTIVO', codigosDeInstructivo);
                            resolve(codigosDeInstructivo);
                        });
                })(context, reject);
            })
        },
        getExclusividades(context) {
            return new Promise((resolve, reject) => {
                (function (context, reject) {
                    AXIOS.get(process.env.VUE_APP_API_URL + '/exclusividad')
                        .then(x => x.data)
                        .then(exclusividades => {
                            context.commit('SET_EXCLUSIVIDADES', exclusividades);
                            resolve(exclusividades);
                        });
                })(context, reject);
            })
        },
        getAreasDefinidoras(context) {
            return new Promise((resolve, reject) => {
                (function (context, reject) {
                    AXIOS.get(process.env.VUE_APP_API_URL + '/area-definidora')
                        .then(x => x.data)
                        .then(areasDefinidoras => {
                            context.commit('SET_AREAS_DEFINIDORAS', areasDefinidoras);
                            resolve(areasDefinidoras);
                        });
                })(context, reject);
            })
        },
        getImpuestos(context) {
            return new Promise((resolve, reject) => {
                (function (context, reject) {
                    AXIOS.get(process.env.VUE_APP_API_URL + '/impuesto')
                        .then(x => x.data)
                        .then(impuestos => {
                            context.commit('SET_IMPUESTOS', impuestos);
                            resolve(impuestos);
                        })
                })(context, reject);
            })
        },

        getImpuestosSefi(context) {
            return new Promise((resolve, reject) => {
                (function (context, reject) {
                    AXIOS.get(process.env.VUE_APP_API_URL + '/impuesto/sefi')
                        .then(x => x.data)
                        .then(impuestos => {
                            context.commit('SET_IMPUESTOS', impuestos);
                            resolve(impuestos);
                        })
                })(context, reject);
            })
        },
        
        getImpuestosSefiByDireccion(context, direccion) {
            return new Promise((resolve, reject) => {
                (function (context, reject) {
                    AXIOS.get(process.env.VUE_APP_API_URL + '/impuesto/sefi/'+direccion)
                        .then(x => x.data)
                        .then(impuestos => {
                            context.commit('SET_IMPUESTOS', impuestos);
                            resolve(impuestos);
                        })
                })(context, reject);
            })
        },
        
        getFormularios(context) {
            return new Promise((resolve, reject) => {
                (function (context, reject) {
                    context.commit('CLEAN_FORMULARIOS');
                    AXIOS.get(process.env.VUE_APP_API_URL + '/impuesto/formulario')
                        .then(x => x.data)
                        .then(formularios => {
                            context.commit('SET_FORMULARIOS', formularios);
                            resolve(formularios);
                        });
                })(context, reject);
            })
        },
        getConceptos(context) {
            return new Promise((resolve, reject) => {
                (function (context, reject) {
                    AXIOS.get(process.env.VUE_APP_API_URL + '/concepto')
                        .then(x => x.data)
                        .then(conceptos => {
                            context.commit('SET_CONCEPTOS', conceptos);
                            resolve(conceptos);
                        });
                })(context, reject);
            })
        },

        getOrigenes(context, codigoConcepto) {
            if(codigoConcepto==undefined){
                context.commit('SET_ORIGENES', null);
                return;
            }                
            return new Promise((resolve, reject) => {
                (function (context, reject) {
                    AXIOS.get(process.env.VUE_APP_API_URL + '/concepto/' + codigoConcepto + '/origen')
                        .then(x => x.data)
                        .then(origenes => {
                            context.commit('SET_ORIGENES', origenes);
                            resolve(origenes);
                        });
                })(context, reject);
            })
        },

        getTipos(context) {
            return new Promise((resolve, reject) => {
                (function (context, reject) {
                    AXIOS.get(process.env.VUE_APP_API_URL + '/tipo-hipotesis')
                        .then(x => x.data)
                        .then(tipos => {
                            context.commit('SET_TIPOS_DIR_GRAL', tipos);
                            resolve(tipos);
                        });
                })(context, reject);
            })
        },

        getUniverso(context) {
            return new Promise((resolve, reject) => {
                (function (context, reject) {
                    token = getSource();
                    AXIOS.post(process.env.VUE_APP_API_URL + '/universo/muestra',
                        {
                            cubo: context.state.cuboSeleccionado.id,
                            tipoperiodo: context.state.tipoPeriodoSeleccionado,
                            periododesde: context.state.tipoPeriodoSeleccionado === 'F' ? context.state.periodoDesdeSeleccionado + '00' : context.state.periodoDesdeSeleccionado,
                            periodohasta: context.state.tipoPeriodoSeleccionado === 'F' ? context.state.periodoHastaSeleccionado + '00' : context.state.periodoHastaSeleccionado,
                            columnas: context.state.dimensionesSeleccionadas,
                            filtrosSeleccionados: context.state.filtrosSeleccionados
                        },
                        {
                            cancelToken: token.token
                        })
                        .then(x => x.data)
                        .then(universo => {
                            context.commit('SET_UNIVERSO', universo);
                            resolve(universo);
                        });
                })(context, reject);
            })
        },

        getEstadisticas(context) {
            return new Promise((resolve, reject) => {
                (function (context, reject) {
                    token = getSource();
                    context.commit('CLEAN_ESTADISTICAS');
                    AXIOS.post(process.env.VUE_APP_API_URL + '/universo/estadistica',
                        {
                            cubo: context.state.cuboSeleccionado.id,
                            tipoperiodo: context.state.tipoPeriodoSeleccionado,
                            periododesde: context.state.tipoPeriodoSeleccionado === 'F' ? context.state.periodoDesdeSeleccionado + '00' : context.state.periodoDesdeSeleccionado,
                            periodohasta: context.state.tipoPeriodoSeleccionado === 'F' ? context.state.periodoHastaSeleccionado + '00' : context.state.periodoHastaSeleccionado,
                            columnas: context.state.dimensionesSeleccionadas,
                            filtrosSeleccionados: context.state.filtrosSeleccionados
                        },
                        {
                            cancelToken: token.token
                        })
                        .then(x => x.data)
                        .then(estadisticas => {
                            let estadisticaObject = {
                                                    cantidadDeContribuyentes: estadisticas.cantidadDeContribuyentes, 
                                                    ajusteEstimado: estadisticas.ajusteEstimado,
                                                    maximoEstimado: estadisticas.max,
                                                    minimoEstimado: estadisticas.min,
                                                    promedioEstimado: estadisticas.avg,
                                                    varianceEstimado: estadisticas.variance
                                                    }
                            context.commit('SET_ESTADISTICAS', estadisticaObject);
                            //context.commit('SET_ESTADISTICAS', {cantidadDeContribuyentes: estadisticas.cantidadDeContribuyentes, ajusteEstimado: estadisticas.ajusteEstimado});
                            resolve(estadisticas);
                        });
                })(context, reject)
                        })
        },
        cancelOperation(context){
            token.cancel('Operación cancelada por el usuario.');
            context.commit('SET_BTN_CANCEL_RQ', false);
            context.commit('SET_SHOW_SELECCIONAR_SPINNER', false);
        },

        getTiposRelevancia(context) {
            return new Promise((resolve, reject) => {
                (function (context, reject) {
                    AXIOS.get(process.env.VUE_APP_API_URL + '/tipo-relevancia')
                        .then(x => x.data)
                        .then(tiposRelevancia => {
                            context.commit('SET_TIPOS_RELEVANCIA', tiposRelevancia);
                            resolve(tiposRelevancia);
                        });
                })(context, reject);
            })
        },

        getTiposPonderacion(context) {
            return new Promise((resolve, reject) => {
                (function (context, reject) {
                    AXIOS.get(process.env.VUE_APP_API_URL + '/tipo-ponderacion')
                        .then(x => x.data)
                        .then(tiposPonderacion => {
                            context.commit('SET_TIPOS_PONDERACION', tiposPonderacion);
                            resolve(tiposPonderacion);
                        });
                })(context, reject);
            })
        },

        getTiposDesvio(context) {
            return new Promise((resolve, reject) => {
                (function (context, reject) {
                    AXIOS.get(process.env.VUE_APP_API_URL + '/tipo-desvio')
                        .then(x => x.data)
                        .then(tiposDesvios => {
                            context.commit('SET_TIPOS_DESVIOS', tiposDesvios);
                            resolve(tiposDesvios);
                        });
                })(context, reject);
            })
        },

        saveHipotesis(context) {
            let periodoDesde = context.state.tipoPeriodoSeleccionado === 'F' ? context.state.periodoDesdeSeleccionado + '00' : context.state.periodoDesdeSeleccionado;
            let periodoHasta = context.state.tipoPeriodoSeleccionado === 'F' ? context.state.periodoHastaSeleccionado + '00' : context.state.periodoHastaSeleccionado;
            return new Promise((resolve, reject) => {
                (function (context, reject) {
                    AXIOS.post(process.env.VUE_APP_API_URL + '/hipotesis',
                        {
                            nombreHipotesis: context.state.nombreHipotesis,
                            objetivoHipotesis: context.state.objetivoHipotesis,
                            descripcionHipotesis: context.state.descripcionHipotesis,
                            dirGral: context.state.dirGralSeleccionado.codigo,
                            tipoRelevancia: context.state.tiposRelevanciaSeleccionado.codigo,
                            tipoPonderacion: {codigo: context.state.tipoPonderacionSeleccionado.codigo},                            
                            areaDefinidoraSeleccionada: context.state.areaDefinidoraSeleccionada.codigo,
                            perVtoSeleccionado: context.state.impuestoSeleccionado.perVto,
                            impuestoSeleccionado: context.state.impuestoSeleccionado.codigo,
                            formulariosSeleccionados: context.state.formulariosSeleccionados.map(formulario => formulario.codigo),
                            exclusividadSeleccionada: context.state.exclusividadSeleccionada.codigo,
                            concepto: context.state.conceptoSeleccionado.codigo,
                            origen: context.state.origenSeleccionado.idOrigen,
                            codigoDeInstructivoSeleccionado: context.state.codigoDeInstructivoSeleccionado,
                            codigoDeTipoDesvioSeleccionado: context.state.tipoDesvioSeleccionado.codigo,
                            seleccion: {
                                cubo: context.state.cuboSeleccionado.id,
                                tipoperiodo: context.state.tipoPeriodoSeleccionado,
                                periododesde: periodoDesde,
                                periodohasta: periodoHasta,
                                periodoCFdesde: context.state.tipoPeriodoSeleccionado === 'C' ? periodoDesde : periodoDesde.substring(0, 6),
                                periodoCFhasta: context.state.tipoPeriodoSeleccionado === 'C' ? periodoHasta : periodoHasta.substring(0, 6),
                                columnas: context.state.dimensionesSeleccionadas,
                                filtrosSeleccionados: context.state.filtrosSeleccionados
                            }
                        },
                        {
                            cancelToken: source.token
                        })
                        .then(x => {
                            resolve(x);
                        }).catch(
                        (e) => {
                            reject(e.data)
                        });
                })(context, reject);
            })
        },

        saveEnviarDFE(context) {
            return new Promise((resolve, reject) => {
                (function (context, reject) {
                    AXIOS.post(process.env.VUE_APP_API_URL + '/enviarDFE',
                        {
                            nombreUsuario: context.state.nombreUsuarioState,
                            areaUsuario: context.state.areaUsuarioState,
                            cargoUsuario: context.state.cargoUsuarioState,
                            codigoDeCampania: context.state.codigoDeCampaniaSeleccionado,
                            idSistemaEVentanilla: context.state.idSistemaEVentanillaSeleccionado.codigo,
                            encabezadoCarta: context.state.encabezadoCartaState,
                            primerParrafo: context.state.primerParrafoState,
                            segundoParrafo: context.state.segundoParrafoState,
                            pdfNombre: context.state.pdfNombreState,
                            tipoDesvio: context.state.tipoDesvioSeleccionado.codigo,
                            formularios: context.state.formulariosSeleccionados.map(formulario => formulario.codigo),
                            seleccion: {
                                cubo: context.state.cuboSeleccionado.id,
                                tipoperiodo: context.state.tipoPeriodoSeleccionado,
                                periododesde: context.state.tipoPeriodoSeleccionado === 'F' ? context.state.periodoDesdeSeleccionado + '00' : context.state.periodoDesdeSeleccionado,
                                periodohasta: context.state.tipoPeriodoSeleccionado === 'F' ? context.state.periodoHastaSeleccionado + '00' : context.state.periodoHastaSeleccionado,
                                columnas: context.state.dimensionesSeleccionadas,
                                filtrosSeleccionados: context.state.filtrosSeleccionados
                            }
                        })
                        .then(x => {
                            resolve(x);
                        }).catch(
                        (e) => {
                            reject(e.data)
                        });
                })(context, reject);
            })
        },

        saveHipotesisCorrida(context, idHipotesis) {
            return new Promise((resolve, reject) => {
                (function (context, reject) {
                    let perDesde = context.state.tipoPeriodoSeleccionado === 'F' ? context.state.periodoDesdeSeleccionado + '00' : context.state.periodoDesdeSeleccionado;
                    let perHasta = context.state.tipoPeriodoSeleccionado === 'F' ? context.state.periodoHastaSeleccionado + '00' : context.state.periodoHastaSeleccionado;

                    AXIOS.post(process.env.VUE_APP_API_URL + '/hipotesis/correr',
                        {idHipotesis: idHipotesis,
                        tipoPeriodo: context.state.tipoPeriodoSeleccionado,
                        perDesde: perDesde,
                        perHasta: perHasta        
                        }
                    )
                    .then(x => {
                            resolve(x);
                        }
                    );
                })(context, reject);
            })
        },

        setHipotesisSeleccionada({commit}, hipotesi) {
            commit('SET_HIPOTESIS_SELECCIONADA', hipotesi);
        },

        getAllHipotesis({commit, state}) {
            return new Promise((resolve, reject) => {
                (function (context, resolve, reject) {
                    AXIOS.get(process.env.VUE_APP_API_URL + '/hipotesis')
                        .then(x => x.data)
                        .then(hipotesis => {
                            commit('SET_HIPOTESIS', hipotesis);
                            if(state.hipotesisSeleccionada){
                                let idHipotesis = state.hipotesisSeleccionada.idHipotesis;
                                let hipSeleccionadaReloaded = hipotesis.filter(value => {
                                    let matchIdHipotesis = value.idHipotesis==idHipotesis;
                                    return matchIdHipotesis ;
                                });

                                commit('SET_HIPOTESIS_SELECCIONADA', hipSeleccionadaReloaded[0]);
                            }
                            resolve(hipotesis);
                        });
                })(state, resolve, reject);
            })
        },

        getAllCampaniasOfState(context) {
            return new Promise((resolve, reject) => {
                (function (context, reject) {
                    resolve(context.state.listadoCampanias);
                })(context, reject);
            });
        },

        getAllCampanias({commit, state}) {
            return new Promise((resolve, reject) => {
                (function (context, resolve, reject) {
                    AXIOS.get(process.env.VUE_APP_API_URL + '/campaniasDFE')
                        .then(x => x.data)
                        .then(data => {
                            commit('SET_MIS_CAMPANIAS', data);
                            resolve(data);
                        });
                })(state, resolve, reject);
            })
        },       

        getMisHipotesis({commit, state}) {
            return new Promise((resolve, reject) => {
                (function (context, resolve, reject) {
                    AXIOS.get(process.env.VUE_APP_API_URL + '/hipotesis/propias')
                        .then(x => x.data)
                        .then(hipotesis => {
                            commit('SET_MIS_HIPOTESIS', hipotesis);
                            resolve(hipotesis);
                        });
                })(state, resolve, reject);
            })
        },

        getSistemasEVentanilla({commit, state}) {
            return new Promise((resolve, reject) => {
                (function (context, resolve, reject) {
                    AXIOS.get(process.env.VUE_APP_API_URL + '/sistema-eventanilla')
                        .then(x => x.data)
                        .then(sistemasEVentanilla => {
                            commit('SET_SISTEMAS_EVENTANILLA', sistemasEVentanilla);
                            resolve(sistemasEVentanilla);
                        });
                })(state, resolve, reject);
            })
        },

        showError(context, error) {
            return new Promise((resolve, reject) => {
                (function (context, resolve, reject) {
                    context.commit('SET_NOTIFICACION', {titulo: error.codigo ? error.codigo : "Error general", color: "red", mensaje: error.descripcion ? error.descripcion : "Ha ocurrido un error", goToHome: false, goToCampana : false});
                    resolve();
                })(context, resolve, reject);
            })
        },

        showBtnCancel(context, value) {
            context.commit('SET_BTN_CANCEL_RQ', value);
        },

        showNotificacion(context, toPath) {
            context.commit('SET_NOTIFICACION', {titulo: "Advertencia", color: "yellow darken-4", mensaje: "¿Estas seguro que deseas cambiar de pestaña?", goToHome: false, goToCampana : false,path: toPath});
        },

        closeNotification(context) {
            context.commit('SET_SHOW_SELECCIONAR_SPINNER', false);
            context.commit('SET_SHOW_HIPOTESIS_SPINNER', false);
        },

        setState(context, value) {           
            
            if(value.changeState==1){
                context.commit('REMOVE_ALL_DIMENSIONES_SELECCIONADAS',context) ;
                if(value.dimensionesSeleccionadas){
                    for(let i=0; i<value.dimensionesSeleccionadas.length;i++){
                        let dimension = value.dimensionesSeleccionadas[i];
                        context.commit('ADD_DIMENSIONES_SELECCIONADAS',dimension) ;
                    }
                }                
            } else {
                context.commit('REMOVE_ALL_FILTROS_SELECCIONADOS',context) ;
                if(value.filtrosSeleccionados){
                    for(let i=0; i<value.filtrosSeleccionados.length;i++){
                        let filtro = value.filtrosSeleccionados[i];
                        context.commit('ADD_FILTROS_SELECCIONADOS',filtro) ;
                    }
                }    
            }
        },    

        checkDimensionsAndFilters(context) {
            return new Promise((resolve, reject) => {
                (function (context, resolve, reject) {
                    let valido = context.state.dimensionesSeleccionadas.length>0 || context.state.filtrosSeleccionados.length>0
                    resolve(valido);
                })(context, resolve, reject);
            });
        },

        isFullPath(context) {
            return new Promise((resolve, reject) => {
                (function (context, resolve, reject) {
                    let isValido = context.state.fullPath.length>0
                    let hasDimensAndFilters = context.state.dimensionesSeleccionadas.length>0 || context.state.filtrosSeleccionados.length>0
                    let obj  =  { isValido: isValido,
                                  hasDimensAndFilters: hasDimensAndFilters
                                }
                    resolve(obj);
                })(context, resolve, reject);
            });
        },

        clearFullPath(context) {
            return new Promise((resolve, reject) => {
                (function (context, resolve, reject) {
                    context.state.fullPath = '';
                    resolve(context.state.fullPath);
                })(context, resolve, reject);
            });
        },

        closeErrorNotification(context) {
            return new Promise((resolve, reject) => {
                (function (context, resolve, reject) {
                    context.commit('SET_NOTIFICACION', {titulo: null, color: null, mensaje: null, goToHome: false, goToCampana : false, path: ''});
                    resolve();
                })(context, resolve, reject);
            })
        },

        logout(context, error) {
            return new Promise((resolve, reject) => {
                (function (context, resolve, reject) {
                    AXIOS.get(process.env.VUE_APP_API_URL + '/logout')
                        .then(x => {
                            window.location.href = "https://authint.afip.gob.ar/persona/"
                        });
                })(context, resolve, reject);
            })
        },

    },

    mutations: {
        
        SET_FULL_PATH(state, value) {
            state.fullPath = value;
        },

        SET_VERSION_MIDDLEWARE(state, value) {
            state.versionMddw = value;
        },

        SET_VERSION_API(state, value) {
            state.versionApi = value;
        },

        SET_SHOW_SELECCIONAR_SPINNER(state, value) {
            state.showSeleccionarSpinner = value;
        },

        SET_SHOW_HIPOTESIS_SPINNER(state, value) {
            state.showHipotesisSpinner = value;
        },

        SET_CARATULA_VALIDA(state, value) {
            state.caratulaValida = value;
        },

        SET_BTN_CANCEL_RQ(state, value) {
            state.showBtnCancelRQ = value;
        },

        SET_VALUES_STATE(state, value) {
            state = value;
        },

        CLEAN_SELECCIONES(state) {
            state.dimensionesSeleccionadas = [];
            state.cuboSeleccionado = null;
            state.filtrosSeleccionados = [];
            state.cubos = [{nombre: "Origen de datos", children: null}];
            state.dimensiones = [{nombre: "Dimensiones", children: null}];
            state.ajusteEstimado = '';
            state.cantidadDeContribuyentes = null;
            state.minimoEstimado= '';
            state.maximoEstimado= '';
            state.promedioEstimado= '';
            state.varianceEstimado= '';
            state.periodoDesdeSeleccionado = '';
            state.periodoHastaSeleccionado = '';
            state.tipoPeriodoSeleccionado = 'C';
            state.dirGralSeleccionado = '';
            state.tipoPonderacionSeleccionado = null;
            state.tipoDesvioSeleccionado = null;
            state.tiposRelevanciaSeleccionado = '';
            state.codigoDeInstructivoSeleccionado = '';
            state.impuestoSeleccionado = null;
            state.formulariosSeleccionados = [];
            state.origenSeleccionado = '';
            state.conceptoSeleccionado = null;
            state.exclusividadSeleccionada = '';
            state.caratulaValida = false;
            state.universo = null;
            state.mensajeHipotesis = null;
            state.codigoHipotesis = null;
            state.saveCampania = false;
        },

        CLEAN_SELECCIONES_CARATULA(state) {
            state.dirGralSeleccionado = '';
            state.tipoPonderacionSeleccionado = null;
            state.tiposRelevanciaSeleccionado = '';
            state.tipoDesvioSeleccionado = null;
            state.codigoDeInstructivoSeleccionado = '';
            state.impuestoSeleccionado = null;
            state.formulariosSeleccionados = [];
            state.origenSeleccionado = '';
            state.conceptoSeleccionado = null;
            state.exclusividadSeleccionada = '';
            state.caratulaValida = false;
            state.mensajeHipotesis = null;
            state.codigoHipotesis = null;
            state.areaDefinidoraSeleccionada = '';
            state.nombreHipotesis = '';
            state.descripcionHipotesis = '';
            state.objetivoHipotesis = '';
        },

        CLEAN_SELECCIONES_PERIODO(state) {
            state.ajusteEstimado = '';
            state.cantidadDeContribuyentes = null;
            state.minimoEstimado= '';
            state.maximoEstimado= '';
            state.promedioEstimado= '';
            state.varianceEstimado= '';
            state.dirGralSeleccionado = '';
            state.tipoPonderacionSeleccionado = null;
            state.tipoDesvioSeleccionado = null;
            state.tiposRelevanciaSeleccionado = '';
            state.codigoDeInstructivoSeleccionado = '';
            state.impuestoSeleccionado = null;
            state.formulariosSeleccionados = [];
            state.origenSeleccionado = '';
            state.conceptoSeleccionado = null;
            state.exclusividadSeleccionada = '';
            state.caratulaValida = false;
            state.universo = null;
            state.mensajeHipotesis = null;
            state.codigoHipotesis = null;
        },

        CLEAN_PERIODO(state) {
            state.periodoDesdeSeleccionado = '';
            state.periodoHastaSeleccionado = '';
            state.tipoPeriodoSeleccionado = 'C';
        },

        CLEAN_CUBOS(state) {
            state.cubos[0].children = null;
        },

        SET_CUBOS(state, cubos) {
            state.cubos[0].children = null;
            state.cubos[0].children = cubos;
        },

        CLEAN_DIMENSIONES(state) {
            state.dimensiones[0].children = null;
            state.dimensionesSeleccionadas = [];
            state.filtrosSeleccionados = [];
        },

        SET_DIMENSIONES(state, value) {
            state.dimensiones[0].children = value;
        },

        SET_CODIGOS_INSTRUCTIVO(state, value) {
            state.codigosDeInstructivo = value;
        },

        SET_EXCLUSIVIDADES(state, value) {
            state.exclusividades = value;
        },

        SET_AREAS_DEFINIDORAS(state, value) {
            state.areasDefinidoras = value;
        },

        SET_IMPUESTOS(state, value) {
            state.impuestos = value;
        },

        CLEAN_FORMULARIOS(state) {
            state.formularios = null;
        },

        SET_FORMULARIOS(state, formularios) {
            state.formularios = formularios;
        },

        SET_CONCEPTOS(state, value) {
            state.conceptos = value;
        },

        SET_ORIGENES(state, value) {
            state.origenes = value;
        },

        SET_TIPOS_DIR_GRAL(state, value) {
            state.tiposDirGral = value;
        },

        SET_UNIVERSO(state, value) {
            state.universo = value;
        },

        CLEAN_ESTADISTICAS(state) {
            state.cantidadDeContribuyentes = null;
            state.ajusteEstimado = null;
            state.minimoEstimado= null;
            state.maximoEstimado= null;
            state.promedioEstimado= null;
            state.varianceEstimado= null;
        },

        SET_ESTADISTICAS(state, value) {
            state.cantidadDeContribuyentes = value.cantidadDeContribuyentes;
            state.ajusteEstimado = value.ajusteEstimado;
            state.minimoEstimado = value.minimoEstimado;
            state.maximoEstimado = value.maximoEstimado;
            state.promedioEstimado = value.promedioEstimado;
            state.varianceEstimado = value.varianceEstimado;
        },

        SET_TIPOS_RELEVANCIA(state, value) {
            state.tiposRelevancia = value;
        },

        SET_TIPOS_PONDERACION(state, value) {
            state.tiposPonderacion = value;
        },

        SET_TIPOS_DESVIOS(state, value) {
            state.tiposDesvios = value;
        },

        SET_NOTIFICACION(state, value) {
            state.titulo = value.titulo;
            state.mensaje = value.mensaje;
            state.color = value.color;
            state.goToHome = value.goToHome;
            state.goToCampana = value.goToCampana;
            if(value.path)
                state.fullPath = value.path;   
                
        },

        CLEAR_NOTIFICACION(state, value) {
            state.titulo = null;
            state.mensaje = null;
            state.color = null;
            state.fullPath = '';
        },

        SHOW_PERIODO(state, value) {
            state.openPeriodo = value;
        },

        SHOW_CARATULA(state, value) {
            state.openCaratula = value;
        },

        SET_CODIGO_INSTRUCTIVO(state, value) {
            state.codigoDeInstructivoSeleccionado = value;
        },

        SET_IMPUESTO(state, value) {
            state.impuestoSeleccionado = value;
        },

        SET_FORMULARIOS_SELECCIONADOS(state, value) {
            state.formulariosSeleccionados = value;
        },

        SET_ORIGEN(state, value) {
            state.origenSeleccionado = value;
        },

        SET_CONCEPTO(state, value) {
            state.conceptoSeleccionado = value;
        },

        SET_DIR_GRAL(state, value) {
            state.dirGralSeleccionado = value;
        },

        SET_TIPO_PERIODO(state, value) {
            state.tipoPeriodoSeleccionado = value;
        },

        SET_PERIODO_DESDE(state, value) {
            state.periodoDesdeSeleccionado = value;
        },

        SET_PERIODO_HASTA(state, value) {
            state.periodoHastaSeleccionado = value;
        },

        SET_EXCLUSIVIDAD(state, value) {
            state.exclusividadSeleccionada = value;
        },

        SET_AREA_DEFINIDORA(state, value) {
            state.areaDefinidoraSeleccionada = value;
        },

        SET_TITULO(state, value) {
            state.titulo = value;
        },

        ADD_DIMENSIONES_SELECCIONADAS(state, value) {
            let objCopy = Object.assign({}, value);
            state.dimensionesSeleccionadas.push(objCopy);
        },

        REMOVE_DIMENSIONES_SELECCIONADAS(state, index) {
            state.dimensionesSeleccionadas.splice(index, 1);
        },

        REMOVE_ALL_DIMENSIONES_SELECCIONADAS(state) {
            state.dimensionesSeleccionadas.splice(0, state.dimensionesSeleccionadas.length);
        },

        ADD_FILTROS_SELECCIONADOS(state, value) {
            state.filtrosSeleccionados.push(value);
        },

        REMOVE_FILTROS_SELECCIONADOS(state, index) {
            state.filtrosSeleccionados.splice(index, 1);
        },

        REMOVE_ALL_FILTROS_SELECCIONADOS(state) {
            state.filtrosSeleccionados.splice(0,state.filtrosSeleccionados.length);
        },

        setFiltrosSeleccionados(state, value) {
            state.filtrosSeleccionados = value;
        },

        SET_CUBO_SELECCIONADO(state, value) {
            state.cuboSeleccionado = value;
        },

        SET_NOMBRE_HIPOTESIS(state, value) {
            state.nombreHipotesis = value;
        },

        SET_DESCRIPCION_HIPOTESIS(state, value) {
            state.descripcionHipotesis = value;
        },

        SET_OBJETIVO_HIPOTESIS(state, value) {
            state.objetivoHipotesis = value;
        },

        SET_TIPO_RELEVANCIA(state, value) {
            state.tiposRelevanciaSeleccionado = value;
        },

        SET_TIPO_PONDERACION(state, value) {
            state.tipoPonderacionSeleccionado = value;
        },

        SET_TIPO_DESVIO(state, value) {
            state.tipoDesvioSeleccionado = value;
        },

        SET_CODIGO_HIPOTESIS(state, value) {
            state.codigoHipotesis = value;
        },

        SET_ERROR_MESSAGE(state, value) {
            state.titulo = "Error";
            state.mensaje = value;
            state.color = "red";
            state.goToHome = true;
            state.goToCampana = false;
        },

        SET_SUCCESS_MESSAGE(state, value) {
            state.titulo = "Hipotesis";
            state.mensaje = value;
            state.color = "green";
            state.goToHome = true;
            state.goToCampana = false;
        },

        CLEAN_SELECCIONES_HIPOTESIS(state) {
            state.hipotesis = null;
            state.hipotesisSeleccionada = null;
            state.showDetailHip = false;

        },

        SET_HIPOTESIS_SELECCIONADA(state, value) {
            state.hipotesisSeleccionada = value;
        },

        SET_SHOW_DETAIL_HIPOTESIS(state, value) {
            state.showDetailHip = value;
        },

        SET_HIPOTESIS(state, value) {
            state.hipotesis = value;
        },

        SET_MIS_HIPOTESIS(state, value) {
            state.misHipotesis = value;
        },

               

        //ENVIAR A DFE
        SET_NOMBRE_USUARIO(state, value){
            state.nombreUsuarioState = value;
        },

        SET_AREA_USUARIO(state, value){
            state.areaUsuarioState = value;
        },

        SET_CARGO_USUARIO(state, value){
            state.cargoUsuarioState = value;
        },

        SET_CODIGO_CAMPANIA(state, value){
            state.codigoDeCampaniaSeleccionado = value;
        },

        SET_ID_SISTEMA_EVENTANILLA(state, value){
            state.idSistemaEVentanillaSeleccionado = value;
        },

        SET_ENCABEZADO_CARTA(state, value){
            state.encabezadoCartaState = value;
        },

        SET_PRIMER_PARRAFO(state, value){
            state.primerParrafoState = value;
        },

        SET_SEGUNDO_PARRAFO(state, value){
            state.segundoParrafoState = value;
        },

        SET_PDF_NOMBRE(state, value){
            state.pdfNombreState = value;
        },

        SHOW_ENVIAR_DFE(state, value){
            state.openEnviarDFE = value;
        },

        SET_SISTEMAS_EVENTANILLA(state, value){
            state.sistemasEventanilla = value;
        },

        // ventanilla
        SET_MIS_CAMPANIAS(state, value) {
            state.listadoCampanias = value;
        },

        CLEAN_SELECCIONES_ENVIAR_DFE(state) {
            state.codigoDeCampaniaSeleccionado = null;
            state.idSistemaEVentanillaSeleccionado = null;
            state.encabezadoCartaState = null;
            state.primerParrafoState = null;
            state.segundoParrafoState = null;
            state.cartaEncabezado = null;
            state.cartaPrimerParrafo = null;
            state.cartaSegundoParrafo = null;
            state.nombreUsuarioState = null;
            state.cargoUsuarioState = null;
            state.areaUsuarioState = null;      
            state.showCarta = false;
            state.pdfNombreState = null;
            state.tipoDesvioSeleccionado = null;
            state.formulariosSeleccionados = [];
        },

        SET_ENVIAR_DFE_VALIDO(state, value){
            state.enviarDFEValido = value;
        },

        SET_SAVE_CAMPANIA(state, value){
            state.saveCampania = value;
        },

        SET_CARTA(state, value){
            state.cartaEncabezado       = value.encabezado;
            state.cartaPrimerParrafo    = value.primerParrafo;
            state.cartaSegundoParrafo   = value.segundoParrafo;
            state.firmante              = value.firmante;
            state.cargo                 = value.cargo;
            state.area                  = value.area;
        },

        CLEAR_CARTA(state, value){
            state.cartaEncabezado = null;
            state.cartaPrimerParrafo = null;
            state.cartaSegundoParrafo = null;
        },

        SET_SHOW_CARTA(state, value){
            state.showCarta = value;
        }

    }
}

export default SeleccionarStore;