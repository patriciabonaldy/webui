# fiscar-data-explorer-web-ui

## Project setup
```
npm install
```
### EXECUTE MODE DEVELOPMENT 
```
npm run serve-local
```

### EXECUTE MODE DEVELOPMENT MOCK
```
npm run serve-local-mock
```

## Deployment
### NOTA:                                           ###
#####       EJECUTAR DESPUES DE TAGEAR EN GIT       ##### 
#####   Compilar para todos los ambientes           #####

~~~bash
./scripts/service.sh build-all
~~~
### Releasing

~~~bash
./scripts/service.sh deploy-to-nexus
~~~

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).
