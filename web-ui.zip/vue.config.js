module.exports = {
  outputDir: "target/dist-" + process.env.NODE_ENV,
  publicPath: "/webapp/",
  pwa: {
    name: "fiscar-data-explorer",
    iconPaths: {
      favicon16: "img/icons/favicon.png",
      favicon32: "img/icons/favicon.png"
    }
  },
  productionSourceMap: false,
};
